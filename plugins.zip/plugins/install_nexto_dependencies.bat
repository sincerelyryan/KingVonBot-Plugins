@echo off
echo ===================================================================
echo Installing Nexto dependencies...
echo ===================================================================

echo Installing numpy...
pip install numpy>=1.19.0

echo Installing rlgym-compat...
pip install rlgym-compat>=1.0.0

echo Installing PyTorch...
pip install torch>=1.7.0 --find-links https://download.pytorch.org/whl/torch_stable.html

echo Installing additional packages...
pip install scipy>=1.5.0 matplotlib>=3.3.0 pandas>=1.0.0

echo ===================================================================
echo Installation complete!
echo Please restart the application to use NextoSwitchPlugin.
echo ===================================================================
pause
