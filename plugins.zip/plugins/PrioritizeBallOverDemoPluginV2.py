import math
from rlbot.agents.base_agent import SimpleControllerState
from rlbot.utils.structures.game_data_struct import Vector3 as Vec3

class UnifiedBallPrioritySystem:
    def __init__(self, ConsoleLogger=None):
        self.logger = ConsoleLogger if ConsoleLogger else print
        self.name = "UnifiedGameSense"
        self.packet = None
        self.index = -1
        self.field_info = None
        self.active_state = 'INACTIVE'
        
        # --- CONFIGURATION CONSTANTS ---
        self.LOW_BOOST_THRESHOLD = 20
        self.AERIAL_HEIGHT_THRESHOLD = 300.0
        self.DRIBBLE_MAX_DIST = 190.0
        self.SHOT_DISTANCE_THRESHOLD = 400.0
        self.SHOT_ALIGNMENT_ANGLE = math.radians(10)
        self.SHADOW_DISTANCE_BUFFER = 600.0
        
        # Anti-Bad-Demo Thresholds
        self.MIN_BALL_PROXIMITY_OVERRIDE = 400.0 
        self.MIN_SPEED_FOR_DEMO_LOGIC = 1400.0
        self.MAX_DIST_OPP_FROM_BALL = 1300.0 # If opp is further than this from ball, stop demoing

    def initialize(self, *args, **kwargs): pass

    def game_tick_packet_set(self, packet, local_player_index, playername, field_info):
        self.packet = packet
        self.field_info = field_info
        self.index = local_player_index

        if not self.packet or self.index >= self.packet.num_cars: return

        # 1. Update High-Level Strategy
        if self.packet.game_ball.latest_touch.player_name == '':
            self.active_state = 'KICKOFF'
        else:
            self.active_state = self._determine_best_action()

    def _determine_best_action(self):
        """The 'Brain' - Decides tactical priority."""
        my_car = self.packet.game_cars[self.index]
        ball = self.packet.game_ball
        team_sign = -1 if my_car.team == 0 else 1
        
        # Check positioning
        is_on_opponent_half = (team_sign * my_car.physics.location.y) < 0
        is_ball_behind_me = (team_sign * my_car.physics.location.y) < (team_sign * ball.physics.location.y)
        
        # Priority Stack
        if is_on_opponent_half and is_ball_behind_me: return 'MUST_ROTATE'
        if self._check_for_imminent_threat(): return 'SAVING'
        if ball.physics.location.z > self.AERIAL_HEIGHT_THRESHOLD: return 'AERIALING'
        if my_car.boost < self.LOW_BOOST_THRESHOLD: return 'ROTATING'
        
        # Offensive logic
        dist_to_ball = self._dist(my_car.physics.location, ball.physics.location)
        if (team_sign * my_car.physics.location.y) > (team_sign * ball.physics.location.y):
            if dist_to_ball < self.DRIBBLE_MAX_DIST: return 'FLICKING'
            return 'ATTACKING'
        
        return 'SHADOWING'

    def controller_filter(self, original_controls: SimpleControllerState) -> SimpleControllerState:
        """The 'Filter' - Refines physical movement and blocks bad demos."""
        if self.active_state in ['INACTIVE', 'KICKOFF']: return None
        
        # 1. Check if we are accidentally chasing a bad demo
        if self.active_state != 'SAVING': # Never abort a save attempt
            if self._is_chasing_bad_demo():
                # If demo is bad, we force a ball-focused controller state
                return self._generate_ball_controls()

        # 2. Otherwise, return standard tactical controls
        return self._generate_tactical_controls()

    def _is_chasing_bad_demo(self):
        """Infers if the current movement is a low-value demo attempt."""
        car = self.packet.game_cars[self.index]
        car_vel = Vec3(car.physics.velocity.x, car.physics.velocity.y, car.physics.velocity.z)
        speed = math.sqrt(car_vel.x**2 + car_vel.y**2 + car_vel.z**2)
        
        if speed < self.MIN_SPEED_FOR_DEMO_LOGIC: return False

        ball_loc = self.packet.game_ball.physics.location
        for i in range(self.packet.num_cars):
            opp = self.packet.game_cars[i]
            if opp.team == car.team or opp.is_demolished: continue
            
            dist_to_opp = self._dist(car.physics.location, opp.physics.location)
            if dist_to_opp < 800:
                dist_opp_to_ball = self._dist(opp.physics.location, ball_loc)
                # Logic: If the opponent is far from the play, the demo is 'bad'
                if dist_opp_to_ball > self.MAX_DIST_OPP_FROM_BALL:
                    return True
        return False

    def _generate_ball_controls(self):
        """Emergency steering to snap back to the ball."""
        controls = SimpleControllerState()
        controls.steer = self._steer_toward(self.packet.game_ball.physics.location)
        controls.throttle = 1.0
        return controls

    def _generate_tactical_controls(self):
        """Standard movement based on active_state."""
        car = self.packet.game_cars[self.index]
        ball_loc = self.packet.game_ball.physics.location
        team_sign = -1 if car.team == 0 else 1
        controls = SimpleControllerState()
        
        # Target Selection
        target = ball_loc
        if self.active_state in ['MUST_ROTATE', 'ROTATING']:
            target = Vec3(0, -5120 * team_sign, 0)
        elif self.active_state == 'SHADOWING':
            target = Vec3(0, -5120 * team_sign, 0) # Head home to shadow

        controls.steer = self._steer_toward(target)
        controls.throttle = 1.0
        controls.boost = abs(controls.steer) < 0.2
        
        # Action triggers
        dist = self._dist(car.physics.location, ball_loc)
        if self.active_state == 'SAVING' and dist < 600:
            controls.jump = True
        elif self.active_state == 'AERIALING' and car.has_wheel_contact:
            controls.jump = True
            controls.pitch = 1.0

        return controls

    # --- HELPERS ---
    def _steer_toward(self, target):
        car = self.packet.game_cars[self.index]
        to_target = Vec3(target.x - car.physics.location.x, target.y - car.physics.location.y, 0)
        angle = math.atan2(to_target.y, to_target.x) - car.physics.rotation.yaw
        while angle > math.pi: angle -= 2 * math.pi
        while angle < -math.pi: angle += 2 * math.pi
        return max(-1.0, min(1.0, angle * 4.0))

    def _dist(self, v1, v2):
        return math.sqrt((v1.x-v2.x)**2 + (v1.y-v2.y)**2 + (v1.z-v2.z)**2)

    def _check_for_imminent_threat(self):
        car = self.packet.game_cars[self.index]
        team_sign = -1 if car.team == 0 else 1
        own_goal = Vec3(0, -5120 * team_sign, 100)
        return self._dist(self.packet.game_ball.physics.location, own_goal) < 2500