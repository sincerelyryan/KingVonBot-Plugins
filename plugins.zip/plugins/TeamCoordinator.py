# plugins/team_coordinator.py

class TeamCoordinatorPlugin:
    def __init__(self, ConsoleLogger=None):
        self.logger = ConsoleLogger or print
        self.Name = "Team Coordinator"
        self.enabled = True
        
        self.team_stats = {}
        self.last_analysis_time = 0
        self.last_strategy_message = ""  # Prevent spam of same message
        
        self.logger(f"[{self.Name}] Team coordination plugin initialized.")

    def initialize(self):
        self.logger(f"[{self.Name}] Ready to coordinate team strategy.")

    def game_tick_packet_set(self, packet, local_player_index, playername, field_info):
        if not self.enabled:
            return None
            
        # Analyze team composition and performance every 5 seconds
        if packet.game_info.seconds_elapsed - self.last_analysis_time > 5:
            controls = self._analyze_team_performance(packet, local_player_index)
            self.last_analysis_time = packet.game_info.seconds_elapsed
            return controls
            
        return None

    def _analyze_team_performance(self, packet, local_player_index):
        if local_player_index >= packet.num_cars:
            return None
            
        local_team = packet.game_cars[local_player_index].team
        
        # Collect team and opponent stats
        team_stats = {'players': [], 'total_score': 0, 'total_goals': 0, 'total_saves': 0}
        opponent_stats = {'players': [], 'total_score': 0, 'total_goals': 0, 'total_saves': 0}
        
        for i in range(packet.num_cars):
            car = packet.game_cars[i]
            player_name = car.name.decode('utf-8') if hasattr(car.name, 'decode') else str(car.name)
            
            player_data = {
                'name': player_name,
                'score': car.score_info.score,
                'goals': car.score_info.goals,
                'assists': car.score_info.assists,
                'saves': car.score_info.saves,
                'shots': car.score_info.shots,
                'demos': car.score_info.demolitions
            }
            
            if car.team == local_team:
                team_stats['players'].append(player_data)
                team_stats['total_score'] += car.score_info.score
                team_stats['total_goals'] += car.score_info.goals
                team_stats['total_saves'] += car.score_info.saves
            else:
                opponent_stats['players'].append(player_data)
                opponent_stats['total_score'] += car.score_info.score
                opponent_stats['total_goals'] += car.score_info.goals
                opponent_stats['total_saves'] += car.score_info.saves
        
        # Strategic analysis with actual control modifications
        return self._provide_strategic_advice(team_stats, opponent_stats, packet, local_player_index)

    def _provide_strategic_advice(self, team_stats, opponent_stats, packet, local_player_index):
        # Score difference analysis
        score_diff = team_stats['total_score'] - opponent_stats['total_score']
        
        # Fix time calculation - game_time_remaining is in seconds, not minutes
        time_remaining_seconds = packet.game_info.game_time_remaining
        time_remaining_minutes = time_remaining_seconds / 60.0
        
        strategy_message = ""
        controls = None
        
        # Time-based strategy with actual behavior changes
        if time_remaining_seconds < 60 and score_diff < -50:  # Less than 1 minute and losing
            strategy_message = f"CRITICAL: Less than 1 minute remaining ({time_remaining_seconds:.0f}s) - all-out attack mode!"
            controls = self._get_aggressive_controls(packet, local_player_index)
            
        elif time_remaining_seconds < 30 and score_diff > 50:  # Less than 30 seconds and winning
            strategy_message = f"DEFENSIVE: Less than 30 seconds remaining ({time_remaining_seconds:.0f}s) - protect the lead!"
            controls = self._get_defensive_controls(packet, local_player_index)
            
        elif score_diff > 200:
            strategy_message = "WINNING: Maintain defensive positioning and capitalize on counter-attacks."
            controls = self._get_balanced_controls(packet, local_player_index)
            
        elif score_diff < -200:
            strategy_message = "LOSING: Increase offensive pressure and look for demo opportunities."
            controls = self._get_aggressive_controls(packet, local_player_index)
            
        else:
            strategy_message = f"CLOSE GAME: Focus on consistent plays and boost management. Time: {time_remaining_minutes:.1f}m"
            controls = self._get_balanced_controls(packet, local_player_index)
        
        # Only log if strategy message changed to prevent spam
        if strategy_message != self.last_strategy_message:
            self.logger(f"[{self.Name}] {strategy_message}")
            self.last_strategy_message = strategy_message
            
        return controls

    def _get_aggressive_controls(self, packet, local_player_index):
        """Return aggressive control modifications"""
        if local_player_index >= packet.num_cars:
            return None
            
        local_car = packet.game_cars[local_player_index]
        ball = packet.game_ball.physics.location
        car_pos = local_car.physics.location
        
        # Calculate distance to ball
        ball_distance = ((ball.x - car_pos.x)**2 + (ball.y - car_pos.y)**2 + (ball.z - car_pos.z)**2)**0.5
        
        # Aggressive behavior: always go for ball if reasonably close
        if ball_distance < 2000 and local_car.boost > 20:
            from rlbot.agents.base_agent import SimpleControllerState
            controller = SimpleControllerState()
            controller.throttle = 1.0
            controller.boost = True
            return controller
            
        return None

    def _get_defensive_controls(self, packet, local_player_index):
        """Return defensive control modifications"""
        if local_player_index >= packet.num_cars:
            return None
            
        local_car = packet.game_cars[local_player_index]
        car_pos = local_car.physics.location
        
        # Defensive behavior: stay back if too far forward
        if abs(car_pos.y) > 3000:  # Too far from goal
            from rlbot.agents.base_agent import SimpleControllerState
            controller = SimpleControllerState()
            # Slow down and position defensively
            controller.throttle = 0.5
            controller.boost = False
            return controller
            
        return None

    def _get_balanced_controls(self, packet, local_player_index):
        """Return balanced control modifications"""
        if local_player_index >= packet.num_cars:
            return None
            
        local_car = packet.game_cars[local_player_index]
        
        # Balanced behavior: boost management
        if local_car.boost < 20:
            from rlbot.agents.base_agent import SimpleControllerState
            controller = SimpleControllerState()
            controller.boost = False  # Conserve boost
            return controller
            
        return None

    @condition("packet.game_info.is_kickoff_pause")
    def kickoff_strategy(self, packet, local_player_index, playername):
        if not self.enabled:
            return
            
        local_car = packet.game_cars[local_player_index]
        time_remaining = packet.game_info.game_time_remaining
        
        # Only log kickoff strategy occasionally to prevent spam
        if hasattr(self, '_last_kickoff_log'):
            if packet.game_info.seconds_elapsed - self._last_kickoff_log < 10:
                return
        
        self.logger(f"[{self.Name}] Kickoff - Time remaining: {time_remaining:.0f}s | Boost: {local_car.boost}%")
        self._last_kickoff_log = packet.game_info.seconds_elapsed

    def on_game_event_started(self, event):
        self.team_stats.clear()
        self.last_analysis_time = 0
        self.last_strategy_message = ""
        if hasattr(self, '_last_kickoff_log'):
            delattr(self, '_last_kickoff_log')
        self.logger(f"[{self.Name}] New match - team coordination reset.")

    def shutdown(self):
        self.enabled = False
        self.logger(f"[{self.Name}] Team coordinator shutting down.")
