import math
import time
import threading
import json
import os

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

class PerformanceAnalyzerPlugin:
    def __init__(self, ConsoleLogger=None):
        self.logger = ConsoleLogger or print
        self.enabled = True
        self.webhook_enabled = False
        self.webhook_url = None
        self.analysis_data = {}
        self.tick_count = 0
        self.analysis_interval = 3600  # Report every ~60 seconds (60 ticks * 60)
        self.match_start_time = None
        self.match_ended = False
        self.SUPERSONIC_THRESHOLD = 2200.0
        self.rocketstats_path = os.path.join(
            os.environ.get('APPDATA', ''),
            'bakkesmod', 'bakkesmod', 'data', 'RocketStats'
        )
        self._load_webhook_config()

    def _load_webhook_config(self):
        config_path = os.path.join(os.path.dirname(__file__), "discord_config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    url = config.get("webhook_url")
                    if url and REQUESTS_AVAILABLE:
                        self.webhook_url = url
                        self.webhook_enabled = config.get("enabled", True)
                    elif not REQUESTS_AVAILABLE:
                        self.logger("[PerformanceAnalyzer] WARNING: requests module not installed.")
            except Exception as e:
                self.logger(f"[PerformanceAnalyzer] Error loading config: {e}")
        else:
            try:
                # Default template if file doesn't exist
                template = {
                    "webhook_url": "YOUR_WEBHOOK_URL_HERE", 
                    "enabled": False
                }
                with open(config_path, 'w') as f:
                    json.dump(template, f, indent=4)
            except: pass

    def initialize(self):
        self.logger("[PerformanceAnalyzer] Plugin Initialized & Ready.")

    def shutdown(self):
        self.enabled = False

    def _format_time(self, seconds):
        if seconds < 0: return "OT"
        m = int(seconds // 60)
        s = int(seconds % 60)
        return f"{m}:{s:02d}"

    def _read_stat_file(self, filename):
        path = os.path.join(self.rocketstats_path, filename)
        if os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    return f.read().strip()
            except: pass
        return None

    def _get_session_stats(self):
        stats = {
            'wins': self._read_stat_file('RocketStats_Win.txt'),
            'losses': self._read_stat_file('RocketStats_Loss.txt'),
            'streak': self._read_stat_file('RocketStats_Streak.txt'),
            'rank': self._read_stat_file('RocketStats_RankName.txt') or self._read_stat_file('RocketStats_Rank.txt'),
            'mmr': self._read_stat_file('RocketStats_MMR.txt'),
        }
        for k, v in stats.items():
            if v is None: stats[k] = "N/A"
        return stats

    def game_tick_packet_set(self, packet, local_player_index, playername, field_info, **kwargs):
        if not self.enabled: return
        
        if self.match_start_time is None:
            self.match_start_time = packet.game_info.seconds_elapsed
        
        self.tick_count += 1
        
        if local_player_index < packet.num_cars:
            local_car = packet.game_cars[local_player_index]
            
            if playername not in self.analysis_data:
                self.analysis_data[playername] = {
                    'total_ticks': 0,
                    'boost_usage': [],
                    'speed_samples': [],
                    'total_boost_consumed': 0.0,
                    'last_boost': local_car.boost,
                    'air_ticks': 0,
                    'supersonic_ticks': 0,
                    'distance_traveled': 0.0,
                    'last_pos': (local_car.physics.location.x, local_car.physics.location.y, local_car.physics.location.z),
                }
            
            data = self.analysis_data[playername]
            data['total_ticks'] += 1
            
            # Boost Tracking
            current_boost = local_car.boost
            data['boost_usage'].append(current_boost)
            if current_boost < data['last_boost']:
                data['total_boost_consumed'] += (data['last_boost'] - current_boost)
            data['last_boost'] = current_boost
            
            # Speed Tracking
            vel = local_car.physics.velocity
            speed = math.hypot(vel.x, vel.y, vel.z)
            data['speed_samples'].append(speed)
            
            # State Tracking
            if not local_car.has_wheel_contact:
                data['air_ticks'] += 1
            if speed >= self.SUPERSONIC_THRESHOLD:
                data['supersonic_ticks'] += 1
            
            # Distance Tracking
            curr_loc = local_car.physics.location
            current_pos = (curr_loc.x, curr_loc.y, curr_loc.z)
            dx = current_pos[0] - data['last_pos'][0]
            dy = current_pos[1] - data['last_pos'][1]
            dz = current_pos[2] - data['last_pos'][2]
            data['distance_traveled'] += math.hypot(dx, dy, dz)
            data['last_pos'] = current_pos

        # Periodic Analysis Trigger
        if self.tick_count % self.analysis_interval == 0:
            self._perform_analysis(packet, local_player_index, playername)

    def _perform_analysis(self, packet, local_player_index, playername):
        if playername not in self.analysis_data: return
        data = self.analysis_data[playername]
        local_car = packet.game_cars[local_player_index]
        
        # Calculations
        avg_boost = sum(data['boost_usage'][-60:]) / min(60, len(data['boost_usage']))
        avg_speed = sum(data['speed_samples'][-60:]) / min(60, len(data['speed_samples']))
        total_time = max(1, packet.game_info.seconds_elapsed - (self.match_start_time or 0))
        score_per_min = (local_car.score_info.score / total_time) * 60
        
        air_s = data['air_ticks'] / 60.0
        super_s = data['supersonic_ticks'] / 60.0
        super_pct = (super_s / total_time) * 100 if total_time > 0 else 0
        
        # Team Scores
        try:
            my_team = local_car.team
            our_score = packet.teams[my_team].score
            their_score = packet.teams[1 - my_team].score
        except:
            our_score = their_score = 0
            
        time_str = self._format_time(packet.game_info.game_time_remaining)
        session = self._get_session_stats()
        
        if self.webhook_enabled:
            self._send_discord_report(playername, data, local_car, our_score, their_score, time_str, 
                                     avg_boost, avg_speed, score_per_min, air_s, super_s, super_pct, session)

    def _send_discord_report(self, playername, data, local_car, our_score, their_score, time_str, 
                            avg_boost, avg_speed, spm, air_s, super_s, super_pct, session):
        def send():
            try:
                color = 0x2ecc71 if our_score > their_score else (0xe74c3c if our_score < their_score else 0x95a5a6)
                embed = {
                    "title": f"📊 Mid-Match: {playername}",
                    "description": f"**Match:** `{our_score} - {their_score}` | **Remaining:** `{time_str}`",
                    "color": color,
                    "fields": [
                        {
                            "name": "⚽ Core Stats",
                            "value": f"**Score:** `{local_car.score_info.score}` (`{spm:.0f}/m`)\n**G/A/S:** `{local_car.score_info.goals}/{local_car.score_info.assists}/{local_car.score_info.saves}`",
                            "inline": False
                        },
                        {
                            "name": "🏎️ Physicals",
                            "value": f"**Avg Speed:** `{avg_speed:.0f}`\n**Supersonic:** `{super_pct:.1f}%`",
                            "inline": True
                        },
                        {
                            "name": "⚡ Resources",
                            "value": f"**Avg Boost:** `{avg_boost:.0f}%`\n**Used:** `{data['total_boost_consumed']:.0f}`",
                            "inline": True
                        },
                        {
                            "name": "📈 Session",
                            "value": f"**Rank:** {session['rank']} (`{session['mmr']}`)\n**Streak:** `{session['streak']}`",
                            "inline": False
                        }
                    ],
                    "footer": {"text": "Performance Analyzer • Live Feed"},
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
                }
                requests.post(self.webhook_url, json={"embeds": [embed]})
            except: pass

        threading.Thread(target=send, daemon=True).start()

    def _send_discord_summary(self, playername, data, session):
        def send():
            try:
                total_s = data['total_ticks'] / 60.0
                embed = {
                    "title": f"🏆 Match Summary: {playername}",
                    "color": 0x3498db,
                    "fields": [
                        {"name": "⏱️ Duration", "value": f"`{self._format_time(total_s)}`", "inline": True},
                        {"name": "✈️ Air Time", "value": f"`{data['air_ticks']/60.0:.1f}s`", "inline": True},
                        {"name": "🗺️ Distance", "value": f"`{data['distance_traveled']:,.0f}`", "inline": True},
                        {"name": "⛽ Total Boost", "value": f"`{data['total_boost_consumed']:.0f}`", "inline": True},
                        {"name": "🏅 Final Session", "value": f"Rank: {session['rank']} ({session['mmr']})\nRecord: `{session['wins']}W - {session['losses']}L`", "inline": False}
                    ],
                    "footer": {"text": "Match Complete"},
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
                }
                requests.post(self.webhook_url, json={"embeds": [embed]})
            except: pass

        threading.Thread(target=send, daemon=True).start()

    def on_game_event_started(self, event):
        self.analysis_data.clear()
        self.tick_count = 0
        self.match_start_time = None
        self.match_ended = False

    def on_game_event_destroyed(self, event):
        if self.match_ended: return
        self.match_ended = True
        for playername, data in self.analysis_data.items():
            if data['total_ticks'] > 100: # Ensure it was a real match
                self._send_discord_summary(playername, data, self._get_session_stats())

    def controller_filter(self, controller):
        return controller