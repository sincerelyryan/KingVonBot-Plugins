# plugins/KickoffSupportPlugin.py
import math
from rlbot.agents.base_agent import SimpleControllerState
# Si necesitas type-hinting para GameTickPacket, PlayerInfo, etc.,
# normalmente las importarías desde donde están definidas en tu script principal.
# from your_main_script import GameTickPacket, PlayerInfo, BallInfo

# --- Constantes del Plugin ---
# DISTANCE_TOLERANCE_SQ = 10.0**2  # This was for very fine-grained equality, replaced by KICKOFF_CHEAT_ALLOWANCE_SQ for grouping
KICKOFF_CHEAT_ALLOWANCE_SQ = 1300000.0  # Allows for significant 'cheating' (e.g., ~200 units movement) while still grouping players for kickoff decision. (Squared units)
BALL_REST_SPEED_THRESHOLD = 60.0  # Velocidad máxima para considerar que la pelota está en reposo para el kickoff
BALL_KICKOFF_POS_X_TOLERANCE = 10.0 # Tolerancia para la posición X de la pelota en kickoff
BALL_KICKOFF_POS_Y_TOLERANCE = 10.0 # Tolerancia para la posición Y de la pelota en kickoff
BALL_KICKOFF_POS_Z_MIN = 90.0 # Altura mínima de la pelota en kickoff
BALL_KICKOFF_POS_Z_MAX = 95.0 # Altura máxima de la pelota en kickoff


class KickoffSupportPlugin:
    def __init__(self, ConsoleLogger):
        self.logger = ConsoleLogger
        self.active = False  # ¿Debe el plugin tomar el control?
        self.was_active_last_tick = False # Para registrar cambios de estado

        # Estado para la lógica de kickoff
        self.kickoff_logic_evaluated_this_pause = False
        self.i_am_designated_kickoff_taker = False
        self.ball_touched_after_kickoff_pause_started = False
        self.ball_touch_time_at_kickoff_pause_start = 0.0

        self.logger("KickoffSupportPlugin: Initialized.")

    def Name(self) -> str:
        """Proporciona un nombre legible para el plugin."""
        return "KickoffSupport"

    def _is_ball_in_kickoff_position(self, packet) -> bool:
        """Verifica si la pelota está en la posición central de kickoff."""
        ball_loc = packet.game_ball.physics.location
        return (
            abs(ball_loc.x) < BALL_KICKOFF_POS_X_TOLERANCE and
            abs(ball_loc.y) < BALL_KICKOFF_POS_Y_TOLERANCE and
            BALL_KICKOFF_POS_Z_MIN < ball_loc.z < BALL_KICKOFF_POS_Z_MAX
        )

    def _is_ball_at_rest(self, packet) -> bool:
        """Verifica si la pelota está esencialmente quieta."""
        ball_vel = packet.game_ball.physics.velocity
        ball_speed = math.hypot(ball_vel.x, ball_vel.y, ball_vel.z)
        return ball_speed < BALL_REST_SPEED_THRESHOLD

    def game_tick_packet_set(self, packet, local_player_index: int, playername: str, **kwargs):
        """
        Lógica principal del plugin, llamada en cada tick.
        Determina si el plugin debe activarse.
        """
        game_info = packet.game_info
        my_car_info = packet.game_cars[local_player_index]
        ball = packet.game_ball

        if my_car_info.spawn_id == -1: # Si mi coche aún no ha spawneado o no es válido
            if self.active:
                 self.logger("KickoffSupportPlugin: Deactivating - My car spawn_id is -1.")
            self.active = False
            self.kickoff_logic_evaluated_this_pause = False
            return

        # --- Resetear estado si no estamos en una pausa de kickoff activa ---
        if not game_info.is_round_active or not game_info.is_kickoff_pause:
            if self.active: # Si estaba activo, ahora se desactiva
                self.logger("KickoffSupportPlugin: Deactivating - Not a kickoff pause or round inactive.")
            self.active = False
            self.kickoff_logic_evaluated_this_pause = False # Listo para la próxima pausa
            return

        # --- Lógica de Kickoff (solo se ejecuta una vez por pausa de kickoff) ---
        if not self.kickoff_logic_evaluated_this_pause:
            self.kickoff_logic_evaluated_this_pause = True # Marcar como evaluado para esta pausa
            self.ball_touched_after_kickoff_pause_started = False # Resetear
            self.ball_touch_time_at_kickoff_pause_start = ball.latest_touch.time_seconds

            if not self._is_ball_in_kickoff_position(packet) or not self._is_ball_at_rest(packet):
                self.logger("KickoffSupportPlugin: Ball not in kickoff state during kickoff pause. Won't activate.")
                self.i_am_designated_kickoff_taker = True # Asumir que no debemos interferir (or False, depending on desired default)
            else:
                ball_pos_2d = (ball.physics.location.x, ball.physics.location.y)
                
                # Step 1: Collect all valid teammates and their squared distances to the ball.
                potential_kickoff_takers_data = []
                for i in range(packet.num_cars):
                    car_candidate = packet.game_cars[i]
                    if car_candidate.spawn_id != -1 and car_candidate.team == my_car_info.team and not car_candidate.is_demolished:
                        car_loc_2d = (car_candidate.physics.location.x, car_candidate.physics.location.y)
                        dist_sq = (car_loc_2d[0] - ball_pos_2d[0])**2 + (car_loc_2d[1] - ball_pos_2d[1])**2
                        potential_kickoff_takers_data.append({'car': car_candidate, 'dist_sq': dist_sq})

                teammates_for_kickoff_decision = [] # This will store car objects
                if not potential_kickoff_takers_data:
                    self.logger("KickoffSupportPlugin: No valid teammates found (this should include self). Assuming I take it to be safe.")
                    self.i_am_designated_kickoff_taker = True
                else:
                    # Step 2: Find the minimum squared distance among them.
                    min_dist_sq_found = min(p['dist_sq'] for p in potential_kickoff_takers_data)
                    
                    # Step 3: Populate teammates_for_kickoff_decision with those close to the absolute minimum, using KICKOFF_CHEAT_ALLOWANCE_SQ.
                    for p_data in potential_kickoff_takers_data:
                        if p_data['dist_sq'] < min_dist_sq_found + KICKOFF_CHEAT_ALLOWANCE_SQ:
                            teammates_for_kickoff_decision.append(p_data['car'])

                # Now, teammates_for_kickoff_decision contains the group of players considered for kickoff.
                # The rest of the logic (len == 1, len == 2, etc.) will use this list.

                if not teammates_for_kickoff_decision: # Should be caught by the check on potential_kickoff_takers_data, but as a safeguard
                    self.logger("KickoffSupportPlugin: ERROR - No valid teammates found for kickoff decision (should include self). Assuming I take it to be safe.")
                    self.i_am_designated_kickoff_taker = True
                elif len(teammates_for_kickoff_decision) == 1:
                    kickoff_taker = teammates_for_kickoff_decision[0]
                    # Compare names instead of object identity
                    kt_name = kickoff_taker.name if hasattr(kickoff_taker, 'name') and kickoff_taker.name else ""
                    self.i_am_designated_kickoff_taker = (kt_name == playername)
                    
                    # Enhanced logging for diagnostics
                    kt_name_str = kt_name[:10] if kt_name else f"SpawnID:{kickoff_taker.spawn_id}"
                    mci_name_str = my_car_info.name[:10] if hasattr(my_car_info, 'name') and my_car_info.name else f"SpawnID:{my_car_info.spawn_id}"

                    self.logger(
                        f"KickoffSupportPlugin: Single closest diagnostic:"
                        f"\n - Kicker: '{kt_name_str}' (SpawnID: {kickoff_taker.spawn_id})"
                        f"\n - MyCar: '{mci_name_str}' (SpawnID: {my_car_info.spawn_id})"
                        f"\n - ArgPlayerName: '{playername[:10] if playername else 'N/A'}'"
                        f"\n - Names Match?: {kt_name == playername}"
                        f"\n - Decision: I {'AM' if self.i_am_designated_kickoff_taker else 'am NOT'} taker."
                    )
                else: # Tie in distance involving 2 or more players (including self)
                    self.logger(f"KickoffSupportPlugin: Tie in distance among {len(teammates_for_kickoff_decision)} players for team {my_car_info.team}. My SpawnID: {my_car_info.spawn_id}")
                    for p_idx, p_info in enumerate(teammates_for_kickoff_decision):
                        p_name = p_info.name[:10] if hasattr(p_info, 'name') and p_info.name else f"SpawnID:{p_info.spawn_id}"
                        self.logger(f"  - Candidate {p_idx+1}: {p_name} (X: {p_info.physics.location.x:.0f}, SpawnID: {p_info.spawn_id})")

                    actual_kickoff_taker = None # Stores the car object of the determined kickoff taker

                    if len(teammates_for_kickoff_decision) == 2:
                        # Identify self and the other teammate in the 2-way tie using names
                        other_teammate = None
                        my_name = playername if playername else ""
                        
                        for car in teammates_for_kickoff_decision:
                            car_name = car.name if hasattr(car, 'name') and car.name else ""
                            if car_name != my_name:  # This is the other car
                                other_teammate = car
                                break
                        
                        if other_teammate:
                            bot_pos_x = my_car_info.physics.location.x
                            # Strict 'left goes' rule based on X-coordinates for 2-player ties.
                            my_x = my_car_info.physics.location.x
                            teammate_x = other_teammate.physics.location.x
                            teammate_name_log = other_teammate.name[:10] if hasattr(other_teammate, 'name') and other_teammate.name else f'SpawnID:{other_teammate.spawn_id}'

                            self.logger(f"KickoffSupportPlugin: 2-way tie. My X: {my_x:.0f}, Teammate ({teammate_name_log}) X: {teammate_x:.0f}. Team: {my_car_info.team}")

                            if my_car_info.team == 0:  # Blue team
                                # For Blue team, player with larger X is on the left.
                                if my_x > teammate_x:
                                    self.i_am_designated_kickoff_taker = True
                                    actual_kickoff_taker = my_car_info
                                    self.logger(f"KickoffSupportPlugin: Blue team - I am on the left (X: {my_x:.0f} > {teammate_x:.0f}). I take kickoff.")
                                elif teammate_x > my_x: # Teammate is further left
                                    self.i_am_designated_kickoff_taker = False
                                    actual_kickoff_taker = other_teammate
                                    self.logger(f"KickoffSupportPlugin: Blue team - Teammate ({teammate_name_log}) is on the left (X: {teammate_x:.0f} > {my_x:.0f}). I do NOT take kickoff.")
                                else: # X coordinates are identical (e.g. both center spawns, though this case is for 2 players)
                                    self.logger(f"KickoffSupportPlugin: Blue team - X coords are identical ({my_x:.0f}). Defaulting to me taking kickoff (arbitrary tie-break, could be improved if needed).")
                                    self.i_am_designated_kickoff_taker = True # Arbitrary tie-break, could be name based or random
                                    actual_kickoff_taker = my_car_info
                            else:  # Orange team (team == 1)
                                # For Orange team, player with smaller X is on the left.
                                if my_x < teammate_x:
                                    self.i_am_designated_kickoff_taker = True
                                    actual_kickoff_taker = my_car_info
                                    self.logger(f"KickoffSupportPlugin: Orange team - I am on the left (X: {my_x:.0f} < {teammate_x:.0f}). I take kickoff.")
                                elif teammate_x < my_x: # Teammate is further left
                                    self.i_am_designated_kickoff_taker = False
                                    actual_kickoff_taker = other_teammate
                                    self.logger(f"KickoffSupportPlugin: Orange team - Teammate ({teammate_name_log}) is on the left (X: {teammate_x:.0f} < {my_x:.0f}). I do NOT take kickoff.")
                                else: # X coordinates are identical
                                    self.logger(f"KickoffSupportPlugin: Orange team - X coords are identical ({my_x:.0f}). Defaulting to me taking kickoff (arbitrary tie-break, could be improved if needed).")
                                    self.i_am_designated_kickoff_taker = True # Arbitrary tie-break
                                    actual_kickoff_taker = my_car_info
                        else:
                            # Should not happen if my_car_info is in the list of 2. Fallback.
                            self.logger("KickoffSupportPlugin: ERROR - Bot not reliably identified in 2-player tie list. Falling back to X-coord logic for the list.")
                            # This fallback seems problematic as it sorts based on absolute X, not relative "leftness"
                            # Standard "left goes" rule for RL kickoffs:
                            # For Blue team (0): Highest X value goes (most positive X)
                            # For Orange team (1): Lowest X value goes (most negative X)
                            
                            # Corrected fallback logic
                            if not teammates_for_kickoff_decision: # Should not happen here, but good check
                                self.logger("KickoffSupportPlugin: CRITICAL ERROR - Tie-break fallback with empty teammates_for_kickoff_decision list. Assuming I go.")
                                self.i_am_designated_kickoff_taker = True
                                actual_kickoff_taker = my_car_info
                            elif my_car_info.team == 0: # Blue team
                                # Sort by X descending, highest X is leftmost
                                sorted_players = sorted(teammates_for_kickoff_decision, key=lambda c: c.physics.location.x, reverse=True)
                                actual_kickoff_taker = sorted_players[0]
                            else: # Orange team
                                # Sort by X ascending, lowest X is leftmost
                                sorted_players = sorted(teammates_for_kickoff_decision, key=lambda c: c.physics.location.x)
                                actual_kickoff_taker = sorted_players[0]
                            
                            # Now check if I am the designated taker from this corrected fallback
                            # Compare using spawn_id as a more robust unique identifier than name or object reference in some contexts
                            if actual_kickoff_taker:
                                self.i_am_designated_kickoff_taker = (actual_kickoff_taker.spawn_id == my_car_info.spawn_id)
                            else: # Should be impossible if teammates_for_kickoff_decision was not empty
                                self.i_am_designated_kickoff_taker = True # Failsafe
                                self.logger("KickoffSupportPlugin: ERROR - Fallback sorting failed to identify a taker. Defaulting to me taking kickoff.")


                    else: # Tie involves 3+ players, or an unexpected count (e.g., <2, though handled earlier)
                        self.logger(f"KickoffSupportPlugin: Tie among {len(teammates_for_kickoff_decision)} players (not 2). Using standard left player logic.")
                        # Left is determined from each team's perspective
                        if my_car_info.team == 0:  # Blue team
                            # For blue team, largest X is leftmost player
                            sorted_players = sorted(teammates_for_kickoff_decision, key=lambda c: c.physics.location.x, reverse=True)
                        else:  # Orange team
                            # For orange team, smallest X is leftmost player
                            sorted_players = sorted(teammates_for_kickoff_decision, key=lambda c: c.physics.location.x)
                        
                        if sorted_players: # Ensure list is not empty
                            actual_kickoff_taker = sorted_players[0]  # Leftmost player takes kickoff
                            # Compare using spawn_id
                            self.i_am_designated_kickoff_taker = (actual_kickoff_taker.spawn_id == my_car_info.spawn_id)
                        else: # Should be impossible here
                            self.logger("KickoffSupportPlugin: ERROR - sorted_players list empty in 3+ player tie. Defaulting to me taking kickoff.")
                            self.i_am_designated_kickoff_taker = True
                            actual_kickoff_taker = my_car_info # For logging purposes
                    
                    # Log the final decision
                    if actual_kickoff_taker:
                        taker_name = actual_kickoff_taker.name[:10] if hasattr(actual_kickoff_taker, 'name') and actual_kickoff_taker.name else f"SpawnID:{actual_kickoff_taker.spawn_id}"
                        mci_sid = my_car_info.spawn_id
                        akt_sid = actual_kickoff_taker.spawn_id
                        self.logger(
                            f"KickoffSupportPlugin: Tie-break winner: {taker_name} (X: {actual_kickoff_taker.physics.location.x:.0f}, SpawnID: {akt_sid}). "
                            f"My SpawnID: {mci_sid}. I {'AM' if self.i_am_designated_kickoff_taker else 'am NOT'} taker."
                        )
                    else:
                        # This case implies an error in determining the taker
                        self.logger("KickoffSupportPlugin: ERROR - Could not determine actual kickoff taker in tie-break. Defaulting to NOT taking kickoff to be safe.")
                        self.i_am_designated_kickoff_taker = False

        # --- Comprobar si la pelota ha sido tocada DESPUÉS de que comenzara la pausa de kickoff ---
        if ball.latest_touch.time_seconds > self.ball_touch_time_at_kickoff_pause_start + 0.01:
            if not self.ball_touched_after_kickoff_pause_started:
                 self.logger(f"KickoffSupportPlugin: Ball touched post-kickoff-pause (touch time: {ball.latest_touch.time_seconds:.2f} > start: {self.ball_touch_time_at_kickoff_pause_start:.2f}).")
            self.ball_touched_after_kickoff_pause_started = True

        # --- Decidir si el plugin debe estar activo ESTE TICK ---
        should_be_active_this_tick = (
            game_info.is_round_active and
            game_info.is_kickoff_pause and
            self.kickoff_logic_evaluated_this_pause and
            not self.i_am_designated_kickoff_taker and
            not self.ball_touched_after_kickoff_pause_started
        )
        
        self.active = should_be_active_this_tick

        if self.active and not self.was_active_last_tick:
            self.logger("KickoffSupportPlugin: >>> ACTIVATED <<< (Plugin will control).") # Changed log message slightly for clarity
        elif not self.active and self.was_active_last_tick:
            self.logger("KickoffSupportPlugin: >>> DEACTIVATED <<< (Returning control).")
        self.was_active_last_tick = self.active


    def controller_filter(self, controller: SimpleControllerState) -> SimpleControllerState:
        if self.active:
            override_controller = SimpleControllerState()
            # The original plugin code would make the bot drive forward.
            # Assuming if I'm NOT the designated kickoff taker, I should probably stay put or do a defensive maneuver.
            # For simplicity, if plugin is active (meaning I am NOT going for kickoff), let's just do nothing.
            # The main bot logic would then take over after the kickoff pause if this plugin deactivates.
            # If the intent is for *this plugin* to drive *away* from kickoff, that's different.
            # The original description "Advancing to ball" was when active, but it should be "NOT advancing to ball".
            # Based on the logic, if self.active is True, it means I AM NOT the designated kicker.
            # So, the original controller_filter was likely a placeholder or had a misunderstanding.
            # If I'm not the kicker, I should probably do nothing or a specific "don't go for kickoff" action.
            # Let's make it do nothing for now, which is what returning an empty SimpleControllerState effectively does (no inputs).
            override_controller.throttle = 1.0 
            override_controller.steer = 0.0
            override_controller.pitch = 0.0
            override_controller.yaw = 0.0
            override_controller.roll = 0.0
            override_controller.jump = False
            override_controller.boost = False
            override_controller.handbrake = False 
            # self.logger("KickoffSupportPlugin: Active and NOT taker. Overriding controls to idle.") # Potentially spammy
            return override_controller
        
        return controller

    def initialize(self):
        self.logger("KickoffSupportPlugin: Initialized method called.")

    def shutdown(self):
        self.logger("KickoffSupportPlugin: Shutdown method called.")