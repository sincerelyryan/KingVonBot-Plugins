# UnifiedAllInOnePlugin.py
# All-in-one: Kickoff, Nexto Switch, Air Dribble, Ball-over-Demo, Team Coordinator (all merged inline),
#             Small Boost (our half), optional 11 2's (Air Assist, Maintain Supersonic).
#
# YOU ONLY NEED:
#   - This file (UnifiedAllInOnePlugin.py)
#   - nexto_core/ folder (bot.py, agent.py, nexto_obs.py, etc. — required for Nexto)
# OPTIONAL: "11 2's plugin pack"/ for MaintainSupersonicPlugin.py and AirAssistPluginV6.
# No other plugin .py files required (Kickoff, Ball Priority, Nexto Switch, Team Coordinator, Air Dribble are merged here).

import math
import os
import sys
import time
import threading
import collections
import importlib.util
import traceback
import urllib.request
import zipfile
import shutil
import numpy as np
from rlbot.agents.base_agent import SimpleControllerState


# --- Air Dribble (merged): orientation helper used by controller_filter ---
class _Vec3:
    __slots__ = ("x", "y", "z")

    def __init__(self, x=0, y=0, z=0):
        if hasattr(x, "x"):
            self.x = float(x.x)
            self.y = float(getattr(x, "y", 0))
            self.z = float(getattr(x, "z", 0))
        else:
            self.x, self.y, self.z = float(x), float(y), float(z)

    def dot(self, other):
        return self.x * other.x + self.y * other.y + self.z * other.z


class _Orientation:
    def __init__(self, rotation):
        yaw, roll, pitch = float(rotation.yaw), float(rotation.roll), float(rotation.pitch)
        cr, sr = math.cos(roll), math.sin(roll)
        cp, sp = math.cos(pitch), math.sin(pitch)
        cy, sy = math.cos(yaw), math.sin(yaw)
        self.forward = _Vec3(cp * cy, cp * sy, sp)
        self.right = _Vec3(cy * sp * sr - cr * sy, sy * sp * sr + cr * cy, -cp * sr)
        self.up = _Vec3(-cr * cy * sp - sr * sy, -cr * sy * sp + sr * cy, cp * cr)


class _MergedAirDribble:
    """Air dribble continuation logic (merged from airdribble.py). Aims at top of net."""
    def __init__(self, logger):
        self.logger = logger or print
        self.air_dribble_active = False
        self.latest_packet = None
        self.latest_local_player_index = -1
        self.latest_player_team = -1
        self.pending_air_dribble_ticks = 0
        self.MIN_CONSECUTIVE_TICKS_FOR_ACTIVATION = 20
        self.config_air_dribble_min_car_height = 250.0
        self.config_air_dribble_min_ball_height = 300.0
        self.config_air_dribble_max_dist_to_ball = 180.0
        self.config_air_dribble_min_facing_angle_to_ball = 0.8
        self.config_air_dribble_max_relative_speed = 350.0
        self.config_air_dribble_min_boost = 15
        self.config_air_dribble_ball_horizontal_speed_min_to_goal = 300
        self.PUSH_STRENGTH_SCALAR = 20.0
        self.BOOST_MAX_PITCH_ERROR = 0.35
        self.BOOST_MAX_YAW_ERROR = 0.35
        self.BOOST_CUTOFF_DIST_TO_BALL = 200.0
        self.REBOUND_BOOST_CUTOFF_DIST_TO_BALL = 280.0
        self.BOOST_CUTOFF_DIST_TO_TARGET = 160.0
        self.BOOST_CUTOFF_DIST_TO_GOAL = 2200.0
        self.GOAL_PROXIMITY_FOR_TARGET_ADJUST = 1500.0
        self.DEFAULT_TARGET_OFFSET_Z = -25.0
        self.NEAR_GOAL_TARGET_OFFSET_Z = 10.0
        self.GOAL_PROXIMITY_FOR_PUSH_REDUCTION = 2000.0
        self.MIN_PUSH_STRENGTH_NEAR_GOAL = 10.0
        self.GOAL_TARGET_Z = 195.0
        self.THROTTLE_REDUCTION_DIST_TO_GOAL = 1200.0
        self.THROTTLE_NEAR_GOAL_MAX = 0.15
        self.REBOUND_SETUP_OFFSET_Z = -60.0

    def initialize(self):
        pass

    def _is_air_dribble_continuation(self, packet, local_player_index):
        try:
            if not packet or not getattr(packet, "game_ball", None) or not getattr(packet, "num_cars", 0) or local_player_index >= packet.num_cars:
                return False
            our_player = packet.game_cars[local_player_index]
            ball_physics = packet.game_ball.physics
            if not all(hasattr(our_player, a) for a in ("physics", "is_demolished", "has_wheel_contact", "boost", "team")):
                return False
            if not all(hasattr(our_player.physics, a) for a in ("location", "velocity", "rotation")):
                return False
            if not all(hasattr(ball_physics, a) for a in ("location", "velocity")):
                return False
        except (AttributeError, IndexError):
            return False
        self.latest_player_team = our_player.team
        if our_player.is_demolished or our_player.has_wheel_contact:
            return False
        car_loc = our_player.physics.location
        car_rot = our_player.physics.rotation
        ball_loc = ball_physics.location
        ball_vel = ball_physics.velocity
        car_location_np = np.array([car_loc.x, car_loc.y, car_loc.z])
        ball_location_np = np.array([ball_loc.x, ball_loc.y, ball_loc.z])
        ball_velocity_np = np.array([ball_vel.x, ball_vel.y, ball_vel.z])
        if car_location_np[2] < self.config_air_dribble_min_car_height or ball_location_np[2] < self.config_air_dribble_min_ball_height:
            return False
        if np.linalg.norm(car_location_np - ball_location_np) > self.config_air_dribble_max_dist_to_ball:
            return False
        car_vel = our_player.physics.velocity
        car_velocity_np = np.array([car_vel.x, car_vel.y, car_vel.z])
        if np.linalg.norm(car_velocity_np - ball_velocity_np) > self.config_air_dribble_max_relative_speed:
            return False
        car_forward = np.array([
            math.cos(car_rot.pitch) * math.cos(car_rot.yaw),
            math.cos(car_rot.pitch) * math.sin(car_rot.yaw),
            math.sin(car_rot.pitch),
        ])
        car_to_ball = ball_location_np - car_location_np
        n = np.linalg.norm(car_to_ball)
        car_to_ball_n = car_to_ball / (n + 1e-6)
        if np.dot(car_forward, car_to_ball_n) < self.config_air_dribble_min_facing_angle_to_ball:
            return False
        if our_player.boost < self.config_air_dribble_min_boost:
            return False
        opp_goal_y = 5120 if our_player.team == 0 else -5120
        ball_speed_to_goal = np.dot(ball_velocity_np[:2], np.array([0, np.sign(opp_goal_y)]))
        if ball_speed_to_goal < self.config_air_dribble_ball_horizontal_speed_min_to_goal:
            return False
        return True

    def game_tick_packet_set(self, packet, local_player_index, playername):
        self.latest_packet = packet
        self.latest_local_player_index = local_player_index
        try:
            if self._is_air_dribble_continuation(packet, local_player_index):
                if not self.air_dribble_active:
                    self.pending_air_dribble_ticks += 1
                    if self.pending_air_dribble_ticks >= self.MIN_CONSECUTIVE_TICKS_FOR_ACTIVATION:
                        self.air_dribble_active = True
                        self.pending_air_dribble_ticks = 0
            else:
                self.air_dribble_active = False
                self.pending_air_dribble_ticks = 0
        except Exception:
            self.air_dribble_active = False
        return None

    def controller_filter(self, controller_input):
        if not self.air_dribble_active or not self.latest_packet or self.latest_local_player_index < 0:
            return controller_input
        try:
            packet = self.latest_packet
            i = self.latest_local_player_index
            our_player = packet.game_cars[i]
            ball_physics = packet.game_ball.physics
            car_loc_np = np.array([our_player.physics.location.x, our_player.physics.location.y, our_player.physics.location.z])
            ball_loc_np = np.array([ball_physics.location.x, ball_physics.location.y, ball_physics.location.z])
            opponent_goal_y = 5120 if self.latest_player_team == 0 else -5120
            opponent_goal_center = np.array([0, opponent_goal_y, self.GOAL_TARGET_Z])
            dist_to_opponent_goal = np.linalg.norm(opponent_goal_center - car_loc_np)
            current_target_offset_z = self.NEAR_GOAL_TARGET_OFFSET_Z if dist_to_opponent_goal < self.GOAL_PROXIMITY_FOR_TARGET_ADJUST else self.DEFAULT_TARGET_OFFSET_Z
            target_offset_under_ball = np.array([0, 0, current_target_offset_z])
            direction_ball_to_goal = opponent_goal_center - ball_loc_np
            norm_ball_to_goal_dir = direction_ball_to_goal / (np.linalg.norm(direction_ball_to_goal) + 1e-6)
            current_push_strength = self.PUSH_STRENGTH_SCALAR
            push_influence_vector = norm_ball_to_goal_dir * current_push_strength
            target_contact_point_on_ball = (ball_loc_np + target_offset_under_ball) - push_influence_vector
            ball_vel_np = np.array([ball_physics.velocity.x, ball_physics.velocity.y, ball_physics.velocity.z])
            opponent_goal_y_abs = 5120.0
            ball_is_on_backboard = abs(ball_loc_np[1]) > opponent_goal_y_abs and abs(ball_loc_np[1]) < opponent_goal_y_abs + 200.0
            is_actually_rebounding = ball_is_on_backboard and (ball_vel_np[1] * opponent_goal_y < 0) and abs(ball_vel_np[1]) > 50.0
            if is_actually_rebounding:
                target_contact_point_on_ball = ball_loc_np + np.array([0, 0, self.REBOUND_SETUP_OFFSET_Z])
            else:
                if dist_to_opponent_goal < self.GOAL_PROXIMITY_FOR_PUSH_REDUCTION:
                    scale = max(0, dist_to_opponent_goal / self.GOAL_PROXIMITY_FOR_PUSH_REDUCTION)
                    current_push_strength = self.MIN_PUSH_STRENGTH_NEAR_GOAL + (self.PUSH_STRENGTH_SCALAR - self.MIN_PUSH_STRENGTH_NEAR_GOAL) * scale
                push_influence_vector = norm_ball_to_goal_dir * current_push_strength
                target_contact_point_on_ball = (ball_loc_np + target_offset_under_ball) - push_influence_vector
            car_to_target_vec = target_contact_point_on_ball - car_loc_np
            ori = _Orientation(our_player.physics.rotation)
            car_forward_np = np.array([ori.forward.x, ori.forward.y, ori.forward.z])
            car_right_np = np.array([ori.right.x, ori.right.y, ori.right.z])
            car_up_np = np.array([ori.up.x, ori.up.y, ori.up.z])
            local_target_y = np.dot(car_to_target_vec, car_forward_np)
            local_target_x = np.dot(car_to_target_vec, car_right_np)
            local_target_z = np.dot(car_to_target_vec, car_up_np)
            P_PITCH, P_YAW, P_ROLL = 2.5, 3.2, 2.0
            pitch_error = math.atan2(local_target_z, local_target_y + 1e-6)
            yaw_error = math.atan2(local_target_x, local_target_y + 1e-6)
            controls_pitch = np.clip(-P_PITCH * pitch_error, -1.0, 1.0)
            controls_yaw = np.clip(P_YAW * yaw_error, -1.0, 1.0)
            controls_roll = np.clip(-P_ROLL * our_player.physics.rotation.roll, -1.0, 1.0)
            should_boost = local_target_y > 0 and abs(pitch_error) < self.BOOST_MAX_PITCH_ERROR and abs(yaw_error) < self.BOOST_MAX_YAW_ERROR
            dist_car_to_ball = np.linalg.norm(ball_loc_np - car_loc_np)
            ball_cutoff = self.REBOUND_BOOST_CUTOFF_DIST_TO_BALL if is_actually_rebounding else self.BOOST_CUTOFF_DIST_TO_BALL
            if dist_car_to_ball < ball_cutoff or np.linalg.norm(target_contact_point_on_ball - car_loc_np) < self.BOOST_CUTOFF_DIST_TO_TARGET or dist_to_opponent_goal < self.BOOST_CUTOFF_DIST_TO_GOAL:
                should_boost = False
            current_throttle = self.THROTTLE_NEAR_GOAL_MAX if dist_to_opponent_goal < self.THROTTLE_REDUCTION_DIST_TO_GOAL else 1.0
            return SimpleControllerState(steer=0.0, throttle=current_throttle, pitch=controls_pitch, yaw=controls_yaw, roll=controls_roll, jump=False, boost=should_boost, handbrake=False)
        except Exception as e:
            self.logger(f"[Unified All-In-One] AirDribble controller_filter error: {e}")
            return controller_input

    def is_active(self):
        return self.air_dribble_active


def _load_plugin_class(plugin_dir, filename, class_name):
    """Load a plugin class from a .py file in the same folder."""
    path = os.path.join(plugin_dir, filename)
    if not os.path.exists(path):
        return None
    try:
        spec = importlib.util.spec_from_file_location(
            filename.replace(".", "_").replace(" ", "_")[:-3], path
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return getattr(mod, class_name)
    except Exception:
        return None


# --- Merged Kickoff (from KickoffSupportPluginV3) ---
_KICKOFF_CHEAT_ALLOWANCE_SQ = 1300000.0
_BALL_REST_SPEED_THRESHOLD = 60.0
_BALL_KICKOFF_POS_X_TOLERANCE = 10.0
_BALL_KICKOFF_POS_Y_TOLERANCE = 10.0
_BALL_KICKOFF_POS_Z_MIN = 90.0
_BALL_KICKOFF_POS_Z_MAX = 95.0


class _MergedKickoff:
    def __init__(self, logger):
        self.logger = logger or print
        self.active = False
        self.was_active_last_tick = False
        self.kickoff_logic_evaluated_this_pause = False
        self.i_am_designated_kickoff_taker = False
        self.ball_touched_after_kickoff_pause_started = False
        self.ball_touch_time_at_kickoff_pause_start = 0.0

    def _is_ball_in_kickoff_position(self, packet):
        ball_loc = packet.game_ball.physics.location
        return (
            abs(ball_loc.x) < _BALL_KICKOFF_POS_X_TOLERANCE
            and abs(ball_loc.y) < _BALL_KICKOFF_POS_Y_TOLERANCE
            and _BALL_KICKOFF_POS_Z_MIN < ball_loc.z < _BALL_KICKOFF_POS_Z_MAX
        )

    def _is_ball_at_rest(self, packet):
        ball_vel = packet.game_ball.physics.velocity
        return math.hypot(ball_vel.x, ball_vel.y, ball_vel.z) < _BALL_REST_SPEED_THRESHOLD

    def game_tick_packet_set(self, packet, local_player_index, playername, **kwargs):
        game_info = packet.game_info
        my_car_info = packet.game_cars[local_player_index]
        ball = packet.game_ball
        if my_car_info.spawn_id == -1:
            self.active = False
            self.kickoff_logic_evaluated_this_pause = False
            return
        if not game_info.is_round_active or not game_info.is_kickoff_pause:
            self.active = False
            self.kickoff_logic_evaluated_this_pause = False
            return
        if not self.kickoff_logic_evaluated_this_pause:
            self.kickoff_logic_evaluated_this_pause = True
            self.ball_touched_after_kickoff_pause_started = False
            self.ball_touch_time_at_kickoff_pause_start = ball.latest_touch.time_seconds
            if not self._is_ball_in_kickoff_position(packet) or not self._is_ball_at_rest(packet):
                self.i_am_designated_kickoff_taker = True
            else:
                ball_pos_2d = (ball.physics.location.x, ball.physics.location.y)
                potential_kickoff_takers_data = []
                for i in range(packet.num_cars):
                    car_candidate = packet.game_cars[i]
                    if car_candidate.spawn_id != -1 and car_candidate.team == my_car_info.team and not car_candidate.is_demolished:
                        car_loc_2d = (car_candidate.physics.location.x, car_candidate.physics.location.y)
                        dist_sq = (car_loc_2d[0] - ball_pos_2d[0]) ** 2 + (car_loc_2d[1] - ball_pos_2d[1]) ** 2
                        potential_kickoff_takers_data.append({"car": car_candidate, "dist_sq": dist_sq})
                teammates_for_kickoff_decision = []
                if not potential_kickoff_takers_data:
                    self.i_am_designated_kickoff_taker = True
                else:
                    min_dist_sq_found = min(p["dist_sq"] for p in potential_kickoff_takers_data)
                    for p_data in potential_kickoff_takers_data:
                        if p_data["dist_sq"] < min_dist_sq_found + _KICKOFF_CHEAT_ALLOWANCE_SQ:
                            teammates_for_kickoff_decision.append(p_data["car"])
                if not teammates_for_kickoff_decision:
                    self.i_am_designated_kickoff_taker = True
                elif len(teammates_for_kickoff_decision) == 1:
                    kt_name = teammates_for_kickoff_decision[0].name if hasattr(teammates_for_kickoff_decision[0], "name") and teammates_for_kickoff_decision[0].name else ""
                    self.i_am_designated_kickoff_taker = (kt_name == playername)
                else:
                    if my_car_info.team == 0:
                        sorted_players = sorted(teammates_for_kickoff_decision, key=lambda c: c.physics.location.x, reverse=True)
                    else:
                        sorted_players = sorted(teammates_for_kickoff_decision, key=lambda c: c.physics.location.x)
                    if sorted_players:
                        actual_kickoff_taker = sorted_players[0]
                        self.i_am_designated_kickoff_taker = (actual_kickoff_taker.spawn_id == my_car_info.spawn_id)
                    else:
                        self.i_am_designated_kickoff_taker = True
        if ball.latest_touch.time_seconds > self.ball_touch_time_at_kickoff_pause_start + 0.01:
            self.ball_touched_after_kickoff_pause_started = True
        should_be_active_this_tick = (
            game_info.is_round_active
            and game_info.is_kickoff_pause
            and self.kickoff_logic_evaluated_this_pause
            and not self.i_am_designated_kickoff_taker
            and not self.ball_touched_after_kickoff_pause_started
        )
        self.active = should_be_active_this_tick
        self.was_active_last_tick = self.active

    def controller_filter(self, controller):
        if self.active:
            c = SimpleControllerState()
            c.throttle = 1.0
            c.steer = c.pitch = c.yaw = c.roll = 0.0
            c.jump = c.boost = c.handbrake = False
            return c
        return controller

    def initialize(self):
        pass


# --- Merged Ball-over-Demo (from PrioritizeBallOverDemoPluginV2) ---
class _MergedBallPriority:
    def __init__(self, logger):
        self.logger = logger or print
        self.packet = None
        self.index = -1
        self.field_info = None
        self.active_state = "INACTIVE"
        self.LOW_BOOST_THRESHOLD = 20
        self.AERIAL_HEIGHT_THRESHOLD = 300.0
        self.DRIBBLE_MAX_DIST = 190.0
        self.SHOT_DISTANCE_THRESHOLD = 400.0
        self.SHADOW_DISTANCE_BUFFER = 600.0
        self.MIN_BALL_PROXIMITY_OVERRIDE = 400.0
        self.MIN_SPEED_FOR_DEMO_LOGIC = 1400.0
        self.MAX_DIST_OPP_FROM_BALL = 1300.0

    def initialize(self, *args, **kwargs):
        pass

    def game_tick_packet_set(self, packet, local_player_index, playername, field_info):
        self.packet = packet
        self.field_info = field_info
        self.index = local_player_index
        if not self.packet or self.index >= self.packet.num_cars:
            return
        if self.packet.game_ball.latest_touch.player_name == "":
            self.active_state = "KICKOFF"
        else:
            self.active_state = self._determine_best_action()

    def _determine_best_action(self):
        my_car = self.packet.game_cars[self.index]
        ball = self.packet.game_ball
        team_sign = -1 if my_car.team == 0 else 1
        is_on_opponent_half = (team_sign * my_car.physics.location.y) < 0
        is_ball_behind_me = (team_sign * my_car.physics.location.y) < (team_sign * ball.physics.location.y)
        if is_on_opponent_half and is_ball_behind_me:
            return "MUST_ROTATE"
        if self._check_for_imminent_threat():
            return "SAVING"
        if ball.physics.location.z > self.AERIAL_HEIGHT_THRESHOLD:
            return "AERIALING"
        if my_car.boost < self.LOW_BOOST_THRESHOLD:
            return "ROTATING"
        dist_to_ball = self._dist(my_car.physics.location, ball.physics.location)
        if (team_sign * my_car.physics.location.y) > (team_sign * ball.physics.location.y):
            if dist_to_ball < self.DRIBBLE_MAX_DIST:
                return "FLICKING"
            return "ATTACKING"
        return "SHADOWING"

    def controller_filter(self, original_controls):
        if self.active_state in ("INACTIVE", "KICKOFF"):
            return None
        if self.active_state != "SAVING" and self._is_chasing_bad_demo():
            return self._generate_ball_controls()
        return self._generate_tactical_controls()

    def _is_chasing_bad_demo(self):
        car = self.packet.game_cars[self.index]
        speed = math.sqrt(
            car.physics.velocity.x ** 2 + car.physics.velocity.y ** 2 + car.physics.velocity.z ** 2
        )
        if speed < self.MIN_SPEED_FOR_DEMO_LOGIC:
            return False
        ball_loc = self.packet.game_ball.physics.location
        for i in range(self.packet.num_cars):
            opp = self.packet.game_cars[i]
            if opp.team == car.team or opp.is_demolished:
                continue
            dist_to_opp = self._dist(car.physics.location, opp.physics.location)
            if dist_to_opp < 800:
                dist_opp_to_ball = self._dist(opp.physics.location, ball_loc)
                if dist_opp_to_ball > self.MAX_DIST_OPP_FROM_BALL:
                    return True
        return False

    def _generate_ball_controls(self):
        c = SimpleControllerState()
        c.steer = self._steer_toward(self.packet.game_ball.physics.location)
        c.throttle = 1.0
        return c

    def _steer_toward(self, target):
        car = self.packet.game_cars[self.index]
        tx, ty = getattr(target, "x", target[0]), getattr(target, "y", target[1])
        to_x = tx - car.physics.location.x
        to_y = ty - car.physics.location.y
        angle = math.atan2(to_y, to_x) - car.physics.rotation.yaw
        while angle > math.pi:
            angle -= 2 * math.pi
        while angle < -math.pi:
            angle += 2 * math.pi
        return max(-1.0, min(1.0, angle * 4.0))

    def _dist(self, v1, v2):
        return math.sqrt((v1.x - v2.x) ** 2 + (v1.y - v2.y) ** 2 + (v1.z - v2.z) ** 2)


# Patch: _check_for_imminent_threat (simple distance to own goal).
def _patch_ball_priority_threat(cls):
    def _check_for_imminent_threat(self):
        car = self.packet.game_cars[self.index]
        team_sign = -1 if car.team == 0 else 1
        own_goal_y = -5120 * team_sign
        bl = self.packet.game_ball.physics.location
        return math.sqrt(bl.x ** 2 + (bl.y - own_goal_y) ** 2 + (bl.z - 100) ** 2) < 2500
    cls._check_for_imminent_threat = _check_for_imminent_threat


_patch_ball_priority_threat(_MergedBallPriority)


# _generate_tactical_controls uses target that might be Vec3 - ensure _steer_toward accepts it. Ball priority uses target.x, target.y; our _Vec3 has x,y,z. For "target = type(ball_loc)(0, -5120 * team_sign, 0)" ball_loc is game_data_struct location so type(ball_loc) might not take 3 args. Use _Vec3 for target when not ball_loc.
def _patch_ball_priority_target(cls):
    def _generate_tactical_controls(self):
        car = self.packet.game_cars[self.index]
        ball_loc = self.packet.game_ball.physics.location
        team_sign = -1 if car.team == 0 else 1
        c = SimpleControllerState()
        target = ball_loc
        if self.active_state in ("MUST_ROTATE", "ROTATING"):
            target = _Vec3(0, -5120 * team_sign, 0)
        elif self.active_state == "SHADOWING":
            target = _Vec3(0, -5120 * team_sign, 0)
        c.steer = self._steer_toward(target)
        c.throttle = 1.0
        c.boost = abs(c.steer) < 0.2
        dist = self._dist(car.physics.location, ball_loc)
        if self.active_state == "SAVING" and dist < 600:
            c.jump = True
        elif self.active_state == "AERIALING" and car.has_wheel_contact:
            c.jump = True
            c.pitch = 1.0
        return c
    cls._generate_tactical_controls = _generate_tactical_controls


_patch_ball_priority_target(_MergedBallPriority)


# --- Merged Team Coordinator (from TeamCoordinator.py); no-op decorator for @condition ---
def _condition_noop(x):
    return lambda f: f


class _MergedTeamCoordinator:
    def __init__(self, logger):
        self.logger = logger or print
        self.Name = "Team Coordinator"
        self.enabled = True
        self.team_stats = {}
        self.last_analysis_time = 0
        self.last_strategy_message = ""

    def initialize(self):
        pass

    def game_tick_packet_set(self, packet, local_player_index, playername, field_info):
        if not self.enabled:
            return None
        if packet.game_info.seconds_elapsed - self.last_analysis_time > 5:
            controls = self._analyze_team_performance(packet, local_player_index)
            self.last_analysis_time = packet.game_info.seconds_elapsed
            return controls
        return None

    def _analyze_team_performance(self, packet, local_player_index):
        if local_player_index >= packet.num_cars:
            return None
        local_team = packet.game_cars[local_player_index].team
        team_stats = {"total_score": 0, "total_goals": 0, "total_saves": 0}
        opponent_stats = {"total_score": 0, "total_goals": 0, "total_saves": 0}
        for i in range(packet.num_cars):
            car = packet.game_cars[i]
            if car.team == local_team:
                team_stats["total_score"] += car.score_info.score
                team_stats["total_goals"] += car.score_info.goals
                team_stats["total_saves"] += car.score_info.saves
            else:
                opponent_stats["total_score"] += car.score_info.score
                opponent_stats["total_goals"] += car.score_info.goals
                opponent_stats["total_saves"] += car.score_info.saves
        return self._provide_strategic_advice(team_stats, opponent_stats, packet, local_player_index)

    def _provide_strategic_advice(self, team_stats, opponent_stats, packet, local_player_index):
        score_diff = team_stats["total_score"] - opponent_stats["total_score"]
        time_remaining_seconds = packet.game_info.game_time_remaining
        strategy_message = ""
        controls = None
        if time_remaining_seconds < 60 and score_diff < -50:
            strategy_message = f"CRITICAL: Less than 1 minute remaining ({time_remaining_seconds:.0f}s) - all-out attack!"
            controls = self._get_aggressive_controls(packet, local_player_index)
        elif time_remaining_seconds < 30 and score_diff > 50:
            strategy_message = f"DEFENSIVE: Less than 30s remaining ({time_remaining_seconds:.0f}s) - protect the lead!"
            controls = self._get_defensive_controls(packet, local_player_index)
        elif score_diff > 200:
            strategy_message = "WINNING: Maintain defensive positioning."
            controls = self._get_balanced_controls(packet, local_player_index)
        elif score_diff < -200:
            strategy_message = "LOSING: Increase offensive pressure."
            controls = self._get_aggressive_controls(packet, local_player_index)
        else:
            strategy_message = f"CLOSE GAME: Time {time_remaining_seconds / 60.0:.1f}m"
            controls = self._get_balanced_controls(packet, local_player_index)
        if strategy_message != self.last_strategy_message:
            self.logger(f"[{self.Name}] {strategy_message}")
            self.last_strategy_message = strategy_message
        return controls

    def _get_aggressive_controls(self, packet, local_player_index):
        if local_player_index >= packet.num_cars:
            return None
        local_car = packet.game_cars[local_player_index]
        ball = packet.game_ball.physics.location
        car_pos = local_car.physics.location
        ball_distance = math.sqrt((ball.x - car_pos.x) ** 2 + (ball.y - car_pos.y) ** 2 + (ball.z - car_pos.z) ** 2)
        if ball_distance < 2000 and local_car.boost > 20:
            c = SimpleControllerState()
            c.throttle = 1.0
            c.boost = True
            return c
        return None

    def _get_defensive_controls(self, packet, local_player_index):
        if local_player_index >= packet.num_cars:
            return None
        car_pos = packet.game_cars[local_player_index].physics.location
        if abs(car_pos.y) > 3000:
            c = SimpleControllerState()
            c.throttle = 0.5
            c.boost = False
            return c
        return None

    def _get_balanced_controls(self, packet, local_player_index):
        if local_player_index >= packet.num_cars:
            return None
        if packet.game_cars[local_player_index].boost < 20:
            c = SimpleControllerState()
            c.boost = False
            return c
        return None


# --- Merged Nexto Switch (from NextoSwitchPluginNEWEST); requires nexto_core/ folder ---
_NEXTO_PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
_NEXTO_CORE_DIR = os.path.join(_NEXTO_PLUGIN_DIR, "nexto_core")
if os.environ.get("LOCALAPPDATA"):
    _alt = os.path.join(os.environ["LOCALAPPDATA"], "vutrium", "sparkline", "plugins", "nexto_core")
    if os.path.exists(_alt):
        _NEXTO_CORE_DIR = _alt
if _NEXTO_PLUGIN_DIR not in sys.path:
    sys.path.insert(0, _NEXTO_PLUGIN_DIR)
if _NEXTO_CORE_DIR not in sys.path:
    sys.path.insert(0, _NEXTO_CORE_DIR)
if os.path.dirname(_NEXTO_CORE_DIR) not in sys.path:
    sys.path.insert(0, os.path.dirname(_NEXTO_CORE_DIR))


def _download_nexto_core(logger):
    """Download nexto_core.zip to plugin dir or LOCALAPPDATA. Returns (True, path) or (False, None)."""
    try:
        url = "https://github.com/NeedlessPage819/NeedlessPage819/releases/download/release/nexto_core.zip"
        target_dir = _NEXTO_PLUGIN_DIR
        if os.environ.get("LOCALAPPDATA"):
            target_dir = os.path.join(os.environ["LOCALAPPDATA"], "vutrium", "sparkline", "plugins")
        os.makedirs(target_dir, exist_ok=True)
        zip_path = os.path.join(target_dir, "nexto_core.zip")
        nexto_dir = os.path.join(target_dir, "nexto_core")
        if os.path.exists(nexto_dir) and not os.path.exists(os.path.join(nexto_dir, "bot.py")):
            shutil.rmtree(nexto_dir, ignore_errors=True)
        if not os.path.exists(nexto_dir) or not os.path.exists(os.path.join(nexto_dir, "bot.py")):
            logger("[Unified] Downloading nexto_core...")
            urllib.request.urlretrieve(url, zip_path)
            if os.path.exists(zip_path):
                if os.path.exists(nexto_dir):
                    shutil.rmtree(nexto_dir, ignore_errors=True)
                os.makedirs(nexto_dir, exist_ok=True)
                with zipfile.ZipFile(zip_path, "r") as z:
                    z.extractall(target_dir)
                os.remove(zip_path)
                if os.path.exists(os.path.join(nexto_dir, "bot.py")):
                    return True, nexto_dir
                return False, None
            return False, None
        return True, nexto_dir
    except Exception as e:
        logger(f"[Unified] nexto_core download error: {e}")
        return False, None


class _NextoDummyVec3:
    def __init__(self, x, y, z):
        self.x, self.y, self.z = float(x), float(y), float(z)


class _NextoDummyGoalInfo:
    def __init__(self, team_num, location_vec3, width=1786.0, height=642.0, depth=880.0):
        self.team_num = int(team_num)
        self.location = location_vec3
        self.width, self.height, self.depth = float(width), float(height), float(depth)


class _NextoDummyBoostPad:
    def __init__(self, location_vec3, is_full_boost):
        self.location = location_vec3
        self.is_full_boost = bool(is_full_boost)


class _NextoAdaptiveFieldInfo:
    def __init__(self, live_field_info_packet=None):
        self.live_field_info_packet = live_field_info_packet
        self.num_boosts = 0
        self.boost_pads = []
        self._boost_locations = np.empty((0, 3), dtype=np.float32)
        self.goals = []
        self._setup_boost_pads()
        self._setup_goals()

    def _setup_goals(self):
        if self.live_field_info_packet and getattr(self.live_field_info_packet, "num_goals", 0) > 0:
            for i in range(self.live_field_info_packet.num_goals):
                g = self.live_field_info_packet.goals[i]
                loc = _NextoDummyVec3(g.location.x, g.location.y, g.location.z)
                self.goals.append(_NextoDummyGoalInfo(g.team_num, loc, getattr(g, "width", 1786), getattr(g, "height", 642)))
        else:
            self.goals.append(_NextoDummyGoalInfo(0, _NextoDummyVec3(0, -5120, 321.3875)))
            self.goals.append(_NextoDummyGoalInfo(1, _NextoDummyVec3(0, 5120, 321.3875)))

    def _setup_boost_pads(self):
        pads = [(3584, 4096, 73), (-3584, 4096, 73), (3584, -4096, 73), (-3584, -4096, 73), (0, 4240, 73), (0, -4240, 73), (3072, 0, 73), (-3072, 0, 73), (0, -2816, 73), (0, -1024, 73), (0, 0, 73), (0, 1024, 73), (0, 2816, 73), (-1792, -4184, 73), (1792, -4184, 73), (-1792, 4184, 73), (1792, 4184, 73), (-3584, -2484, 73), (3584, -2484, 73), (-3584, 2484, 73), (3584, 2484, 73), (-2048, -3072, 73), (2048, -3072, 73), (-2048, 3072, 73), (2048, 3072, 73), (-940, -1036, 73), (940, -1036, 73), (-940, 1036, 73), (940, 1036, 73), (-2048, -1036, 73), (2048, -1036, 73), (-2048, 1036, 73), (2048, 1036, 73), (-1024, -4240, 73)]
        raw = []
        if self.live_field_info_packet and getattr(self.live_field_info_packet, "num_boosts", 0) > 0:
            self.num_boosts = self.live_field_info_packet.num_boosts
            for i in range(self.live_field_info_packet.num_boosts):
                p = self.live_field_info_packet.boost_pads[i]
                loc = _NextoDummyVec3(p.location.x, p.location.y, p.location.z)
                self.boost_pads.append(_NextoDummyBoostPad(loc, p.is_full_boost))
                raw.append((loc.x, loc.y, loc.z))
        else:
            self.num_boosts = len(pads)
            for x, y, z in pads:
                loc = _NextoDummyVec3(x, y, z)
                self.boost_pads.append(_NextoDummyBoostPad(loc, abs(x) >= 3072 or (x == 0 and abs(y) >= 4096)))
                raw.append((x, y, z))
        self._boost_locations = np.array(raw, dtype=np.float32) if raw else np.empty((0, 3), dtype=np.float32)

    @property
    def boost_locations(self):
        if self._boost_locations.size == 0:
            return np.zeros((2, 1, 0, 3), dtype=np.float32)
        n = 34
        cur = self._boost_locations.shape[0]
        if cur == n:
            locs = self._boost_locations
        elif cur > n:
            locs = self._boost_locations[:n, :]
        else:
            locs = np.vstack((self._boost_locations, np.zeros((n - cur, 3), dtype=np.float32)))
        out = np.zeros((2, 1, n, 3), dtype=np.float32)
        out[0, 0, :] = out[1, 0, :] = locs
        return out

    @property
    def field_size(self):
        return (8192, 10240, 2044)


class _MergedNextoSwitch:
    """Nexto switch logic merged from NextoSwitchPluginNEWEST. Needs nexto_core/ in plugin dir."""
    def __init__(self, logger, plugin_dir):
        self.logger = logger or print
        self._plugin_dir = plugin_dir
        self._nexto_core_dir = _NEXTO_CORE_DIR
        self.nexto_instance = None
        self.nexto_agent_active = False
        self._nexto_initialized_for_player_key = None
        self.live_field_info = None
        self.field_info = None
        self.dribble_stop_timestamp = 0
        self.dribble_cooldown_duration = 1.5
        self.activated_for_dribble = False
        self.BOLD, self.GREEN, self.RED, self.YELLOW, self.BLUE, self.RESET = "\033[1m", "\033[92m", "\033[91m", "\033[93m", "\033[94m", "\033[0m"
        self.config_min_ball_height_above_car = 30.0
        self.config_max_ball_height_above_car = 220.0
        self.config_max_horizontal_offset = 160.0
        self.config_max_relative_speed_for_dribble = 350.0
        self.config_max_car_height = 100.0
        self.opponent_was_dribbling = False
        self.we_were_dribbling = False
        self.dribble_confirmation_time = 0.05
        self.opponent_dribble_start_time = 0
        self.our_dribble_start_time = 0
        self.current_player_index = -1
        self.current_player_team = -1
        self.last_game_tick_packet = None
        self.clock_thread = None
        self.clock_running = False
        self.clock_initialized = False
        self.smoothing_window_size = 5
        self.steer_history = collections.deque(maxlen=self.smoothing_window_size)
        self.throttle_history = collections.deque(maxlen=self.smoothing_window_size)
        self.pitch_history = collections.deque(maxlen=self.smoothing_window_size)
        self.yaw_history = collections.deque(maxlen=self.smoothing_window_size)
        self.roll_history = collections.deque(maxlen=self.smoothing_window_size)
        self.NextoBotClass = None
        try:
            try:
                from nexto_core.bot import Nexto as _NextoClass
                self.NextoBotClass = _NextoClass
            except Exception:
                result, path = _download_nexto_core(self.logger)
                if result and path:
                    if os.path.dirname(path) not in sys.path:
                        sys.path.insert(0, os.path.dirname(path))
                    if "nexto_core.bot" in sys.modules:
                        del sys.modules["nexto_core.bot"]
                    from nexto_core.bot import Nexto as _NextoClass
                    self.NextoBotClass = _NextoClass
                else:
                    bot_path = os.path.join(self._nexto_core_dir, "bot.py")
                    if os.path.exists(bot_path):
                        spec = importlib.util.spec_from_file_location("nexto_bot", bot_path)
                        mod = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(mod)
                        self.NextoBotClass = mod.Nexto
        except Exception as e:
            self.logger(f"[Unified] Nexto import failed: {e}")
            self.NextoBotClass = None

    def Name(self):
        return "NextoSwitch(merged)"

    def initialize(self):
        pass

    def _clear_smoothing_history(self):
        self.steer_history.clear()
        self.throttle_history.clear()
        self.pitch_history.clear()
        self.yaw_history.clear()
        self.roll_history.clear()

    def start_clock(self):
        if not self.clock_thread or not self.clock_running:
            self.clock_running = True
            self.clock_thread = threading.Thread(target=self._clock_loop)
            self.clock_thread.daemon = True
            self.clock_thread.start()

    def stop_clock(self):
        self.clock_running = False
        self.clock_thread = None

    def _clock_loop(self):
        last_t = 0
        while self.clock_running:
            t = time.time()
            if t - last_t >= 1.0 and self.nexto_instance and self.last_game_tick_packet and self._nexto_initialized_for_player_key:
                try:
                    _ = self.nexto_instance.get_output(self.last_game_tick_packet)
                    self.clock_initialized = True
                except Exception:
                    pass
                last_t = t
            time.sleep(0.1)

    def _initialize_nexto_if_needed(self, packet, local_player_index, player_team):
        if local_player_index < 0 or local_player_index >= packet.num_cars or not self.NextoBotClass:
            return False
        key = (local_player_index, player_team)
        if self.nexto_instance and self._nexto_initialized_for_player_key == key:
            return True
        try:
            name = getattr(packet.game_cars[local_player_index], "name", b"Nexto") or b"Nexto"
            if hasattr(name, "decode"):
                name = name.decode("utf-8", errors="replace")
            self.nexto_instance = self.NextoBotClass(name=name, team=player_team, index=local_player_index, beta=1, render=False, hardcoded_kickoffs=True, stochastic_kickoffs=False)
            self.field_info = _NextoAdaptiveFieldInfo(live_field_info_packet=self.live_field_info)
            self.nexto_instance.initialize_agent(self.field_info)
            self.nexto_instance.tick_skip = 8
            if hasattr(self.nexto_instance, "team_sign"):
                self.nexto_instance.team_sign = 1 if player_team == 0 else -1
            self._nexto_initialized_for_player_key = key
            return True
        except Exception as e:
            self.logger(f"[Unified] Nexto init error: {e}")
            self.nexto_instance = None
            self._nexto_initialized_for_player_key = None
            return False

    def _is_kickoff(self, packet):
        return getattr(packet.game_info, "is_kickoff_pause", False)

    def _is_our_car_dribbling(self, packet, local_player_index):
        if not getattr(packet, "game_ball", None) or local_player_index >= packet.num_cars:
            return False
        our = packet.game_cars[local_player_index]
        if our.is_demolished or (not our.has_wheel_contact and our.physics.location.z > self.config_max_car_height * 1.5):
            return False
        bl = np.array([packet.game_ball.physics.location.x, packet.game_ball.physics.location.y, packet.game_ball.physics.location.z])
        cl = np.array([our.physics.location.x, our.physics.location.y, our.physics.location.z])
        if (cl[1] > 0) != (bl[1] > 0) or cl[2] > self.config_max_car_height * 1.5:
            return False
        rel_z = bl[2] - cl[2]
        if not (self.config_min_ball_height_above_car * 0.8 < rel_z < self.config_max_ball_height_above_car * 1.1):
            return False
        if (bl[0] - cl[0]) ** 2 + (bl[1] - cl[1]) ** 2 >= (self.config_max_horizontal_offset * 1.1) ** 2:
            return False
        cv = np.array([our.physics.velocity.x, our.physics.velocity.y, our.physics.velocity.z])
        bv = np.array([packet.game_ball.physics.velocity.x, packet.game_ball.physics.velocity.y, packet.game_ball.physics.velocity.z])
        if np.linalg.norm(cv - bv) >= self.config_max_relative_speed_for_dribble * 1.1:
            return False
        fwd = np.array([math.cos(our.physics.rotation.yaw), math.sin(our.physics.rotation.yaw), 0])
        to_ball = bl - cl
        to_ball = to_ball / (np.linalg.norm(to_ball) + 1e-6)
        return np.dot(fwd, to_ball) > 0.3

    def _is_opponent_dribbling(self, packet, local_player_team):
        if not getattr(packet, "game_ball", None):
            return False
        bl = np.array([packet.game_ball.physics.location.x, packet.game_ball.physics.location.y, packet.game_ball.physics.location.z])
        our_pos = None
        for i in range(packet.num_cars):
            if packet.game_cars[i].team == local_player_team:
                c = packet.game_cars[i]
                our_pos = np.array([c.physics.location.x, c.physics.location.y, c.physics.location.z])
                break
        if our_pos is None:
            return False
        for i in range(packet.num_cars):
            p = packet.game_cars[i]
            if p.team == local_player_team or p.is_demolished:
                continue
            cl = np.array([p.physics.location.x, p.physics.location.y, p.physics.location.z])
            if (cl[1] > 0) != (our_pos[1] > 0) or cl[2] > self.config_max_car_height * 1.5:
                continue
            rel_z = bl[2] - cl[2]
            if not (self.config_min_ball_height_above_car < rel_z < self.config_max_ball_height_above_car):
                continue
            if (bl[0] - cl[0]) ** 2 + (bl[1] - cl[1]) ** 2 >= 150 ** 2:
                continue
            pv = np.array([p.physics.velocity.x, p.physics.velocity.y, p.physics.velocity.z])
            bv = np.array([packet.game_ball.physics.velocity.x, packet.game_ball.physics.velocity.y, packet.game_ball.physics.velocity.z])
            if np.linalg.norm(pv - bv) >= 350:
                continue
            fwd = np.array([math.cos(p.physics.rotation.yaw), math.sin(p.physics.rotation.yaw), 0])
            to_ball = bl - cl
            to_ball = to_ball / (np.linalg.norm(to_ball) + 1e-6)
            if np.dot(fwd, to_ball) > 0.4:
                return True
        return False

    def _is_near_wall(self, car_pos, car_rotation=None):
        if abs(car_pos[0]) > 8192 - 200 or abs(car_pos[1]) > 10240 - 200:
            return True, "wall"
        return False, None

    def _check_dribble_conditions(self, packet, local_player_index, local_player_team):
        if self._is_kickoff(packet) or local_player_index >= packet.num_cars:
            return False, ""
        t = packet.game_info.seconds_elapsed
        opp_now = self._is_opponent_dribbling(packet, local_player_team)
        we_now = self._is_our_car_dribbling(packet, local_player_index)
        if opp_now:
            if not self.opponent_was_dribbling:
                self.opponent_dribble_start_time = t
            self.opponent_was_dribbling = True
            if t - self.opponent_dribble_start_time >= self.dribble_confirmation_time:
                return True, "opponent dribbling"
        else:
            self.opponent_was_dribbling = False
        if we_now:
            if not self.we_were_dribbling:
                self.our_dribble_start_time = t
            self.we_were_dribbling = True
            if t - self.our_dribble_start_time >= self.dribble_confirmation_time:
                return True, "we are dribbling"
        else:
            self.we_were_dribbling = False
        return False, ""

    def game_tick_packet_set(self, packet, local_player_index, playername, field_info=None):
        if field_info is not None:
            self.live_field_info = field_info
        if local_player_index < 0 or local_player_index >= packet.num_cars:
            if self.nexto_agent_active:
                self.nexto_agent_active = False
                self._clear_smoothing_history()
            return None
        our = packet.game_cars[local_player_index]
        team = our.team
        self.last_game_tick_packet = packet
        if self.current_player_index != local_player_index or self.current_player_team != team:
            self.current_player_index = local_player_index
            self.current_player_team = team
            self.clock_initialized = False
            if self.nexto_instance and self._nexto_initialized_for_player_key != (local_player_index, team):
                self._nexto_initialized_for_player_key = None
        if not self.clock_initialized and self._initialize_nexto_if_needed(packet, local_player_index, team):
            self.start_clock()
        if not our.has_wheel_contact and self.nexto_agent_active:
            return self.nexto_instance.get_output(packet) if self.nexto_instance else None
        if self._is_kickoff(packet):
            return None
        should_act, reason = self._check_dribble_conditions(packet, local_player_index, team)
        t = packet.game_info.seconds_elapsed
        car_pos = np.array([our.physics.location.x, our.physics.location.y, our.physics.location.z])
        near_wall, _ = self._is_near_wall(car_pos, our.physics.rotation.yaw)
        if should_act and not near_wall:
            if not self.nexto_agent_active:
                self.nexto_agent_active = True
                self._clear_smoothing_history()
                self.dribble_stop_timestamp = 0
                self.activated_for_dribble = True
        elif self.nexto_agent_active:
            if not should_act or near_wall or not our.has_wheel_contact:
                if self.dribble_stop_timestamp == 0:
                    self.dribble_stop_timestamp = t
                if (t - self.dribble_stop_timestamp) > self.dribble_cooldown_duration:
                    self.nexto_agent_active = False
                    self._clear_smoothing_history()
                    self.dribble_stop_timestamp = 0
                    self.activated_for_dribble = False
        if self.nexto_agent_active and self.nexto_instance:
            try:
                out = self.nexto_instance.get_output(packet)
                self.steer_history.append(out.steer)
                self.throttle_history.append(out.throttle)
                self.pitch_history.append(out.pitch)
                self.yaw_history.append(out.yaw)
                self.roll_history.append(out.roll)
                smooth = SimpleControllerState(
                    steer=float(np.mean(self.steer_history)),
                    throttle=float(np.mean(self.throttle_history)),
                    pitch=float(np.mean(self.pitch_history)),
                    yaw=float(np.mean(self.yaw_history)),
                    roll=float(np.mean(self.roll_history)),
                    jump=out.jump, boost=out.boost, handbrake=out.handbrake, use_item=getattr(out, "use_item", False),
                )
                return smooth
            except Exception as e:
                self.logger(f"[Unified] Nexto output error: {e}")
                self.nexto_agent_active = False
                self._clear_smoothing_history()
                return None
        return None


class UnifiedAllInOnePlugin:
    def __init__(self, ConsoleLogger=None):
        self.logger = ConsoleLogger or print
        self.name = "Unified All-In-One"
        self._plugin_dir = os.path.dirname(os.path.abspath(__file__))

        # Sub-plugins (loaded lazily or in initialize)
        self._kickoff = None
        self._nexto_switch = None
        self._ball_priority = None
        self._team_coordinator = None
        self._air_dribble = None
        self._air_assist = None
        self._maintain_supersonic = None
        self._pack_dir = os.path.join(self._plugin_dir, "11 2's plugin pack")

        # Overrides from sub-plugins (Nexto / Team Coordinator return controller from game_tick_packet_set)
        self._nexto_override = None
        self._team_coordinator_override = None

        # --- Small boost: our-half only (no crossing midline for pads) ---
        self._small_pads_all = []  # list of {loc, index} for all small pads (from field_info)
        self._small_pads_initialized = False
        self._active_pad_index = None
        self._current_car = None
        self._local_index = -1
        self._packet = None
        self._field_info = None

        # Small boost our-half constants
        self.MAX_BOOST_TO_COLLECT = 88
        self.MAX_DISTANCE_TO_PAD = 1800
        self.MAX_ANGLE_TO_PAD_DEGREES = 45.0
        self.ASSIST_STEER_STRENGTH = 0.25
        self.MIN_MAIN_BOT_STEER_FOR_ASSIST = 0.25
        self.OUR_HALF_MARGIN = 100  # Pads must be this far into our half (avoid midline)

        self._ensure_subplugins()

    def _ensure_subplugins(self):
        if self._kickoff is not None:
            return
        # All merged inline — no external plugin files needed
        self._kickoff = _MergedKickoff(self.logger)
        self._ball_priority = _MergedBallPriority(self.logger)
        self._team_coordinator = _MergedTeamCoordinator(self.logger)
        self._air_dribble = _MergedAirDribble(self.logger)
        # Nexto: load merged Nexto (uses nexto_core/ folder only)
        try:
            self._nexto_switch = _MergedNextoSwitch(self.logger, self._plugin_dir)
        except Exception as e:
            self.logger(f"[{self.name}] Could not load Nexto (merged): {e}")
        # Maintain Supersonic (11 2's pack) - saves boost when supersonic, maintains speed
        try:
            if os.path.exists(os.path.join(self._pack_dir, "MaintainSupersonicPlugin.py")):
                spec_ms = importlib.util.spec_from_file_location(
                    "maintain_supersonic_pack",
                    os.path.join(self._pack_dir, "MaintainSupersonicPlugin.py"),
                )
                mod_ms = importlib.util.module_from_spec(spec_ms)
                spec_ms.loader.exec_module(mod_ms)
                self._maintain_supersonic = mod_ms.MaintainSupersonicPlugin(self.logger)
        except Exception as e:
            self.logger(f"[{self.name}] Could not load MaintainSupersonic (11 2's): {e}")
        # Air Assist (11 2's pack) - aerials, double tap, airdribble, flip reset; uses SharedState
        try:
            if os.path.exists(os.path.join(self._pack_dir, "AirAssistPluginV6_Ultimate_Team_Player.py")):
                import sys
                if self._pack_dir not in sys.path:
                    sys.path.insert(0, self._pack_dir)
                spec_aa = importlib.util.spec_from_file_location(
                    "air_assist_pack",
                    os.path.join(self._pack_dir, "AirAssistPluginV6_Ultimate_Team_Player.py"),
                )
                mod_aa = importlib.util.module_from_spec(spec_aa)
                spec_aa.loader.exec_module(mod_aa)
                self._air_assist = mod_aa.AirAssistPlugin(self.logger)
        except Exception as e:
            self.logger(f"[{self.name}] Could not load AirAssist (11 2's): {e}")
        # Small boost: we implement our-half logic inline (no separate plugin)

    def Name(self):
        return self.name

    def initialize(self):
        self._ensure_subplugins()
        if self._kickoff and hasattr(self._kickoff, "initialize"):
            self._kickoff.initialize()
        if self._nexto_switch and hasattr(self._nexto_switch, "initialize"):
            self._nexto_switch.initialize()
        if self._ball_priority and hasattr(self._ball_priority, "initialize"):
            self._ball_priority.initialize()
        if self._team_coordinator and hasattr(self._team_coordinator, "initialize"):
            self._team_coordinator.initialize()
        if self._air_dribble and hasattr(self._air_dribble, "initialize"):
            self._air_dribble.initialize()
        if self._air_assist and hasattr(self._air_assist, "initialize"):
            self._air_assist.initialize()
        if self._maintain_supersonic and hasattr(self._maintain_supersonic, "initialize"):
            self._maintain_supersonic.initialize()
        parts = ["Kickoff", "Nexto Switch", "Ball-over-Demo", "Small Boost (our half)"]
        if self._team_coordinator:
            parts.insert(-1, "Team Coordinator")
        if self._air_dribble:
            parts.insert(-1, "Air Dribble")
        if self._air_assist:
            parts.insert(-1, "Air Assist")
        if self._maintain_supersonic:
            parts.append("Maintain Supersonic")
        self.logger(f"[{self.name}] Initialized: {', '.join(parts)}.")

    def game_tick_packet_set(self, packet, local_player_index, playername, field_info):
        self._packet = packet
        self._local_index = local_player_index
        self._field_info = field_info
        self._nexto_override = None
        self._team_coordinator_override = None

        if not packet or local_player_index < 0 or local_player_index >= packet.num_cars:
            return

        # 1) Kickoff
        if self._kickoff:
            try:
                self._kickoff.game_tick_packet_set(
                    packet, local_player_index, playername or "", **{}
                )
            except TypeError:
                self._kickoff.game_tick_packet_set(
                    packet, local_player_index, playername or ""
                )

        # 2) Nexto Switch (may return a controller when Nexto is active)
        if self._nexto_switch:
            try:
                out = self._nexto_switch.game_tick_packet_set(
                    packet, local_player_index, playername or "", field_info
                )
                if out is not None and isinstance(out, SimpleControllerState):
                    self._nexto_override = out
            except Exception as e:
                self.logger(f"[{self.name}] Nexto game_tick error: {e}")

        # 3) Prioritize ball over demo
        if self._ball_priority:
            try:
                self._ball_priority.game_tick_packet_set(
                    packet, local_player_index, playername or "", field_info
                )
            except Exception as e:
                self.logger(f"[{self.name}] Ball priority game_tick error: {e}")

        # 4a) Air Dribble (continuation) - detects in-air dribble toward goal
        if self._air_dribble:
            try:
                self._air_dribble.game_tick_packet_set(
                    packet, local_player_index, playername or ""
                )
            except Exception as e:
                self.logger(f"[{self.name}] AirDribble game_tick error: {e}")
        # 4b) Air Assist (11 2's) - sets active_assist_target for aerials / double tap / airdribble / flip reset
        if self._air_assist:
            try:
                self._air_assist.game_tick_packet_set(
                    packet, local_player_index, playername or "", field_info
                )
            except Exception as e:
                self.logger(f"[{self.name}] AirAssist game_tick error: {e}")
        # 5) Maintain Supersonic (11 2's) - track speed/ground for boost filter
        if self._maintain_supersonic:
            try:
                self._maintain_supersonic.game_tick_packet_set(
                    packet, local_player_index, playername or ""
                )
            except Exception as e:
                self.logger(f"[{self.name}] MaintainSupersonic game_tick error: {e}")
        # 6) Team Coordinator (returns controls every ~5s for strategy; e.g. all-out attack / protect lead)
        if self._team_coordinator:
            try:
                out = self._team_coordinator.game_tick_packet_set(
                    packet, local_player_index, playername or "", field_info
                )
                if out is not None and isinstance(out, SimpleControllerState):
                    self._team_coordinator_override = out
            except Exception as e:
                self.logger(f"[{self.name}] TeamCoordinator game_tick error: {e}")

        # 7) Small boost pads on our half only
        self._update_small_boost_our_half(packet, local_player_index, field_info)

    def _update_small_boost_our_half(self, packet, local_player_index, field_info):
        """Pick a small boost pad target only from our half of the map."""
        self._active_pad_index = None
        self._current_car = None
        self._current_car_matrix = None

        if not packet or not field_info or field_info.num_boosts == 0:
            return
        my_car = packet.game_cars[local_player_index]
        if my_car.is_demolished or my_car.boost > self.MAX_BOOST_TO_COLLECT:
            return
        if not my_car.has_wheel_contact or my_car.jumped or my_car.double_jumped:
            return

        # One-time: build list of all small pads (no team filter yet)
        if not self._small_pads_initialized and field_info:
            self._small_pads_all = []
            for i in range(field_info.num_boosts):
                pad = field_info.boost_pads[i]
                if not pad.is_full_boost:
                    self._small_pads_all.append({"loc": pad.location, "index": i})
            self._small_pads_initialized = True

        # Our half: Blue (0) -> y <= -margin, Orange (1) -> y >= margin (don't cross midline)
        our_half_y_max = -self.OUR_HALF_MARGIN if my_car.team == 0 else 1e9
        our_half_y_min = -1e9 if my_car.team == 0 else self.OUR_HALF_MARGIN

        self._current_car = my_car
        my_x = my_car.physics.location.x
        my_y = my_car.physics.location.y
        best_score = -1.0

        # 2D yaw only for steering toward pad
        yaw = my_car.physics.rotation.yaw
        forward = (math.cos(yaw), math.sin(yaw))
        right = (-math.sin(yaw), math.cos(yaw))

        for pad_info in self._small_pads_all:
            idx = pad_info["index"]
            loc = pad_info["loc"]
            y = loc.y
            if my_car.team == 0 and y > our_half_y_max:
                continue
            if my_car.team == 1 and y < our_half_y_min:
                continue
            if not packet.game_boosts[idx].is_active:
                continue
            dx = loc.x - my_x
            dy = loc.y - my_y
            dist = math.sqrt(dx * dx + dy * dy)
            if dist > self.MAX_DISTANCE_TO_PAD or dist < 50:
                continue
            # Angle from car forward (2D)
            dot = dx * forward[0] + dy * forward[1]
            angle_deg = math.degrees(math.acos(max(-1, min(1, dot / (dist + 1e-6)))))
            if angle_deg > self.MAX_ANGLE_TO_PAD_DEGREES:
                continue
            angle_score = (self.MAX_ANGLE_TO_PAD_DEGREES - angle_deg) / self.MAX_ANGLE_TO_PAD_DEGREES
            dist_score = (self.MAX_DISTANCE_TO_PAD - dist) / self.MAX_DISTANCE_TO_PAD
            score = angle_score * 0.7 + dist_score * 0.3
            if score > best_score:
                best_score = score
                self._active_pad_index = idx

    def controller_filter(self, controller: SimpleControllerState) -> SimpleControllerState:
        if controller is None:
            controller = SimpleControllerState()

        # 1) Kickoff: if we're NOT the designated taker, override to stay back
        if self._kickoff and getattr(self._kickoff, "active", False):
            return self._kickoff.controller_filter(controller)

        # 2) Nexto override (when Nexto is active)
        if self._nexto_override is not None:
            return self._nexto_override

        # 3) Air Dribble override (merged inline; aims at goal so ball doesn't land in front for easy save)
        if self._air_dribble and self._air_dribble.is_active():
            try:
                out = self._air_dribble.controller_filter(controller)
                if out is not None:
                    return out
            except Exception as e:
                self.logger(f"[{self.name}] AirDribble controller_filter error: {e}")

        # 4) Air Assist override (when it has an active aerial / double tap / airdribble / flip reset)
        if self._air_assist:
            try:
                out = self._air_assist.controller_filter(controller)
                if out is not None:
                    return out
            except Exception as e:
                self.logger(f"[{self.name}] AirAssist controller_filter error: {e}")

        # 5) Team Coordinator override (e.g. all-out attack / protect lead when time/score says so)
        if self._team_coordinator_override is not None:
            return self._team_coordinator_override

        # 6) Prioritize ball over demo: if we're chasing a bad demo, force ball
        if self._ball_priority and self._packet and self._local_index >= 0:
            filtered = self._ball_priority.controller_filter(controller)
            if filtered is not None:
                return filtered

        # 7) Small boost nudge (our half only) - gentle steer toward nearest small pad
        if (
            self._active_pad_index is not None
            and self._current_car is not None
            and self._packet is not None
            and self._field_info is not None
        ):
            my_car = self._current_car
            pad_loc = self._field_info.boost_pads[self._active_pad_index].location
            my_x = my_car.physics.location.x
            my_y = my_car.physics.location.y
            dx = pad_loc.x - my_x
            dy = pad_loc.y - my_y
            yaw = my_car.physics.rotation.yaw
            forward = (math.cos(yaw), math.sin(yaw))
            right = (-math.sin(yaw), math.cos(yaw))
            local_x = dx * forward[0] + dy * forward[1]
            local_y = dx * right[0] + dy * right[1]
            angle_rad = math.atan2(local_y, local_x) if (local_x != 0 or local_y != 0) else 0
            target_steer = max(-1.0, min(1.0, angle_rad * 2.5))
            if abs(controller.steer) <= self.MIN_MAIN_BOT_STEER_FOR_ASSIST:
                controller.steer = controller.steer * (1.0 - self.ASSIST_STEER_STRENGTH) + target_steer * self.ASSIST_STEER_STRENGTH
                controller.steer = max(-1.0, min(1.0, controller.steer))
            if abs(angle_rad) < math.radians(10) and not controller.boost:
                controller.throttle = max(controller.throttle, 0.5)

        # 8) Maintain Supersonic (11 2's) - cut boost when supersonic, maintain when just below
        if self._maintain_supersonic:
            try:
                controller = self._maintain_supersonic.controller_filter(controller)
            except Exception as e:
                self.logger(f"[{self.name}] MaintainSupersonic controller_filter error: {e}")

        return controller
