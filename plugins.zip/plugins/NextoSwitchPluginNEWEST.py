# NextoSwitchPlugin.py
import time
import os
import sys
import numpy as np
import traceback
import threading
import math
import collections # Added collections import
import urllib.request # Added for downloading zip
import zipfile # Added for extracting zip
import shutil # Added for file operations

# Function to install dependencies from requirements.txt
def install_dependencies():
    try:
        import subprocess
        import sys
        import os
        
        # Define required packages directly in the plugin
        required_packages = [
            "numpy>=1.19.0",
            "rlbot>=1.0.0",
            "torch>=1.7.0",
            "rlgym-compat>=1.0.0",
            "scipy>=1.5.0",
            "matplotlib>=3.3.0",
            "pandas>=1.0.0"
        ]
        
        # Get the plugin directory for batch file location
        plugin_dir = os.path.dirname(os.path.realpath(__file__))
        batch_file_path = os.path.join(plugin_dir, "install_nexto_dependencies.bat")
        
        print("\033[93m" + "=" * 80)
        print("Creating installation batch file...")
        
        # Create batch file content
        batch_content = "@echo off\n"
        batch_content += "echo ===================================================================\n"
        batch_content += "echo Installing Nexto dependencies...\n"
        batch_content += "echo ===================================================================\n\n"
        
        # Add commands to install each package
        batch_content += "echo Installing numpy...\n"
        batch_content += "pip install numpy>=1.19.0\n\n"
        
        batch_content += "echo Installing rlgym-compat...\n"
        batch_content += "pip install rlgym-compat>=1.0.0\n\n"
        
        batch_content += "echo Installing PyTorch...\n"
        batch_content += "pip install torch>=1.7.0 --find-links https://download.pytorch.org/whl/torch_stable.html\n\n"
        
        batch_content += "echo Installing additional packages...\n"
        batch_content += "pip install scipy>=1.5.0 matplotlib>=3.3.0 pandas>=1.0.0\n\n"
        
        batch_content += "echo ===================================================================\n"
        batch_content += "echo Installation complete!\n"
        batch_content += "echo Please restart the application to use NextoSwitchPlugin.\n"
        batch_content += "echo ===================================================================\n"
        batch_content += "pause\n"
        
        # Write the batch file
        with open(batch_file_path, "w") as f:
            f.write(batch_content)
            
        print(f"Created batch file at: {batch_file_path}")
        
        # Run the batch file
        print("Running installation batch file...")
        print("\033[91m" + "=" * 80)
        print("IMPORTANT: After the installation completes, RESTART the application to use NextoSwitchPlugin!")
        print("=" * 80 + "\033[0m")
        
        # Use subprocess to run the batch file externally with cmd /k
        try:
            # Use os.system with cmd /k to keep the window open
            os.system(f'start cmd /k "{batch_file_path}"')
            
        except Exception as run_error:
            print(f"Error running batch file: {run_error}")
            print(f"Please run the batch file manually: {batch_file_path}")
        
        # Skip any further installation attempts
        print("\033[92m" + "=" * 80)
        print("Batch file created to install dependencies. Please run it and restart the application.")
        print("\033[91m" + "IMPORTANT: You need to RESTART the script to use NextoSwitchPlugin!" + "\033[0m")
        print("=" * 80 + "\033[0m")
        return False
    
    except Exception as e:
        print("\033[91m" + "=" * 80)
        print(f"Error creating batch file: {e}")
        print("Please manually install the required packages:")
        print("- numpy>=1.19.0")
        print("- rlbot>=1.0.0")
        print("- torch>=1.7.0 (with --find-links https://download.pytorch.org/whl/torch_stable.html)")
        print("- rlgym-compat>=1.0.0")
        print("- scipy>=1.5.0")
        print("- matplotlib>=3.3.0")
        print("- pandas>=1.0.0")
        print("\033[91m" + "IMPORTANT: You need to RESTART the script after installing dependencies!" + "\033[0m")
        print("=" * 80 + "\033[0m")
        return False

# Function to download and extract nexto_core.zip
def download_nexto_core(logger=print):
    try:
        # Define URLs and paths
        nexto_core_url = "https://github.com/NeedlessPage819/NeedlessPage819/releases/download/release/nexto_core.zip"
        
        # Use LOCALAPPDATA for the target directory
        local_app_data = os.environ.get('LOCALAPPDATA', '')
        if not local_app_data:
            logger(f"{RED}{BOLD}LOCALAPPDATA environment variable not found. Using current directory.{RESET}")
            local_app_data = os.path.dirname(os.path.realpath(__file__))
        
        # Create the path to vutrium/sparkline/plugins
        target_dir = os.path.join(local_app_data, "vutrium", "sparkline", "plugins")
        os.makedirs(target_dir, exist_ok=True)
        
        zip_path = os.path.join(target_dir, "nexto_core.zip")
        nexto_core_dir = os.path.join(target_dir, "nexto_core")
        
        # Create a colored logger message
        BOLD = "\033[1m"
        GREEN = "\033[92m"
        YELLOW = "\033[93m"
        RED = "\033[91m"
        RESET = "\033[0m"
        
        logger(f"{YELLOW}{BOLD}nexto_core module not found. Attempting to download from GitHub...{RESET}")
        logger(f"{YELLOW}Target directory: {target_dir}{RESET}")
        
        # Remove existing nexto_core directory if it exists but is incomplete/corrupted
        if os.path.exists(nexto_core_dir) and not os.path.exists(os.path.join(nexto_core_dir, "bot.py")):
            logger(f"{YELLOW}Found incomplete nexto_core folder. Removing it before download.{RESET}")
            shutil.rmtree(nexto_core_dir, ignore_errors=True)
        
        # Only download if the directory doesn't exist or is incomplete
        if not os.path.exists(nexto_core_dir) or not os.path.exists(os.path.join(nexto_core_dir, "bot.py")):
            # Download the zip file
            logger(f"{YELLOW}Downloading nexto_core.zip from GitHub...{RESET}")
            urllib.request.urlretrieve(nexto_core_url, zip_path)
            
            if os.path.exists(zip_path):
                logger(f"{GREEN}Download successful! Extracting files...{RESET}")
                
                # Remove existing directory if it exists
                if os.path.exists(nexto_core_dir):
                    shutil.rmtree(nexto_core_dir, ignore_errors=True)
                    
                # Create the directory
                os.makedirs(nexto_core_dir, exist_ok=True)
                
                # Extract zip file
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(target_dir)
                
                # Clean up the zip file
                os.remove(zip_path)
                
                # Verify extraction was successful
                if os.path.exists(os.path.join(nexto_core_dir, "bot.py")):
                    logger(f"{GREEN}{BOLD}nexto_core successfully downloaded and extracted to {nexto_core_dir}!{RESET}")
                    return True, nexto_core_dir
                else:
                    logger(f"{RED}{BOLD}Extraction appears incomplete. bot.py not found in nexto_core directory.{RESET}")
                    return False, None
            else:
                logger(f"{RED}{BOLD}Failed to download nexto_core.zip!{RESET}")
                return False, None
        else:
            logger(f"{GREEN}nexto_core directory already exists at {nexto_core_dir}. Skipping download.{RESET}")
            return True, nexto_core_dir
            
    except Exception as e:
        logger(f"{RED}{BOLD}Error downloading nexto_core: {e}{RESET}")
        logger(traceback.format_exc())
        return False, None

# Attempt to make Nexto code importable
_PLUGIN_DIR = os.path.dirname(os.path.realpath(__file__))

# Try to find nexto_core in LOCALAPPDATA first
_LOCALAPPDATA = os.environ.get('LOCALAPPDATA', '')
if _LOCALAPPDATA:
    _NEXTO_CORE_DIR = os.path.join(_LOCALAPPDATA, "vutrium", "sparkline", "plugins", "nexto_core")
    if not os.path.exists(_NEXTO_CORE_DIR):
        # Fall back to plugin directory if not found in LOCALAPPDATA
        _NEXTO_CORE_DIR = os.path.join(_PLUGIN_DIR, "nexto_core")
else:
    _NEXTO_CORE_DIR = os.path.join(_PLUGIN_DIR, "nexto_core")

# Add both the plugin directory and nexto_core directory to path
if _PLUGIN_DIR not in sys.path:
    sys.path.insert(0, _PLUGIN_DIR)
if _NEXTO_CORE_DIR not in sys.path:
    sys.path.insert(0, _NEXTO_CORE_DIR)
# Also add the parent directory of nexto_core to path
_NEXTO_PARENT_DIR = os.path.dirname(_NEXTO_CORE_DIR)
if _NEXTO_PARENT_DIR not in sys.path:
    sys.path.insert(0, _NEXTO_PARENT_DIR)

# This import is from rlbot.agents.base_agent, which script_old (1).py also uses.
try:
    from rlbot.agents.base_agent import SimpleControllerState
except ImportError:
    class SimpleControllerState:
        def __init__(self, steer=0.0, throttle=0.0, pitch=0.0, yaw=0.0, roll=0.0, jump=False, boost=False, handbrake=False, use_item=False):
            self.steer, self.throttle, self.pitch, self.yaw, self.roll = steer, throttle, pitch, yaw, roll
            self.jump, self.boost, self.handbrake, self.use_item = jump, boost, handbrake, use_item
        def __str__(self): return f"SCS(T:{self.throttle:.1f} S:{self.steer:.1f} P:{self.pitch:.1f} J:{self.jump})"

class DummyVec3: # Used by AdaptiveFieldInfo for field data representation
    def __init__(self, x, y, z):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)

class DummyGoalInfo: # Used by AdaptiveFieldInfo for goal data representation
    def __init__(self, team_num, location_vec3, width=1786.0, height=642.0, depth=880.0):
        self.team_num = int(team_num)
        self.location = location_vec3 # Should be a DummyVec3 instance
        self.width = float(width)
        self.height = float(height)
        self.depth = float(depth) # Standard RLBot FieldInfo might not have depth, Nexto might use it.

class DummyBoostPad: # Used by AdaptiveFieldInfo for boost pad representation
    def __init__(self, location_vec3, is_full_boost):
        self.location = location_vec3 # Should be a DummyVec3 instance
        self.is_full_boost = bool(is_full_boost)

class AdaptiveFieldInfo:
    """A field info class that provides what Nexto needs, adapting live game data if available."""
    def __init__(self, live_field_info_packet=None):
        self.live_field_info_packet = live_field_info_packet
        self.num_boosts = 0 # Will be updated
        self.boost_pads = [] # List of DummyBoostPad objects
        self._boost_locations = np.empty((0, 3), dtype=np.float32) # Raw locations for Nexto's format, initialized as 2D
        
        self.goals = [] # List of DummyGoalInfo objects
        
        self._setup_boost_pads()
        self._setup_goals()
        
    def _setup_goals(self):
        if self.live_field_info_packet and self.live_field_info_packet.num_goals > 0:
            for i in range(self.live_field_info_packet.num_goals):
                live_goal = self.live_field_info_packet.goals[i]
                loc = DummyVec3(live_goal.location.x, live_goal.location.y, live_goal.location.z)
                # Note: live_goal.direction might be useful for Nexto, but DummyGoalInfo doesn't store it.
                # Standard RLBot FieldInfo also might not have goal depth, so we use default.
                self.goals.append(DummyGoalInfo(live_goal.team_num, loc, live_goal.width, live_goal.height))
        else:
            # Fallback to standard goal locations
            blue_goal_loc = DummyVec3(0, -5120, 321.3875)
            self.goals.append(DummyGoalInfo(0, blue_goal_loc))
            orange_goal_loc = DummyVec3(0, 5120, 321.3875)
            self.goals.append(DummyGoalInfo(1, orange_goal_loc))
            
    def _setup_boost_pads(self):
        standard_pads_tuples = [ # Keep this for fallback
            (3584, 4096, 73), (-3584, 4096, 73), (3584, -4096, 73), (-3584, -4096, 73),
            (0, 4240, 73), (0, -4240, 73), (3072, 0, 73), (-3072, 0, 73),
            (0, -2816, 73), (0, -1024, 73), (0, 0, 73), (0, 1024, 73), (0, 2816, 73),
            (-1792, -4184, 73), (1792, -4184, 73), (-1792, 4184, 73), (1792, 4184, 73),
            (-3584, -2484, 73), (3584, -2484, 73), (-3584, 2484, 73), (3584, 2484, 73),
            (-2048, -3072, 73), (2048, -3072, 73), (-2048, 3072, 73), (2048, 3072, 73),
            (-940, -1036, 73), (940, -1036, 73), (-940, 1036, 73), (940, 1036, 73),
            (-2048, -1036, 73), (2048, -1036, 73), (-2048, 1036, 73), (2048, 1036, 73),
            (-1024, -4240, 73)
        ]

        raw_locations_list = []
        if self.live_field_info_packet and self.live_field_info_packet.num_boosts > 0:
            self.num_boosts = self.live_field_info_packet.num_boosts
            for i in range(self.live_field_info_packet.num_boosts):
                live_pad = self.live_field_info_packet.boost_pads[i]
                loc = DummyVec3(live_pad.location.x, live_pad.location.y, live_pad.location.z)
                is_full = live_pad.is_full_boost
                self.boost_pads.append(DummyBoostPad(loc, is_full))
                raw_locations_list.append((loc.x, loc.y, loc.z))
        else:
            # Fallback to standard boost pad locations
            self.num_boosts = len(standard_pads_tuples)
            for x, y, z in standard_pads_tuples:
                loc = DummyVec3(x, y, z)
                is_full = abs(x) >= 3072 or (x == 0 and abs(y) >= 4096) # Approximation for full boosts
                self.boost_pads.append(DummyBoostPad(loc, is_full))
                raw_locations_list.append((x, y, z))
        
        # Ensure _boost_locations is populated correctly for the property
        if raw_locations_list:
            self._boost_locations = np.array(raw_locations_list, dtype=np.float32)
        else: # Should not happen if fallback works, but as a safe guard
            self._boost_locations = np.empty((0,3), dtype=np.float32)


    @property
    def boost_locations(self):
        """Return boost locations in the shape Nexto expects: (2,1,N,3) where N is num_boosts"""
        # Reshape the locations to match the expected shape
        # Nexto might expect exactly 34, but using self.num_boosts is more robust if live data has different counts.
        # However, Nexto's internal model is likely trained on 34. We might need to pad or truncate if num_boosts differs.
        # For now, assume Nexto can handle variable N or that N will be 34 from live data on standard maps.
        # If Nexto strictly requires 34, padding/truncation logic would be needed here.
        # Let's assume self.num_boosts is the correct N for now.
        
        # Ensure _boost_locations has data
        if self._boost_locations.size == 0:
             # Return a correctly shaped empty array or handle error
             # This indicates an congenial in _setup_boost_pads if it happens
            return np.zeros((2, 1, 0, 3), dtype=np.float32)

        # Pad or truncate to 34 if Nexto requires it
        # This is a common requirement for fixed-size NN inputs.
        target_num_pads = 34 
        current_num_pads = self._boost_locations.shape[0]
        
        if current_num_pads == target_num_pads:
            processed_locations = self._boost_locations
        elif current_num_pads > target_num_pads:
            processed_locations = self._boost_locations[:target_num_pads, :]
        else: # current_num_pads < target_num_pads
            padding = np.zeros((target_num_pads - current_num_pads, 3), dtype=np.float32)
            processed_locations = np.vstack((self._boost_locations, padding))

        reshaped = np.zeros((2, 1, target_num_pads, 3), dtype=np.float32)
        reshaped[0, 0, :target_num_pads] = processed_locations
        reshaped[1, 0, :target_num_pads] = processed_locations # Both teams see same pads
        return reshaped
        
    @property
    def field_size(self):
        """Return standard field dimensions. Not typically in FieldInfoPacket."""
        return (8192, 10240, 2044)  # Width (x), Length (y), Height (z)

class NextoSwitchPlugin:
    def __init__(self, ConsoleLogger=print):
        self.logger = ConsoleLogger
        self.Name = lambda: "NextoSwitchPlugin"

        self.nexto_instance = None
        self.nexto_agent_active = False
        self._nexto_initialized_for_player_key = None
        
        self.live_field_info = None
        self.field_info = None
        
        self.dribble_stop_timestamp = 0
        self.dribble_cooldown_duration = 1.5
        
        self.activated_for_dribble = False
        self.last_activation_reason = ""
        
        self.BOLD = "\033[1m"
        self.GREEN = "\033[92m"
        self.RED = "\033[91m"
        self.YELLOW = "\033[93m"
        self.BLUE = "\033[94m"
        self.RESET = "\033[0m"
        
        self.low_boost_threshold = 20
        self.threat_distance = 1500
        self.ball_possession_distance = 300
        
        self.opponent_dribble_start_time = 0
        self.our_dribble_start_time = 0
        self.teammate_dribble_start_time = 0
        self.opponent_was_dribbling = False
        self.we_were_dribbling = False
        self.teammate_was_dribbling = False
        self.dribble_confirmation_time = 0.05

        self.NextoBotClass = None
        try:
            try:
                from nexto_core.bot import Nexto as NextoBotClass
            except Exception as e:
                self.logger(f"[{self.Name()}] Failed to import Nexto: {e}")
                
                # First try downloading the nexto_core from GitHub
                if download_nexto_core(self.logger):
                    self.logger(f"[{self.Name()}] Successfully downloaded nexto_core. Attempting to import...")
                    try:
                        # Force reload sys.modules to recognize the new files
                        if 'nexto_core.bot' in sys.modules:
                            del sys.modules['nexto_core.bot']
                        from nexto_core.bot import Nexto as NextoBotClass
                        self.logger(f"[{self.GREEN}{self.BOLD}SUCCESS{self.RESET}] Imported Nexto after downloading.")
                    except ImportError as import_after_download_error:
                        self.logger(f"[{self.Name()}] Failed to import Nexto after downloading: {import_after_download_error}")
                        self.logger(f"[{self.Name()}] Attempting to install dependencies...")
                        if install_dependencies():
                            self.logger(f"[{self.Name()}] Dependencies installed. Please restart the script to use NextoSwitchPlugin.")
                            self.logger(f"{self.RED}" + "=" * 80)
                            self.logger("IMPORTANT: You need to RESTART the script to use NextoSwitchPlugin!")
                            self.logger("=" * 80 + f"{self.RESET}")
                else:
                    self.logger(f"[{self.Name()}] Failed to download nexto_core. Attempting to install dependencies...")
                    if install_dependencies():
                        self.logger(f"[{self.Name()}] Dependencies installed. Please restart the script to use NextoSwitchPlugin.")
                        self.logger(f"{self.RED}" + "=" * 80)
                        self.logger("IMPORTANT: You need to RESTART the script to use NextoSwitchPlugin!")
                        self.logger("=" * 80 + f"{self.RESET}")
                
                import importlib.util
                bot_path = os.path.join(_NEXTO_CORE_DIR, "bot.py")
                if os.path.exists(bot_path):
                    try:
                        spec = importlib.util.spec_from_file_location("bot", bot_path)
                        bot_module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(bot_module)
                        NextoBotClass = bot_module.Nexto
                    except ImportError as direct_import_error:
                        self.logger(f"[{self.Name()}] Failed to directly import Nexto: {direct_import_error}")
                        if install_dependencies():
                            self.logger(f"[{self.Name()}] Dependencies installed. Please restart the script to use NextoSwitchPlugin.")
                            self.logger(f"{self.RED}" + "=" * 80)
                            self.logger("IMPORTANT: You need to RESTART the script to use NextoSwitchPlugin!")
                            self.logger("=" * 80 + f"{self.RESET}")
                else:
                    if download_nexto_core(self.logger):
                        self.logger(f"[{self.Name()}] Successfully downloaded nexto_core. Attempting to import...")
                        try:
                            # Force reload sys.modules to recognize the new files
                            if 'nexto_core.bot' in sys.modules:
                                del sys.modules['nexto_core.bot']
                            from nexto_core.bot import Nexto as NextoBotClass
                            self.logger(f"[{self.GREEN}{self.BOLD}SUCCESS{self.RESET}] Imported Nexto after downloading.")
                            raise ImportError(f"bot.py not found at {bot_path}")
                        except Exception as e:
                            print(e)
                        
            
            self.NextoBotClass = NextoBotClass
        except Exception as e:
            self.logger(f"[{self.Name()}] Failed to import NextoBotClass: {e}")
            self.logger(traceback.format_exc())

        self.current_player_index = -1
        self.current_player_team = -1
        
        # Use a deque to store recent Nexto outputs (sampled once per second)
        self.recent_nexto_outputs = collections.deque(maxlen=4) # Store last 4 sampled ticks
        self.last_sample_time = 0.0 # Time of the last sampled output

        # Smoothing parameters (independent of MovementSmootherPlugin)
        self.smoothing_window_size = 5  # Number of past Nexto controller states to average
        self.steer_history = collections.deque(maxlen=self.smoothing_window_size)
        self.throttle_history = collections.deque(maxlen=self.smoothing_window_size)
        self.pitch_history = collections.deque(maxlen=self.smoothing_window_size)
        self.yaw_history = collections.deque(maxlen=self.smoothing_window_size)
        self.roll_history = collections.deque(maxlen=self.smoothing_window_size)
        self._clear_smoothing_history() # Initialize as empty

        # Re-add clock variables
        self.clock_thread = None
        self.clock_running = False
        self.clock_initialized = False
        self.last_game_tick_packet = None
    
        self.config_min_ball_height_above_car = 30.0
        self.config_max_ball_height_above_car = 220.0
        self.config_max_horizontal_offset = 160.0
        self.config_max_relative_speed_for_dribble = 350.0
        self.config_max_car_height = 100.0

    def _clear_smoothing_history(self):
        self.steer_history.clear()
        self.throttle_history.clear()
        self.pitch_history.clear()
        self.yaw_history.clear()
        self.roll_history.clear()
        # self.logger(f"[{self.Name()}] Cleared Nexto smoothing history.")

    # Removed start_clock, stop_clock, and clock_loop methods
    # def start_clock(self):
    #     """Start a background clock thread to keep Nexto initialized"""
    #     pass # Removed
    
    # def stop_clock(self):
    #     """Stop the clock thread"""
    #     pass # Removed
    
    # def clock_loop(self):
    #     """Main loop for the clock thread that keeps Nexto initialized"""
    #     pass # Removed

    # Re-add clock methods
    def start_clock(self):
        """Start a background clock thread to keep Nexto initialized"""
        if not self.clock_thread or not self.clock_running:
            self.clock_running = True
            self.clock_thread = threading.Thread(target=self.clock_loop)
            self.clock_thread.daemon = True  # Thread will exit when main program exits
            self.clock_thread.start()
            self.logger(f"[{self.Name()}] Started clock thread to keep Nexto initialized")

    def stop_clock(self):
        """Stop the clock thread"""
        self.clock_running = False
        if self.clock_thread and self.clock_thread.is_alive():
            try:
                self.clock_thread.join(timeout=1.0)  # Wait up to 1 second for thread to exit
                if self.clock_thread.is_alive():
                    self.logger(f"[{self.Name()}] Warning: Clock thread did not exit cleanly")
            except Exception as e:
                self.logger(f"[{self.Name()}] Error stopping clock thread: {e}")
        self.clock_thread = None
        self.logger(f"[{self.Name()}] Stopped clock thread")

    def clock_loop(self):
        """Main loop for the clock thread that keeps Nexto initialized"""
        tick_interval = 1.0  # Run every 1 second
        last_tick_time = 0
        
        while self.clock_running:
            current_time = time.time()
            
            # Only run at specified interval
            if current_time - last_tick_time >= tick_interval:
                try:
                    # If we have a valid Nexto instance and game packet, keep it warm
                    if self.nexto_instance and self.last_game_tick_packet and self._nexto_initialized_for_player_key:
                        # Just get output without doing anything with it
                        # This keeps the Nexto model loaded and ready
                        _ = self.nexto_instance.get_output(self.last_game_tick_packet)
                        self.clock_initialized = True
                except Exception as e:
                    # Don't log every error to avoid spam
                    if not hasattr(self, "_last_clock_error_time") or current_time - self._last_clock_error_time > 10:
                        self.logger(f"[{self.Name()}] Clock thread error: {e}")
                        self._last_clock_error_time = current_time
                
                last_tick_time = current_time
            
            # Sleep to avoid high CPU usage
            time.sleep(0.1)

    def _initialize_nexto_if_needed(self, packet, local_player_index, player_team):
        # Add validation for player index
        if local_player_index < 0 or local_player_index >= packet.num_cars:
            self.logger(f"[{self.Name()}] Invalid local_player_index: {local_player_index}. Cannot initialize Nexto.")
            return False
        
        if not self.NextoBotClass:
            if not hasattr(self, "_nexto_import_failed_logged_init"):
                self.logger(f"[{self.Name()}] NextoBotClass not available, cannot initialize Nexto.")
                self._nexto_import_failed_logged_init = True
            return False
        
        current_key = (local_player_index, player_team)
        if self.nexto_instance and self._nexto_initialized_for_player_key == current_key:
            # If already initialized for this player/team and field_info is prepared, skip full re-init.
            # However, if field_info needs to be updated (e.g. on map change), this might need adjustment.
            # For now, assume field_info is stable for the duration of Nexto's use for this player.
            return True

        try:
            # Get player name if available, otherwise use a default
            player_name = "NextoPluginInstance"
            if local_player_index < len(packet.game_cars): # Check length of game_cars array
                if hasattr(packet.game_cars[local_player_index], 'name'):
                     player_name = packet.game_cars[local_player_index].name
            
            # Create Nexto instance with parameters matching the standard usage
            self.nexto_instance = self.NextoBotClass(
                name=player_name,
                team=player_team,
                index=local_player_index,
                beta=1, 
                render=False,
                hardcoded_kickoffs=True, # Nexto has its own kickoff logic, but we also prevent activation on kickoff
                stochastic_kickoffs=False
            )
            
            # Prepare Nexto-compatible field_info using live data if available
            # self.live_field_info should be set by game_tick_packet_set
            current_live_field_info = self.live_field_info if hasattr(self, 'live_field_info') else None
            self.field_info = AdaptiveFieldInfo(live_field_info_packet=current_live_field_info)
            
            self.nexto_instance.initialize_agent(self.field_info) # Pass the (potentially live) field info
            
            # Set tick_skip to 8 which is what Nexto expects by default
            self.nexto_instance.tick_skip = 8
            
            # Make sure obs_builder is initialized properly
            # This part relies on Nexto's internal structure.
            if hasattr(self.nexto_instance, 'obs_builder') and self.nexto_instance.obs_builder is not None:
                if hasattr(self.nexto_instance.obs_builder, '_reset') and hasattr(self.nexto_instance, 'game_state'):
                    try:
                        # Nexto's GameState might need to be populated before resetting obs_builder
                        # This could be tricky if _update_game_state hasn't run yet for this specific init.
                        # For now, assuming Nexto handles initial GameState state or can reset with a partially ready one.
                        self.nexto_instance.obs_builder._reset(self.nexto_instance.game_state)
                    except Exception as e:
                        self.logger(f"[{self.Name()}] Warning: Could not reset obs_builder: {e}")
            
            # Fix team orientation by setting the correct team_sign based on team
            if hasattr(self.nexto_instance, 'team_sign'):
                self.nexto_instance.team_sign = 1 if player_team == 0 else -1 # Blue team is 0, Orange is 1
            
            self._nexto_initialized_for_player_key = current_key
            self.logger(f"[{self.Name()}] {self.GREEN}{self.BOLD}Nexto initialized{self.RESET} for player {player_name} (idx: {local_player_index}, team: {player_team})")
            return True

        except Exception as e:
            self.logger(f"[{self.Name()}] Error during Nexto initialization: {e}")
            self.logger(traceback.format_exc())
            self.nexto_instance = None
            self._nexto_initialized_for_player_key = None
            return False

    def _is_opponent_dribbling(self, packet, local_player_team: int) -> bool:
        if not hasattr(packet, 'game_ball') or not hasattr(packet.game_ball, 'physics'):
            return False

        ball_phys = packet.game_ball.physics
        ball_loc = np.array([ball_phys.location.x, ball_phys.location.y, ball_phys.location.z])
        ball_vel = np.array([ball_phys.velocity.x, ball_phys.velocity.y, ball_phys.velocity.y]) # Fix: Changed ball_phys.velocity.z to ball_phys.velocity.y to fix typo and align with common vector representation
        
        # Get our car's position to check if we're on the same side as the opponent
        local_player_index = -1
        our_car_pos = None
        for i in range(packet.num_cars):
            if packet.game_cars[i].team == local_player_team:
                # local_player_index = i # Not strictly needed here but good practice
                our_car_pos = np.array([
                    packet.game_cars[i].physics.location.x,
                    packet.game_cars[i].physics.location.y,
                    packet.game_cars[i].physics.location.z
                ])
                break
        
        if our_car_pos is None:
            return False  # Can't find our car position

        for i in range(packet.num_cars):
            player = packet.game_cars[i]
            if player.team == local_player_team or player.is_demolished:
                continue

            # More lenient check for ground contact - completely removed wheel contact requirement
            car_phys = player.physics
            car_loc = np.array([car_phys.location.x, car_phys.location.y, car_phys.location.z])
            car_vel = np.array([car_phys.velocity.x, car_phys.velocity.y, car_phys.velocity.z])
            
            # Check if both cars are on the same side of the field
            # Same side means both cars have y values with the same sign (both positive or both negative)
            same_side = (car_loc[1] > 0 and our_car_pos[1] > 0) or (car_loc[1] < 0 and our_car_pos[1] < 0)
            if not same_side:
                continue  # Skip if not on same side
            
            # Much less strict height check
            if car_loc[2] > self.config_max_car_height * 1.5:  # Give much more tolerance for opponent cars
                continue

            relative_ball_loc_z = ball_loc[2] - car_loc[2]
            if not (self.config_min_ball_height_above_car < relative_ball_loc_z < self.config_max_ball_height_above_car):
                continue

            # Less strict horizontal distance check - increased to 150^2
            horizontal_offset_sq = (ball_loc[0] - car_loc[0])**2 + (ball_loc[1] - car_loc[1])**2
            if horizontal_offset_sq >= 150**2:
                continue
            
            # Less strict relative speed check - increased to 350
            relative_speed = np.linalg.norm(ball_vel - car_vel)
            if relative_speed >= 350:
                continue
            
            # Add forward vector check but make it more lenient
            car_forward = np.array([math.cos(player.physics.rotation.yaw), math.sin(player.physics.rotation.yaw), 0])
            car_to_ball = ball_loc - car_loc
            car_to_ball_normalized = car_to_ball / np.linalg.norm(car_to_ball) if np.linalg.norm(car_to_ball) > 0.001 else np.array([0, 0, 0])
            facing_ball = np.dot(car_forward, car_to_ball_normalized) > 0.4  # Reduced from 0.6 to be more lenient
            
            if not facing_ball:
                continue
                
            # Log when we detect a dribble and we're on the same side
            self.logger(f"[{self.Name()}] {self.BLUE}{self.BOLD}Opponent dribble detected on same side.{self.RESET} Our Y: {our_car_pos[1]:.0f}, Enemy Y: {car_loc[1]:.0f}")    
            return True
        return False

    def _is_our_car_dribbling(self, packet, local_player_index: int) -> bool:
        if not hasattr(packet, 'game_ball') or not hasattr(packet.game_ball, 'physics') or local_player_index >= packet.num_cars:
            return False
            
        our_player = packet.game_cars[local_player_index]
        if our_player.is_demolished:
            return False
            
        # Be more lenient with wheel contact - allow significant jumps during dribbling
        if not our_player.has_wheel_contact and our_player.physics.location.z > self.config_max_car_height * 1.5:
            return False
            
        ball_phys = packet.game_ball.physics
        ball_loc = np.array([ball_phys.location.x, ball_phys.location.y, ball_phys.location.z])
        ball_vel = np.array([ball_phys.velocity.x, ball_phys.velocity.y, ball_phys.velocity.z])
        
        car_phys = our_player.physics
        car_loc = np.array([car_phys.location.x, car_phys.location.y, car_phys.location.z])
        car_vel = np.array([car_phys.velocity.x, car_phys.velocity.y, car_phys.velocity.z])
        
        # Ensure we're on the same side of the field as the ball
        # Same side means both have y values with the same sign (both positive or both negative)
        same_side = (car_loc[1] > 0 and ball_loc[1] > 0) or (car_loc[1] < 0 and ball_loc[1] < 0)
        if not same_side:
            return False
            
        # Much more lenient height check
        if car_loc[2] > self.config_max_car_height * 1.5:
            return False
            
        # Expand the relative ball height range
        relative_ball_loc_z = ball_loc[2] - car_loc[2]
        if not (self.config_min_ball_height_above_car * 0.8 < relative_ball_loc_z < self.config_max_ball_height_above_car * 1.1):
            return False
            
        # Even more lenient horizontal distance check for our car
        horizontal_offset_sq = (ball_loc[0] - car_loc[0])**2 + (ball_loc[1] - car_loc[1])**2
        max_horizontal_offset = self.config_max_horizontal_offset * 1.1  # Give extra 10% allowance
        if horizontal_offset_sq >= max_horizontal_offset**2:
            return False
            
        # Even more lenient relative speed check for our car
        relative_speed = np.linalg.norm(ball_vel - car_vel)
        max_speed = self.config_max_relative_speed_for_dribble * 1.1  # Give extra 10% allowance
        if relative_speed >= max_speed:
            return False
            
        # Even more lenient forward vector check for our car
        car_forward = np.array([math.cos(car_phys.rotation.yaw), math.sin(car_phys.rotation.yaw), 0])
        car_to_ball = ball_loc - car_loc
        car_to_ball_normalized = car_to_ball / np.linalg.norm(car_to_ball) if np.linalg.norm(car_to_ball) > 0.001 else np.array([0, 0, 0])
        facing_ball = np.dot(car_forward, car_to_ball_normalized) > 0.3  # Reduced from 0.4 for even more leniency
        
        if not facing_ball:
            return False
            
        return True

    def _is_teammate_dribbling(self, packet, local_player_index, local_player_team):
        """Check if a teammate is dribbling the ball"""
        if not hasattr(packet, 'game_ball') or not hasattr(packet.game_ball, 'physics'):
            return False
            
        # Get our car position to check if we're on the same side
        if local_player_index >= packet.num_cars:
            return False
            
        our_car = packet.game_cars[local_player_index]
        our_car_pos = np.array([our_car.physics.location.x, our_car.physics.location.y, our_car.physics.location.z])

        ball_phys = packet.game_ball.physics
        ball_loc = np.array([ball_phys.location.x, ball_phys.location.y, ball_phys.location.z])
        ball_vel = np.array([ball_phys.velocity.x, ball_phys.velocity.y, ball_phys.velocity.z])
        
        # Check if we're on the same side as the ball
        we_same_side_as_ball = (our_car_pos[1] > 0 and ball_loc[1] > 0) or (our_car_pos[1] < 0 and ball_loc[1] < 0)
        if not we_same_side_as_ball:
            return False  # We're not on the same side as the ball

        for i in range(packet.num_cars):
            # Skip if it's our car or an opponent
            if i == local_player_index or packet.game_cars[i].team != local_player_team:
                continue
                
            player = packet.game_cars[i]
            if player.is_demolished:
                continue

            # More lenient check for ground contact
            if not player.has_wheel_contact and player.physics.location.z > self.config_max_car_height * 1.5:
                continue

            car_phys = player.physics
            car_loc = np.array([car_phys.location.x, car_phys.location.y, car_phys.location.z])
            car_vel = np.array([car_phys.velocity.x, car_phys.velocity.y, car_phys.velocity.z])

            # Ensure teammate is on the same side as the ball
            teammate_same_side_as_ball = (car_loc[1] > 0 and ball_loc[1] > 0) or (car_loc[1] < 0 and ball_loc[1] < 0)
            if not teammate_same_side_as_ball:
                continue  # Teammate not on same side as ball
                
            # Also ensure teammate is on the same side as us
            teammate_same_side_as_us = (car_loc[1] > 0 and our_car_pos[1] > 0) or (car_loc[1] < 0 and our_car_pos[1] < 0)
            if not teammate_same_side_as_us:
                continue  # Teammate not on same side as us

            # More lenient height check
            if car_loc[2] > self.config_max_car_height * 1.5:
                continue

            # More lenient ball height range
            relative_ball_loc_z = ball_loc[2] - car_loc[2]
            if not (self.config_min_ball_height_above_car * 0.8 < relative_ball_loc_z < self.config_max_ball_height_above_car * 1.1):
                continue

            # Much less strict horizontal distance check
            horizontal_offset_sq = (ball_loc[0] - car_loc[0])**2 + (ball_loc[1] - car_loc[1])**2
            if horizontal_offset_sq >= 150**2:  # Increased from 110^2
                continue
            
            # Less strict relative speed check
            relative_speed = np.linalg.norm(ball_vel - car_vel)
            if relative_speed >= 350:  # Increased from 270
                continue
            
            # More lenient forward vector check
            car_forward = np.array([math.cos(car_phys.rotation.yaw), math.sin(car_phys.rotation.yaw), 0])
            car_to_ball = ball_loc - car_loc
            car_to_ball_normalized = car_to_ball / np.linalg.norm(car_to_ball) if np.linalg.norm(car_to_ball) > 0.001 else np.array([0, 0, 0])
            facing_ball = np.dot(car_forward, car_to_ball_normalized) > 0.4  # Reduced from 0.55
            
            if not facing_ball:
                continue
            
            return True
        return False

    def _check_enemy_possession_challenge(self, packet, local_player_index, local_player_team):
        """Check if we're challenging an enemy who has ball possession"""
        if not hasattr(packet, 'game_ball') or not hasattr(packet.game_ball, 'physics'):
            return False
            
        # Get our car data
        our_car = packet.game_cars[local_player_index]
        our_car_pos = np.array([our_car.physics.location.x, our_car.physics.location.y, our_car.physics.location.z])
        our_car_vel = np.array([our_car.physics.velocity.x, our_car.physics.velocity.y, our_car.physics.velocity.z])
        our_car_forward = np.array([
            math.cos(our_car.physics.rotation.yaw), 
            math.sin(our_car.physics.rotation.yaw), 
            0
        ])
        
        # Get ball data
        ball_phys = packet.game_ball.physics
        ball_pos = np.array([ball_phys.location.x, ball_phys.location.y, ball_phys.location.z])
        
        # Check if ball is too high for Nexto to handle effectively
        BALL_HEIGHT_THRESHOLD = 120.0  # Ball height threshold to consider it an aerial challenge
        if ball_pos[2] > BALL_HEIGHT_THRESHOLD:
            # Ball is too high off the ground - don't use Nexto for this aerial possession challenge
            return False
        
        # Find opponent with ball possession
        opponent_with_ball = None
        opponent_pos = None
        closest_opponent_dist_to_ball = float('inf')
        
        for i in range(packet.num_cars):
            if packet.game_cars[i].team != local_player_team:
                car = packet.game_cars[i]
                if car.is_demolished:
                    continue
                    
                car_pos = np.array([car.physics.location.x, car.physics.location.y, car.physics.location.z])
                dist_to_ball = np.linalg.norm(car_pos - ball_pos)
                
                # Much stricter distance requirement - previously 300
                if dist_to_ball < 200 and dist_to_ball < closest_opponent_dist_to_ball:
                    closest_opponent_dist_to_ball = dist_to_ball
                    opponent_with_ball = car
                    opponent_pos = car_pos
        
        if opponent_with_ball is None:
            return False
            
        # Check if we're close to the ball and moving toward it
        dist_to_ball = np.linalg.norm(our_car_pos - ball_pos)
        
        # Must be much closer to consider a true challenge - previously 800
        if dist_to_ball > 400:
            return False
            
        # Distance from our car to the opponent with the ball
        dist_to_opponent = np.linalg.norm(our_car_pos - opponent_pos)
        
        # Must be much closer to opponent - previously 1000
        if dist_to_opponent > 400:
            return False
            
        # Calculate if we're moving toward the ball
        car_to_ball_dir = (ball_pos - our_car_pos)
        car_to_ball_dir_normalized = car_to_ball_dir / np.linalg.norm(car_to_ball_dir) if np.linalg.norm(car_to_ball_dir) > 0.001 else np.array([0, 0, 0])
        speed_toward_ball = np.dot(our_car_vel, car_to_ball_dir_normalized)
        
        # Require a higher speed toward the ball - previously 400
        if speed_toward_ball < 600:
            return False
            
        # Calculate if we're facing the ball - increased requirement from 0.7
        facing_ball = np.dot(our_car_forward, car_to_ball_dir_normalized) > 0.85
        if not facing_ball:
            return False
            
        # Make sure the balanced_distances check is strict here too
        # Don't activate if one car is way closer to the ball than the other
        balanced_distances = abs(dist_to_ball - closest_opponent_dist_to_ball) < 150
        if not balanced_distances:
            return False
        
        # If we've reached this point, we're challenging an opponent with possession
        self.logger(f"[{self.Name()}] {self.BLUE}{self.BOLD}Enemy possession challenge:{self.RESET} BallDist={dist_to_ball:.0f}, OppDist={closest_opponent_dist_to_ball:.0f}, Speed={speed_toward_ball:.0f}")
        return True

    def _are_on_same_side(self, car1_pos, car2_pos):
        """Check if two car positions are on the same side of the field"""
        # Same side means both cars have y values with the same sign (both positive or both negative)
        return (car1_pos[1] > 0 and car2_pos[1] > 0) or (car1_pos[1] < 0 and car2_pos[1] < 0)

    def _check_low_boost_threat(self, packet, local_player_index, local_player_team):
        """Check if we're in a low boost situation with our goal being threatened and we're between ball and goal"""
        if local_player_index >= packet.num_cars:
            return False
            
        # Get our car data
        our_car = packet.game_cars[local_player_index]
        
        # Check if we have low boost
        if our_car.boost > self.low_boost_threshold:
            return False
            
        # Get our position
        our_pos = np.array([
            our_car.physics.location.x,
            our_car.physics.location.y,
            our_car.physics.location.z
        ])
        
        # Get ball position
        if not hasattr(packet, 'game_ball') or not hasattr(packet.game_ball, 'physics'):
            return False
            
        ball_pos = np.array([
            packet.game_ball.physics.location.x,
            packet.game_ball.physics.location.y,
            packet.game_ball.physics.location.z
        ])
        
        # Check if ball is in the air - don't use Nexto for aerial defense
        BALL_AIR_THRESHOLD = 120  # Ball height to consider it in the air
        if ball_pos[2] > BALL_AIR_THRESHOLD:
            return False  # Ball is in the air, Opti handles aerials better
        
        # Determine our goal position based on team
        goal_pos = np.array([0, -5120, 0]) if local_player_team == 0 else np.array([0, 5120, 0])
        
        # Check if ball is on our side of the field
        ball_on_our_side = (local_player_team == 0 and ball_pos[1] < 0) or (local_player_team == 1 and ball_pos[1] > 0)
        if not ball_on_our_side:
            return False  # Ball not on our side, no immediate threat
        
        # Calculate distance from ball to our goal
        ball_to_goal_distance = np.linalg.norm(ball_pos - goal_pos)
        
        # Define threat zone - closer to our goal means higher threat
        GOAL_THREAT_DISTANCE = 3500  # Distance to consider ball threatening our goal
        
        # Check if ball is threatening our goal
        ball_threatening_goal = ball_to_goal_distance < GOAL_THREAT_DISTANCE
        if not ball_threatening_goal:
            return False  # Ball not close enough to our goal
        
        # Check if we have ball possession
        distance_to_ball = np.linalg.norm(our_pos - ball_pos)
        if distance_to_ball < self.ball_possession_distance:
            return False  # We have ball possession, no need for Nexto
            
        # Check if we're between the ball and our goal
        # If we're behind the ball (from goal's perspective), Opti would be better
        ball_to_goal = goal_pos - ball_pos
        ball_to_goal_normalized = ball_to_goal / np.linalg.norm(ball_to_goal)
        our_to_ball = our_pos - ball_pos
        
        # Dot product < 0 means we're on the opposite side of the ball from the goal
        # (we're behind the ball from goal's perspective)
        dot_product = np.dot(ball_to_goal_normalized, our_to_ball) / np.linalg.norm(our_to_ball) if np.linalg.norm(our_to_ball) > 0 else 0
        
        # If we're behind the ball, Opti is better, so don't activate Nexto
        if dot_product < -0.2:  # Giving some buffer for slight angles
            return False
        
        # Check if any opponent is close to the ball and potentially threatening our goal
        opponent_threatening = False
        for i in range(packet.num_cars):
            if packet.game_cars[i].team != local_player_team:
                opp_car = packet.game_cars[i]
                if opp_car.is_demolished:
                    continue
                    
                opp_pos = np.array([
                    opp_car.physics.location.x,
                    opp_car.physics.location.y,
                    opp_car.physics.location.z
                ])
                
                # Calculate distance to ball
                dist_to_ball = np.linalg.norm(opp_pos - ball_pos)
                
                # Calculate distance to our goal
                dist_to_goal = np.linalg.norm(opp_pos - goal_pos)
                
                # Check if opponent is between ball and our goal or close to the ball
                if dist_to_ball < self.threat_distance or dist_to_goal < GOAL_THREAT_DISTANCE:
                    # Calculate if opponent is between ball and goal
                    opp_to_ball = opp_pos - ball_pos
                    
                    # Dot product > 0 means opponent is somewhat between ball and goal
                    opp_dot_product = np.dot(ball_to_goal_normalized, opp_to_ball) / np.linalg.norm(opp_to_ball) if np.linalg.norm(opp_to_ball) > 0 else 0
                    
                    if opp_dot_product > 0.3 or dist_to_ball < self.threat_distance:  # Opponent is somewhat between ball and goal or close to ball
                        opponent_threatening = True
                        break
        
        # We're in a low boost threat situation if:
        # 1. We have low boost
        # 2. Our goal is being threatened
        # 3. We're between the ball and our goal (not behind the ball)
        # 4. Ball is on the ground (not in the air)
        if ball_threatening_goal and opponent_threatening:
            self.logger(f"[{self.Name()}] {self.YELLOW}{self.BOLD}Goal threat detected:{self.RESET} Boost={our_car.boost}, BallDist={distance_to_ball:.0f}, GoalDist={ball_to_goal_distance:.0f}, BallHeight={ball_pos[2]:.0f}")
            return True
            
        return False

    def _check_dribble_conditions(self, packet, local_player_index, local_player_team):
        current_time = packet.game_info.seconds_elapsed
        
        # Check for kickoff - don't activate during kickoffs
        if self._is_kickoff(packet):
            return False, ""
            
        # Get our car position
        if local_player_index >= packet.num_cars:
            return False, ""
            
        our_car = packet.game_cars[local_player_index]
        our_car_pos = np.array([our_car.physics.location.x, our_car.physics.location.y, our_car.physics.location.z])
        
        # Get ball position
        if not hasattr(packet, 'game_ball') or not hasattr(packet.game_ball, 'physics'):
            return False, ""
            
        ball_pos = np.array([
            packet.game_ball.physics.location.x,
            packet.game_ball.physics.location.y, 
            packet.game_ball.physics.location.z
        ])
            
        # Check for instantaneous dribble conditions
        # Note: _is_opponent_dribbling already checks for same side, so no need for additional check
        opponent_has_ball_now = self._is_opponent_dribbling(packet, local_player_team) # Uncommented
        we_have_ball_now = self._is_our_car_dribbling(packet, local_player_index)
        # teammate_has_ball_now = self._is_teammate_dribbling(packet, local_player_index, local_player_team) # Commented out
        
        # Only continue with other checks if we and the ball are on the same side
        # same_side_as_ball = self._are_on_same_side(our_car_pos, ball_pos) # Not needed if only checking our dribble
        
        # Check for offensive teammate possession - only if we're on the same side as the ball
        # offensive_teammate_possession = False # Commented out
        # if same_side_as_ball: # Commented out
        #     offensive_teammate_possession = self._check_offensive_teammate_possession(packet, local_player_index, local_player_team) # Commented out
        
        # Check for recovery situation (ball and enemy on our side, we're on enemy side)
        # This is a special case where we're intentionally on opposite sides
        # recovery_situation = self._check_recovery_situation(packet, local_player_index, local_player_team) # Commented out
        
        # Check for low boost threat situation
        #low_boost_threat = self._check_low_boost_threat(packet, local_player_index, local_player_team) # Commented out
        
        # Timer logic for opponent dribble
        opponent_confirmed_dribbling = False # Uncommented
        if opponent_has_ball_now: # Uncommented
            if not self.opponent_was_dribbling: # Uncommented
                self.opponent_dribble_start_time = current_time # Uncommented
                self.opponent_was_dribbling = True # Uncommented
            
            # Check if timer threshold reached # Uncommented
            time_with_ball = current_time - self.opponent_dribble_start_time # Uncommented
            opponent_confirmed_dribbling = time_with_ball >= self.dribble_confirmation_time # Uncommented
        else: # Uncommented
            if self.opponent_was_dribbling: # Uncommented
                self.opponent_was_dribbling = False # Uncommented
        
        # Timer logic for our dribble
        our_confirmed_dribbling = False
        if we_have_ball_now:
            if not self.we_were_dribbling:
                self.our_dribble_start_time = current_time
                self.we_were_dribbling = True
            
            # Check if timer threshold reached
            time_with_ball = current_time - self.our_dribble_start_time
            our_confirmed_dribbling = time_with_ball >= self.dribble_confirmation_time
        else:
            if self.we_were_dribbling:
                self.we_were_dribbling = False
                
        # Timer logic for teammate dribble
        # teammate_confirmed_dribbling = False # Commented out
        # if teammate_has_ball_now: # Commented out
        #     if not self.teammate_was_dribbling: # Commented out
        #         self.teammate_dribble_start_time = current_time # Commented out
        #         self.teammate_was_dribbling = True # Commented out
            
        #     # Check if timer threshold reached # Commented out
        #     time_with_ball = current_time - self.teammate_dribble_start_time # Commented out
        #     teammate_confirmed_dribbling = time_with_ball >= self.dribble_confirmation_time # Commented out
        # else: # Commented out
        #     if self.teammate_was_dribbling: # Commented out
        #         self.teammate_was_dribbling = False # Commented out
        
        # Return the confirmed dribble states and which type
        # should_activate = opponent_confirmed_dribbling or our_confirmed_dribbling or offensive_teammate_possession or recovery_situation # Original line
        should_activate = opponent_confirmed_dribbling or our_confirmed_dribbling # Modified line
        activation_reason = ""
        if opponent_confirmed_dribbling: # Uncommented
            activation_reason = "opponent dribbling" # Uncommented
        elif our_confirmed_dribbling: # Modified to be the only reason
            activation_reason = "we are dribbling"
        # elif offensive_teammate_possession: # Commented out
        #     activation_reason = "offensive teammate possession" # Commented out
        # elif recovery_situation: # Commented out
        #     activation_reason = "recovery situation" # Commented out
        #elif low_boost_threat: # Commented out
        #    activation_reason = "low boost threat" # Commented out
            
        return should_activate, activation_reason

    def _check_offensive_teammate_possession(self, packet, local_player_index, local_player_team):
        """Check if a teammate has possession on the enemy side while we're also on the enemy side"""
        if not hasattr(packet, 'game_ball') or not hasattr(packet.game_ball, 'physics'):
            return False
            
        # Get ball position
        ball_phys = packet.game_ball.physics
        ball_loc = np.array([ball_phys.location.x, ball_phys.location.y, ball_phys.location.z])
        
        # Check if ball is on enemy side
        is_ball_on_enemy_side = (local_player_team == 0 and ball_loc[1] > 200) or \
                               (local_player_team == 1 and ball_loc[1] < -200)
                               
        if not is_ball_on_enemy_side:
            return False
            
        # Get our car position
        if local_player_index >= packet.num_cars:
            return False
            
        our_car = packet.game_cars[local_player_index]
        our_car_loc = np.array([our_car.physics.location.x, our_car.physics.location.y, our_car.physics.location.z])
        
        # Check if we're on enemy side
        we_on_enemy_side = (local_player_team == 0 and our_car_loc[1] > 0) or \
                          (local_player_team == 1 and our_car_loc[1] < 0)
                          
        if not we_on_enemy_side:
            return False
            
        # Check if we're at least 300 units from the ball
        distance_to_ball = np.linalg.norm(our_car_loc - ball_loc)
        if distance_to_ball < 300:
            return False
            
        # Check if any teammate has possession
        teammate_with_possession = False
        teammate_pos = None
        
        for i in range(packet.num_cars):
            # Skip if it's our car or an opponent
            if i == local_player_index or packet.game_cars[i].team != local_player_team:
                continue
                
            teammate = packet.game_cars[i]
            if teammate.is_demolished:
                continue
                
            teammate_loc = np.array([teammate.physics.location.x, teammate.physics.location.y, teammate.physics.location.z])
            
            # Check if teammate is on enemy side
            teammate_on_enemy_side = (local_player_team == 0 and teammate_loc[1] > 0) or \
                                    (local_player_team == 1 and teammate_loc[1] < 0)
                                    
            if not teammate_on_enemy_side:
                continue
                
            # Check if teammate is close to the ball (possession)
            teammate_distance_to_ball = np.linalg.norm(teammate_loc - ball_loc)
            if teammate_distance_to_ball < 200:  # Close enough to have possession
                teammate_with_possession = True
                teammate_pos = teammate_loc
                break
                
        if not teammate_with_possession:
            return False
            
        # NEW: Check if we're on the same side as the teammate with possession
        # Same side means both X coordinates have the same sign (both positive or both negative)
        same_side_as_teammate = (our_car_loc[0] > 0 and teammate_pos[0] > 0) or \
                               (our_car_loc[0] < 0 and teammate_pos[0] < 0)
                               
        # If we're on the same side as the teammate with possession, don't activate
        if same_side_as_teammate:
            return False
            
        # Count enemies nearby the play
        nearby_enemies = 0
        NEARBY_THRESHOLD = 1500  # Distance to consider an enemy "nearby"
        
        for i in range(packet.num_cars):
            car = packet.game_cars[i]
            if car.team == local_player_team:  # Skip teammates
                continue
                
            if car.is_demolished:
                continue
                
            enemy_loc = np.array([car.physics.location.x, car.physics.location.y, car.physics.location.z])
            
            # Check distance to ball/teammate
            distance_to_play = min(
                np.linalg.norm(enemy_loc - ball_loc),
                np.linalg.norm(enemy_loc - teammate_pos) if teammate_pos is not None else float('inf')
            )
            
            if distance_to_play < NEARBY_THRESHOLD:
                nearby_enemies += 1
        
        # Only activate if there's more than one enemy nearby
        return nearby_enemies > 1

    def _check_recovery_situation(self, packet, local_player_index, local_player_team):
        """Check if ball and enemy are on our side while we're on the enemy side"""
        if not hasattr(packet, 'game_ball') or not hasattr(packet.game_ball, 'physics'):
            return False
            
        # Get ball position
        ball_phys = packet.game_ball.physics
        ball_loc = np.array([ball_phys.location.x, ball_phys.location.y, ball_phys.location.z])
        
        # Check if ball is on our side
        is_ball_on_our_side = (local_player_team == 0 and ball_loc[1] < -200) or \
                             (local_player_team == 1 and ball_loc[1] > 200)
                               
        if not is_ball_on_our_side:
            return False
            
        # Get our car position
        if local_player_index >= packet.num_cars:
            return False
            
        our_car = packet.game_cars[local_player_index]
        our_car_loc = np.array([our_car.physics.location.x, our_car.physics.location.y, our_car.physics.location.z])
        
        # Check if we're on enemy side
        we_on_enemy_side = (local_player_team == 0 and our_car_loc[1] > 0) or \
                          (local_player_team == 1 and our_car_loc[1] < 0)
                          
        if not we_on_enemy_side:
            return False
            
        # Check if any enemy is on our side
        enemy_on_our_side = False
        for i in range(packet.num_cars):
            car = packet.game_cars[i]
            if car.team != local_player_team:  # Enemy car
                car_loc = np.array([car.physics.location.x, car.physics.location.y, car.physics.location.z])
                # Check if enemy is on our side
                if (local_player_team == 0 and car_loc[1] < 0) or \
                   (local_player_team == 1 and car_loc[1] > 0):
                    enemy_on_our_side = True
                    break
                    
        return enemy_on_our_side  # If we got here, ball is on our side and we're on enemy side

    def _is_kickoff(self, packet):
        """Check if the current state is a kickoff"""
        # Check if game_info has is_kickoff_pause attribute
        if hasattr(packet.game_info, 'is_kickoff_pause') and packet.game_info.is_kickoff_pause:
            return True
            
        # Manual kickoff detection as fallback
        if hasattr(packet, 'game_ball') and hasattr(packet.game_ball, 'physics'):
            ball_phys = packet.game_ball.physics
            
            # Check if ball is at center position (0,0)
            at_center = (abs(ball_phys.location.x) < 10 and abs(ball_phys.location.y) < 10)
            
            # Check if ball has very low velocity
            low_velocity = (abs(ball_phys.velocity.x) < 10 and 
                           abs(ball_phys.velocity.y) < 10 and
                           abs(ball_phys.velocity.z) < 10)
            
            # Check if game is waiting for kickoff
            is_round_active = hasattr(packet.game_info, 'is_round_active') and packet.game_info.is_round_active
            
            return at_center and low_velocity and is_round_active
            
        return False

    def _is_near_wall(self, car_pos, car_rotation=None):
        """Check if the car is near a wall based on its position and orientation.
        
        Args:
            car_pos: numpy array of car position [x, y, z]
            car_rotation: Optional car rotation (yaw) in radians. If provided, will consider orientation.
            
        Returns:
            tuple: (is_near_wall, wall_type) where wall_type is 'side', 'back', or None
        """
        # Get field dimensions
        field_width, field_length, field_height = 8192, 10240, 2044  # Standard field dimensions
        
        # Base wall threshold
        base_wall_threshold = 200  # Reduced from 300 to 200 units - only deactivate when very close to walls
        
        # Dynamic threshold adjustment based on car's orientation
        wall_threshold = base_wall_threshold
        if car_rotation is not None:
            # If car is facing the wall, reduce threshold (we're more likely to hit it)
            # If car is facing away from wall, increase threshold (we're safer)
            facing_wall = False
            if abs(car_pos[0]) > field_width - base_wall_threshold:  # Near side wall
                # Check if car is facing the wall
                facing_wall = (car_pos[0] > 0 and abs(car_rotation) < math.pi/2) or \
                             (car_pos[0] < 0 and abs(car_rotation) > math.pi/2)
            elif abs(car_pos[1]) > field_length - base_wall_threshold:  # Near back wall
                # Check if car is facing the wall
                facing_wall = (car_pos[1] > 0 and car_rotation > 0) or \
                             (car_pos[1] < 0 and car_rotation < 0)
            
            if facing_wall:
                wall_threshold *= 0.7  # Reduce threshold when facing wall
            else:
                wall_threshold *= 1.3  # Increase threshold when facing away
        
        # Check distance to each wall
        near_side_wall = abs(car_pos[0]) > field_width - wall_threshold
        near_back_wall = abs(car_pos[1]) > field_length - wall_threshold
        
        # Determine which wall we're near
        wall_type = None
        if near_side_wall and near_back_wall:
            # If near both, determine which is closer
            dist_to_side = field_width - abs(car_pos[0])
            dist_to_back = field_length - abs(car_pos[1])
            wall_type = 'side' if dist_to_side < dist_to_back else 'back'
        elif near_side_wall:
            wall_type = 'side'
        elif near_back_wall:
            wall_type = 'back'
        
        # Log wall detection for debugging
        if wall_type:
            self.logger(f"[{self.Name()}] Near {wall_type} wall: pos=({car_pos[0]:.0f}, {car_pos[1]:.0f}), threshold={wall_threshold:.0f}")
        
        return (near_side_wall or near_back_wall), wall_type

    def game_tick_packet_set(self, packet, local_player_index, playername, field_info=None): # Added field_info
        # Store the live field info if provided
        if field_info is not None:
            self.live_field_info = field_info
            # If Nexto is already active and we get new field_info (e.g. map change mid-game?), 
            # we might need to re-initialize or update Nexto's field understanding.
            # For simplicity, current _initialize_nexto_if_needed will use the latest self.live_field_info
            # when it decides to (re)initialize.

        # Add more robust validation for player index
        if local_player_index < 0 or local_player_index >= packet.num_cars:
            if self.nexto_agent_active: 
                self.logger(f"[{self.Name()}] Invalid local_player_index: {local_player_index}. Disabling Nexto if active.")
                self.nexto_agent_active = False
                self.recent_nexto_outputs.clear()
                self._clear_smoothing_history() # Clear smoothing history
                self.last_sample_time = 0.0 # Reset sample timer
            return None

        our_player_data = packet.game_cars[local_player_index]
        local_player_team = our_player_data.team
        
        # Re-add: Store the last game tick packet for the clock thread
        self.last_game_tick_packet = packet
        
        if self.current_player_index != local_player_index or self.current_player_team != local_player_team:
            self.current_player_index = local_player_index
            self.current_player_team = local_player_team
            # Re-add: Reset clock initialization flag
            self.clock_initialized = False
            if self.nexto_instance and self._nexto_initialized_for_player_key != (local_player_index, local_player_team):
                self._nexto_initialized_for_player_key = None 

        # Start the clock thread if needed
        if not self.clock_initialized and self._initialize_nexto_if_needed(packet, local_player_index, local_player_team):
            self.start_clock()

        # Check if the car has wheel contact - don't switch during flips/aerials
        if not our_player_data.has_wheel_contact and self.nexto_agent_active:
            # Car is in the air and Nexto is active - keep Nexto active but don't reset cooldown
            # This prevents the switch happening mid-air, but preserves any active cooldown
            return self.nexto_instance.get_output(packet) if self.nexto_instance else None
        
        # Check for kickoff - don't activate or deactivate during kickoffs
        if self._is_kickoff(packet):
            #self.logger(f"[{self.Name()}] Kickoff detected. No action taken.")
            return None

        should_activate_nexto, activation_reason = self._check_dribble_conditions(packet, local_player_index, local_player_team)
        current_time = packet.game_info.seconds_elapsed

        # Check if we have boost and are near a wall with ball possession
        car_pos = np.array([our_player_data.physics.location.x, our_player_data.physics.location.y, our_player_data.physics.location.z])
        car_rotation = our_player_data.physics.rotation.yaw
        has_boost = our_player_data.boost > 0
        near_wall, wall_type = self._is_near_wall(car_pos, car_rotation)
        we_are_dribbling = self._is_our_car_dribbling(packet, local_player_index) # This variable is used for internal logic

        # Nexto Activation Logic
        # New logic: Activate if 'we are dribbling' or 'opponent dribbling', and not near wall.
        if should_activate_nexto and not near_wall: # Condition simplified
            if not self.nexto_agent_active:
                self.logger(f"[{self.Name()}] {self.GREEN}{self.BOLD}Activating Nexto: {activation_reason}{self.RESET}")
                self.nexto_agent_active = True
                self._clear_smoothing_history() # Clear smoothing history on activation
                self.recent_nexto_outputs.clear() # Clear recent outputs on activation
                self.last_sample_time = 0.0 # Reset sample timer on activation
                self.dribble_stop_timestamp = 0 # Reset dribble stop timestamp
                self.activated_for_dribble = True # Mark as activated for dribble
        elif self.nexto_agent_active:
            # Deactivate Nexto if the condition for activation is no longer met,
            # or if we are too close to a wall, or if we were activated for dribble
            # and dribble condition is no longer met.
            
            # Deactivate if not dribbling (either ours or opponent's), or near wall, or car is in the air
            if not should_activate_nexto or near_wall or not our_player_data.has_wheel_contact:
                # Always apply cooldown for dribble-related deactivations
                if self.dribble_stop_timestamp == 0:
                    self.dribble_stop_timestamp = current_time
                
                if (current_time - self.dribble_stop_timestamp) > self.dribble_cooldown_duration:
                    self.logger(f"[{self.Name()}] {self.RED}{self.BOLD}Deactivating Nexto: Condition ended or near wall.{self.RESET}")
                    self.nexto_agent_active = False
                    self.recent_nexto_outputs.clear()
                    self._clear_smoothing_history() # Clear smoothing history
                    self.last_sample_time = 0.0 # Reset sample timer
                    self.dribble_stop_timestamp = 0 # Reset
                    self.activated_for_dribble = False # Reset flag

        # Run Nexto if active
        if self.nexto_agent_active and self.nexto_instance:
            try:
                # Sample Nexto output once per second for recent_nexto_outputs
                if current_time - self.last_sample_time >= 1.0:
                    nexto_output_for_sample = self.nexto_instance.get_output(packet)
                    self.recent_nexto_outputs.append(nexto_output_for_sample)
                    self.last_sample_time = current_time
                
                # Get the current output from Nexto (real-time)
                nexto_output = self.nexto_instance.get_output(packet)
                
                # Apply smoothing
                # Append current output to histories
                self.steer_history.append(nexto_output.steer)
                self.throttle_history.append(nexto_output.throttle)
                self.pitch_history.append(nexto_output.pitch)
                self.yaw_history.append(nexto_output.yaw)
                self.roll_history.append(nexto_output.roll)

                # Average the historical values
                smoothed_steer = np.mean(list(self.steer_history))
                smoothed_throttle = np.mean(list(self.throttle_history))
                smoothed_pitch = np.mean(list(self.pitch_history))
                smoothed_yaw = np.mean(list(self.yaw_history))
                smoothed_roll = np.mean(list(self.roll_history))

                # Create a new SimpleControllerState with smoothed values
                smoothed_controller_state = SimpleControllerState(
                    steer=float(smoothed_steer),
                    throttle=float(smoothed_throttle),
                    pitch=float(smoothed_pitch),
                    yaw=float(smoothed_yaw),
                    roll=float(smoothed_roll),
                    jump=nexto_output.jump,
                    boost=nexto_output.boost,
                    handbrake=nexto_output.handbrake,
                    use_item=nexto_output.use_item
                )
                
                return smoothed_controller_state
            except Exception as e:
                self.logger(f"[{self.Name()}] Error getting output from Nexto: {e}")
                self.logger(traceback.format_exc())
                self.nexto_agent_active = False 
                self.recent_nexto_outputs.clear()
                self._clear_smoothing_history() # Clear smoothing history
                self.last_sample_time = 0.0 # Reset sample timer
                return None
        
        return None

    def shutdown(self):
        # Removed: self.stop_clock()  # Stop the clock thread
        # Re-add: Stop the clock thread
        self.stop_clock()  # Stop the clock thread
        self.nexto_instance = None
        self.nexto_agent_active = False
        self._clear_smoothing_history() # Clear smoothing history on shutdown

    def reset_info(self):
        try:
            self.field_info = None
            self.live_field_info = None
            # self.bot = None # 'bot' attribute was not used in NextoSwitchPlugin, likely from a template
            # self.input_address = None # Not used
            # self.frame_num = 0 # Not used
            self._clear_smoothing_history() # Clear smoothing history on reset
        except: pass

    def _check_enemy_possession_challenge(self, packet, local_player_index, local_player_team):
        """Check if we're challenging an enemy who has ball possession"""
        # Since we're removing challenge detection, this method should always return False
        return False