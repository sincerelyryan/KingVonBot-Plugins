# plugins/SmallBoostCollectorPlugin.py

import math

try:
    from rlbot.agents.base_agent import SimpleControllerState
except ImportError:
    # Define a fallback SimpleControllerState if rlbot is not available
    # This is useful for linting or running outside the game environment
    class SimpleControllerState:
        def __init__(self, steer=0.0, throttle=0.0, pitch=0.0, yaw=0.0, roll=0.0, jump=False, boost=False, handbrake=False, use_item=False):
            self.steer, self.throttle, self.pitch, self.yaw, self.roll = steer, throttle, pitch, yaw, roll
            self.jump, self.boost, self.handbrake, self.use_item = jump, boost, handbrake, use_item

class Vec3:
    def __init__(self, x=0.0, y=0.0, z=0.0):
        if hasattr(x, 'x') and hasattr(x, 'y') and hasattr(x, 'z'): # Check if x is a vector-like object (e.g., from game packet)
            self.x, self.y, self.z = float(x.x), float(x.y), float(x.z)
        else:
            self.x, self.y, self.z = float(x), float(y), float(z)

    def __add__(self, other: 'Vec3') -> 'Vec3': return Vec3(self.x + other.x, self.y + other.y, self.z + other.z)
    def __sub__(self, other: 'Vec3') -> 'Vec3': return Vec3(self.x - other.x, self.y - other.y, self.z - other.z)
    def __mul__(self, scalar: float) -> 'Vec3': return Vec3(self.x * scalar, self.y * scalar, self.z * scalar)
    def __truediv__(self, scalar: float) -> 'Vec3': 
        return Vec3(self.x / scalar, self.y / scalar, self.z / scalar) if scalar != 0 else Vec3()
    def magnitude(self) -> float: return math.sqrt(self.x**2 + self.y**2 + self.z**2)
    def normalize(self) -> 'Vec3': 
        mag = self.magnitude()
        return self / mag if mag != 0 else Vec3()
    def dot(self, other: 'Vec3') -> float: return self.x * other.x + self.y * other.y + self.z * other.z
    def ang_to(self, ideal_vector: 'Vec3') -> float:
        """Returns the angle in radians between this vector and the ideal_vector."""
        cos_angle = self.normalize().dot(ideal_vector.normalize())
        return math.acos(max(-1.0, min(1.0, cos_angle))) # Clamp to avoid domain errors
    def __str__(self) -> str: return f"Vec3(x={self.x:.2f}, y={self.y:.2f}, z={self.z:.2f})"

def rotator_to_matrix(rotator) -> list[Vec3]: # Assuming rotator has pitch, yaw, roll
    CP, SP = math.cos(rotator.pitch), math.sin(rotator.pitch)
    CY, SY = math.cos(rotator.yaw), math.sin(rotator.yaw)
    CR, SR = math.cos(rotator.roll), math.sin(rotator.roll)

    # Construct the rotation matrix (same as in AirAssistPlugin for consistency)
    # Forward vector (X-axis)
    forward = Vec3(CP * CY, CP * SY, SP)
    # Right vector (Y-axis)
    right = Vec3(CY * SP * SR - CR * SY, SY * SP * SR + CR * CY, -CP * SR)
    # Up vector (Z-axis)
    up = Vec3(-CR * CY * SP - SR * SY, -CR * SY * SP + SR * CY, CP * CR)
    return [forward, right, up]

class SmallBoostCollectorPlugin:
    def __init__(self, ConsoleLogger):
        self.logger = ConsoleLogger
        self.small_boost_pads_info = []  # Will store tuples: (Vec3_location, pad_index)
        self.initialized_pad_locations = False
        self.active_target_pad_index = None # Index of the small pad we are targeting
        self.current_my_car_info = None # To store car info for controller_filter
        self.current_car_orientation_matrix = None # To store car orientation for controller_filter

        # Constants for decision making
        self.MAX_BOOST_TO_COLLECT = 88 # Don't collect if boost is above this
        self.MAX_DISTANCE_TO_PAD = 2000 # Max distance to consider a pad
        self.MAX_ANGLE_TO_PAD_DEGREES = 45.0 # Max angle (degrees) from car's forward to pad
        self.MIN_MAIN_BOT_STEER_FOR_ASSIST = 0.25 # Only assist if main bot steer is less than this
        self.ASSIST_STEER_STRENGTH = 0.25 # How strongly to nudge steering
        self.MIN_THROTTLE_ASSIST = 0.5 # Minimum throttle if assisting towards a pad

        self.logger("SmallBoostCollectorPlugin initialized!")

    def Name(self) -> str:
        return "Small Boost Collector"

    def game_tick_packet_set(self, packet, local_player_index: int, playername: str, field_info):
        # One-time initialization of small boost pad locations
        if not self.initialized_pad_locations and field_info and field_info.num_boosts > 0:
            self.small_boost_pads_info = []
            for i in range(field_info.num_boosts):
                pad = field_info.boost_pads[i]
                if not pad.is_full_boost:
                    self.small_boost_pads_info.append({'location': Vec3(pad.location), 'boost_index': i})
            self.initialized_pad_locations = True
            self.logger(f"Initialized {len(self.small_boost_pads_info)} small boost pads.")

        self.active_target_pad_index = None # Reset target each tick

        if not self.initialized_pad_locations or not packet or not packet.game_cars:
            return None

        my_car = packet.game_cars[local_player_index]
        if my_car.is_demolished:
            return None

        # If boost is high, don't bother collecting small pads
        if my_car.boost > self.MAX_BOOST_TO_COLLECT:
            return None
        
        # Car needs to be in a suitable state
        if not my_car.has_wheel_contact or my_car.jumped or my_car.double_jumped:
            return None

        my_car_pos = Vec3(my_car.physics.location)
        car_orientation_matrix = rotator_to_matrix(my_car.physics.rotation)
        my_car_forward_vec = car_orientation_matrix[0]

        best_target_score = -1.0

        for pad_info in self.small_boost_pads_info:
            pad_index = pad_info['boost_index']
            pad_loc = pad_info['location']

            if not packet.game_boosts[pad_index].is_active:
                continue

            dist_to_pad = (pad_loc - my_car_pos).magnitude()

            if dist_to_pad > self.MAX_DISTANCE_TO_PAD or dist_to_pad < 50: # Too far or too close (already on it)
                continue

            dir_to_pad = (pad_loc - my_car_pos).normalize()
            angle_to_pad_rad = my_car_forward_vec.ang_to(dir_to_pad)
            angle_to_pad_deg = math.degrees(angle_to_pad_rad)

            if angle_to_pad_deg > self.MAX_ANGLE_TO_PAD_DEGREES:
                continue
            
            # Scoring: prefer closer pads and pads more aligned with current heading
            # Lower angle is better (closer to 0), shorter distance is better.
            # We want to maximize this score.
            # Angle score: (1 - normalized_angle), Distance score: (1 - normalized_distance)
            angle_score_factor = (self.MAX_ANGLE_TO_PAD_DEGREES - angle_to_pad_deg) / self.MAX_ANGLE_TO_PAD_DEGREES
            dist_score_factor = (self.MAX_DISTANCE_TO_PAD - dist_to_pad) / self.MAX_DISTANCE_TO_PAD
            current_target_score = (angle_score_factor * 0.7) + (dist_score_factor * 0.3) # Weight angle more

            if current_target_score > best_target_score:
                best_target_score = current_target_score
                self.active_target_pad_index = pad_index
        
        
        # Store car info for controller_filter if we might use it
        if my_car: # Ensure my_car is valid before storing
            self.current_my_car_info = my_car
            self.current_car_orientation_matrix = car_orientation_matrix # Stored from earlier in this method
        else:
            self.current_my_car_info = None
            self.current_car_orientation_matrix = None

        # if self.active_target_pad_index is not None:
        #     self.logger(f"Targeting small pad index: {self.active_target_pad_index}, Score: {best_target_score:.2f}")
        return None

    def controller_filter(self, controller: SimpleControllerState) -> SimpleControllerState:
        if self.active_target_pad_index is None or not self.current_my_car_info or not self.current_car_orientation_matrix:
            return controller

        my_car = self.current_my_car_info
        car_orientation_matrix = self.current_car_orientation_matrix
        my_car_pos = Vec3(my_car.physics.location)
        my_car_forward_vec = car_orientation_matrix[0]
        my_car_right_vec = car_orientation_matrix[1]

        # Don't interfere if main bot is actively steering, or if car is not in a simple driving state
        if abs(controller.steer) > self.MIN_MAIN_BOT_STEER_FOR_ASSIST:
            return controller
        if not my_car.has_wheel_contact or my_car.jumped or my_car.double_jumped or my_car.is_demolished:
            return controller

        target_pad_info = next((pad for pad in self.small_boost_pads_info if pad['boost_index'] == self.active_target_pad_index), None)
        if not target_pad_info:
            return controller
        
        target_pad_loc = target_pad_info['location']

        # Calculate steer adjustment
        vector_to_target = target_pad_loc - my_car_pos
        local_target_x = vector_to_target.dot(my_car_forward_vec)
        local_target_y = vector_to_target.dot(my_car_right_vec)

        angle_to_target_rad = math.atan2(local_target_y, local_target_x) if local_target_x != 0 else math.copysign(math.pi / 2, local_target_y)
        
        # target_steer_for_pad is how much the bot *would* steer if it was fully aiming for the pad.
        # We use a large factor here (e.g., 2.5) to get a responsive base steer value, then blend it.
        target_steer_for_pad = max(-1.0, min(1.0, angle_to_target_rad * 2.5)) 

        # Gentle nudge: blend current steer with target steer for pad
        adjusted_steer = controller.steer * (1.0 - self.ASSIST_STEER_STRENGTH) + target_steer_for_pad * self.ASSIST_STEER_STRENGTH
        controller.steer = max(-1.0, min(1.0, adjusted_steer))

        # Optional: Throttle assist if aligned and not boosting, to ensure we reach the pad
        if abs(angle_to_target_rad) < math.radians(10) and not controller.boost:
            controller.throttle = max(controller.throttle, self.MIN_THROTTLE_ASSIST)
            
        # self.logger(f"Assisting steer: {controller.steer:.2f} towards pad {self.active_target_pad_index}")
        return controller

