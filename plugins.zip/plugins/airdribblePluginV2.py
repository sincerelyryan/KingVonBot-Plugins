# rocket_2v2_wall_freestyle_master_v3.py
# WALL FREESTYLE MASTER v3 — Wall → Ceiling → Aerial Freestyle & Air Dribble (2v2 training, offline)
# Autor: ChatGPT (2025) - nadogradnja s Advanced Ball Awareness + ceiling transition + dodatne heuristike
# NAMJENA: OFFLINE / SANDBOX / TRAINING. Ne koristiti za online automatizaciju.

import math
import random
from types import SimpleNamespace

# ---------------------- POMOĆNE FUNKCIJE ----------------------
def vec_len(v):
    try:
        return math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
    except Exception:
        return 0.0

def dist(a, b):
    try:
        return math.sqrt((a.x - b.x)**2 + (a.y - b.y)**2 + (a.z - b.z)**2)
    except Exception:
        return 0.0

def flat_dist(a, b):
    try:
        return math.sqrt((a.x - b.x)**2 + (a.y - b.y)**2)
    except Exception:
        return 0.0

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def angle_to(a, b):
    dx = b.x - a.x
    dy = b.y - a.y
    return math.atan2(dy, dx)

def predict_ball_pos(ball, ticks=24, dt=1/120.0, gravity=-650):
    """
    Jednostavna kratkoročna predikcija: linearna + gravity na z osi.
    ticks: koliko frameova unaprijed (npr. 24 = ~0.2s)
    dt: trajanje framea (default 1/120)
    Vrati SimpleNamespace(x,y,z) poziciju.
    """
    try:
        if hasattr(ball, "physics"):
            pos = ball.physics.location
            vel = ball.physics.velocity
        else:
            pos = ball
            vel = getattr(ball, "velocity", SimpleNamespace(x=0, y=0, z=0))

        x = pos.x
        y = pos.y
        z = pos.z
        vx = vel.x
        vy = vel.y
        vz = vel.z
    except Exception:
        return SimpleNamespace(x=0.0, y=0.0, z=0.0)
    for _ in range(ticks):
        x += vx * dt
        y += vy * dt
        z += vz * dt
        vz += gravity * dt
        # ground clamp (ne simuliramo bounce ovdje)
        if z < 6:
            z = 6
            vz = -vz * 0.2  # blagi odbitak
    return SimpleNamespace(x=x, y=y, z=z)

# ---------------------- GLAVNA KLASA PLUGINA ----------------------
class Rocket2v2WallFreestyleMasterV3:
    """
    Single-file Vutrium/Spark plugin:
    Fokus: isključivo zidni pristupi -> ceiling -> aerial freestyle / air dribble / flip reset
    Napredno: kratkoročna predikcija lopte i izbor najboljeg zida/ceiling rute.
    """

    def __init__(self, ConsoleLogger=None):
        self.Name = "Rocket2v2WallFreestyleMasterV3" # Capitalized per PluginGuide
        self.name = self.Name # Keep lowercase alias just in case
        self.logger = ConsoleLogger
        self.index = 0
        self.enabled = True

        # modes: WallApproach -> WallClimb -> CeilingRide -> LaunchAerial -> AerialFreestyle -> GroundFreestyle -> RecoverToWall
        # NEW DEFENSE MODES: ShadowDefense -> GoalLine -> PanicClear
        # MECHANICS: WaveDashRecovery, DoomseeDish
        self.mode = "WallApproach"
        self.last_inputs = {"throttle":0.0, "steer":0.0, "pitch":0.0, "yaw":0.0, "roll":0.0}
        self.smooth_factor = 0.15

        # heuristike / pragovi
        self.wall_threshold = 4100     # y coordinate threshold for "near wall" (increased to allow more mid-field freestyle)
        self.ceiling_height = 1800     # z above which consider ceiling play
        self.min_boost_to_fly = 10
        self.max_freestyle_time = 1200 # ticks (significantly increased ~10s)
        self.jump_cooldown = 0
        self.jump_ready = True
        self.wave_dash_timer = 0

        # state flags
        self.freestyle_timer = 0
        self.last_tick = 0
        self.aggressive = True
        self.team_index = 0 # 0 for blue, 1 for orange (detected later)
        self.teammate_index = -1
        
        # Game Mode Detection
        self.game_mode = "2v2" # Default to 2v2 logic
        self.is_1v1 = False

    # -------------------- lifecycle --------------------
    def initialize(self):
        print("🚀 Wall Freestyle Master v3 initialized (Advanced Ball Awareness ON).")

    def shutdown(self):
        self.enabled = False
        print("🛑 Wall Freestyle Master v3 shutdown.")

    def main(self, command: str = ""):
        cmd = command.lower().strip() if command else ""
        if cmd == "/toggle":
            self.enabled = not self.enabled
            print(f"Plugin {'ENABLED' if self.enabled else 'DISABLED'}.")
        elif cmd == "/mode":
            print(f"Current state: {self.mode} | Game Mode: {self.game_mode}")
        elif cmd == "/reset":
            self.mode = "WallApproach"
            self.freestyle_timer = 0
            print("Mode reset to WallApproach.")
        elif cmd == "/aggressive":
            self.aggressive = not self.aggressive
            print(f"Aggressive: {self.aggressive}")
        elif cmd == "/1v1":
            self.game_mode = "1v1"
            self.is_1v1 = True
            print("Switched to 1v1 Mode (No Teammate Reliance).")
        elif cmd == "/2v2":
            self.game_mode = "2v2"
            self.is_1v1 = False
            print("Switched to 2v2 Mode (Team Play Enabled).")

    # -------------------- smoothing helper --------------------
    def smooth(self, key, val):
        prev = self.last_inputs.get(key, 0.0)
        new = prev + (val - prev) * self.smooth_factor
        self.last_inputs[key] = new
        return new

    # -------------------- game tick update --------------------
    def game_tick_packet_set(self, packet, local_player_index=0, playername=None, field_info=None):
        """
        Update flags, predikcije i odluči target zid/ceiling/ground.
        Sada uključuje i LOGIKU OBRANE (Defense).
        """
        self.packet = packet # Store for other methods to access opponents
        self.last_tick += 1
        try:
            car = packet.game_cars[self.index]
            ball_loc = packet.game_ball.physics.location
            ball = packet.game_ball
            self.team_index = car.team
        except Exception:
            return

        # Find Teammate & Auto-Detect Mode
        self.teammate_index = -1
        teammate_car = None
        player_count = 0
        
        for i in range(packet.num_cars):
            # Count cars on my team
            if packet.game_cars[i].team == self.team_index:
                player_count += 1
                if i != self.index:
                    self.teammate_index = i
                    teammate_car = packet.game_cars[i]
        
        # Auto-switch logic: If only 1 player on team, force 1v1 mode
        if player_count == 1:
            self.is_1v1 = True
            self.game_mode = "1v1"
        elif player_count > 1:
            self.is_1v1 = False
            self.game_mode = "2v2" # or 3v3, treated same

        # kratkoročna predikcija lopte
        predicted = predict_ball_pos(ball, ticks=36)  # ~0.3s naprijed

        # --- HIGH LEVEL DECISION: ATTACK vs DEFENSE ---
        my_goal_y = -5120 if self.team_index == 0 else 5120
        opponent_goal_y = -my_goal_y
        
        # 2. Are we needed on defense?
        ball_on_my_half = (ball_loc.y < 0 and self.team_index == 0) or (ball_loc.y > 0 and self.team_index == 1)
        ball_moving_to_goal = (ball.physics.velocity.y < 0 and self.team_index == 0) or (ball.physics.velocity.y > 0 and self.team_index == 1)
        
        # Teammate logic (Only applies in 2v2)
        i_am_closest = True
        if teammate_car and not self.is_1v1:
            dist_me = dist(car.physics.location, ball_loc)
            dist_tm = dist(teammate_car.physics.location, ball_loc)
            
            # --- AGGRESSION TUNING ---
            # If teammate is significantly closer (e.g., 500 units), let them have it.
            # Don't challenge if distance is roughly equal (double commit prevention).
            if dist_tm < dist_me - 100:
                i_am_closest = False
                
        # Defensive Triggers:
        # A. Ball is deep in my territory -> PANIC CLEAR
        # TUNED DOWN: 2500 is safer balance than 3000.
        panic_zone = abs(ball_loc.y - my_goal_y) < 2500
        
        # B. Teammate is attacking (closer) -> SHADOW DEFENSE (2v2 only)
        teammate_attacking = (not i_am_closest and not ball_on_my_half) and not self.is_1v1
        
        # C. Ball on my half -> CHALLENGE / DEFENSE
        # TUNED: Only force defense if we are closest or it's an imminent shot.
        shot_on_net = False
        if abs(ball.physics.velocity.y) > 100:
            time_to_goal = abs((my_goal_y - ball_loc.y) / ball.physics.velocity.y)
            pred_x_at_goal = ball_loc.x + (ball.physics.velocity.x * time_to_goal)
            shot_on_net = abs(pred_x_at_goal) < 900 and ball_moving_to_goal

        # Respect teammate priority even on defense (unless shot on net)
        need_to_save = (ball_on_my_half and i_am_closest) or shot_on_net

        # Override Freestyle for Defense?
        is_freestyling = self.mode in ["AerialFreestyle", "LaunchAerial", "CeilingRide"]
        can_abort = not is_freestyling or (car.has_wheel_contact)
        
        # FORCE ABORT if shot on net detected, even if mid-air freestyle (try to save!)
        if shot_on_net: can_abort = True

        defense_mode = None
        if can_abort or self.mode == "GroundFreestyle":
            if panic_zone:
                defense_mode = "PanicClear"
            elif need_to_save:
                if ball_moving_to_goal or shot_on_net:
                     defense_mode = "GoalLine" # Goalie mode
                else:
                     defense_mode = "ShadowDefense"
            elif teammate_attacking:
                defense_mode = "ShadowDefense" # Support role
            
            # --- PASSIVE ROTATION ---
            # If not closest, and not freestyling, always shadow/support.
            elif not i_am_closest and not is_freestyling:
                 defense_mode = "ShadowDefense"

        if defense_mode:
            self.mode = defense_mode
        else:
            # --- OFFENSIVE LOGIC (Existing) ---
            
            # Izaberi najbolji zid (lijevi ili desni) na osnovu predicted.y
            self.preferred_wall_side = 1 if predicted.y > 0 else -1
            
            # Keep existing freestyle modes if active and within timer
            if self.mode in ["AerialFreestyle", "GroundFreestyle"] and self.freestyle_timer < self.max_freestyle_time:
                 # Check exit conditions
                is_grounded = car.has_wheel_contact and car.physics.location.z < 50
                if self.mode == "AerialFreestyle" and is_grounded:
                    self.mode = "GroundFreestyle" # Transition to ground freestyle on landing
                    self.freestyle_timer = 0
                elif self.mode == "GroundFreestyle" and not is_grounded and car.physics.location.z > 200:
                    self.mode = "AerialFreestyle" # Transition to air if we pop up
                    self.freestyle_timer = 0
                pass
            else:
                 # Standard Attack Transitions
                car_loc = car.physics.location
                car_z = car_loc.z
                # RELAXED WALL THRESHOLD: Consider wall play from further out (0.5 instead of 0.75)
                # This makes it enter WallClimb/Approach much more often.
                near_wall = (abs(car_loc.y) > self.wall_threshold * 0.5) or (abs(predicted.y) > self.wall_threshold * 0.5)
                close_to_ball = dist(car_loc, ball_loc) < 900
                is_grounded = car.has_wheel_contact and car_z < 50
                 
                if near_wall and car_z < 220:
                    self.mode = "WallClimb"
                elif car_z > 300 and (predicted.z > 200 or close_to_ball):
                    self.mode = "LaunchAerial"
                elif car_z > self.ceiling_height:
                    self.mode = "CeilingRide"
                elif is_grounded and not near_wall:
                    self.mode = "GroundFreestyle" # Default to ground play if open
                elif car_z > 100 and not near_wall:
                    self.mode = "AerialFreestyle"
                else:
                    self.mode = "WallApproach"

        # refresh jump readiness
        if self.jump_cooldown > 0:
            self.jump_cooldown -= 1
        else:
            self.jump_ready = True

        # store predicted for controller usage
        self._last_predicted_ball = predicted
        self._last_ball = ball_loc
        self._last_ball_full = ball
        self._last_car = car

    # -------------------- controller filter --------------------
    def controller_filter(self, controller, car=None, ball=None):
        """
        Ovdje obrađujemo svaki tick inputa. Vutrium zove ovu metodu i očekuje modificirani controller.
        """
        if not self.enabled or car is None or ball is None:
            return controller

        # ensure attributes exist on controller
        for attr in ("throttle","steer","pitch","yaw","roll","boost","jump", "handbrake"):
            if not hasattr(controller, attr):
                setattr(controller, attr, False if attr in ("boost","jump", "handbrake") else 0.0)

        # apply smoothing on incoming controller values (keeps stable)
        controller.throttle = self.smooth("throttle", getattr(controller, "throttle", 0.0))
        controller.steer    = self.smooth("steer", getattr(controller, "steer", 0.0))
        controller.pitch    = self.smooth("pitch", getattr(controller, "pitch", 0.0))
        controller.yaw      = self.smooth("yaw", getattr(controller, "yaw", 0.0))
        controller.roll     = self.smooth("roll", getattr(controller, "roll", 0.0))

        # choose behavior based on current mode
        try:
            # Force roll for aerial modes at start to ensure default is set
            # ALSO DISABLE SMOOTHING for Roll to ensure it's instant
            if self.mode in ["AerialFreestyle", "LaunchAerial", "CeilingRide"]:
                 # Direct assignment to prevent smoothing interference?
                 # No, just set high value.
                 r_val = float(-1.0 if self.preferred_wall_side < 0 else 1.0)
                 controller.roll = r_val
                 self.last_inputs["roll"] = r_val # Bypass smoother for roll

            if self.mode == "WaveDashRecovery":
                self._wave_dash_recovery(controller, car, ball)
            elif self.mode == "WallApproach":
                self._wall_approach(controller, car, ball)
            elif self.mode == "WallClimb":
                self._wall_climb(controller, car, ball)
            elif self.mode == "CeilingRide":
                self._ceiling_ride(controller, car, ball)
            elif self.mode == "LaunchAerial":
                self._launch_aerial(controller, car, ball)
            elif self.mode == "AerialFreestyle":
                self._aerial_freestyle(controller, car, ball)
            elif self.mode == "GroundFreestyle":
                self._ground_freestyle(controller, car, ball)
            # DEFENSE HANDLERS
            elif self.mode == "ShadowDefense":
                self._shadow_defense(controller, car, ball)
            elif self.mode == "GoalLine":
                self._goal_line(controller, car, ball)
            elif self.mode == "PanicClear":
                self._panic_clear(controller, car, ball)
            elif self.mode == "DoomseeDish":
                self._doomsee_dish(controller, car, ball)
            else:
                # fallback to approach
                self._wall_approach(controller, car, ball)
                
            # GLOBAL DOOMSEE DISH CHECK
            # If we are near opponent backboard/goal and ball is there
            opp_goal_y = 5120 if self.team_index == 0 else -5120
            # INCREASED RANGE: Trigger from further out (1000 units instead of 300)
            ball_near_backboard = abs(ball.physics.location.y - opp_goal_y) < 1000
            ball_height = ball.physics.location.z
            
            # CORNER CHECK: Even if on wall, if in corner near goal, DO IT.
            car_in_corner = abs(car.physics.location.y) > 4000 and abs(car.physics.location.x) > 2000
            
            # INCREASED DISTANCE: Allow starting dish from 1500 units away
            # FORCE MODE: Even if on WallClimb, if dish opportunity exists, TAKE IT.
            if ball_near_backboard and ball_height > 200 and ball_height < 1500 and dist(car.physics.location, ball.physics.location) < 1500:
                if self.mode != "DoomseeDish":
                    # If we are on wall, jump off first?
                    # DoomseeDish logic handles the jump.
                    self.mode = "DoomseeDish"

            # GLOBAL WAVE DASH CHECK
            # If we are falling close to ground with momentum, trigger wave dash recovery
            # Only if NOT in a delicate mode like Dribbling or Aerial or Dish
            # FORCE IT: Make it happen more often by relaxing the Z velocity check and allowing it in more modes
            
            # Allow in GroundFreestyle if NOT carrying the ball (dist > 300)
            is_carrying = (self.mode == "GroundFreestyle" and dist(car.physics.location, ball.physics.location) < 300)
            
            safe_to_dash = self.mode not in ["AerialFreestyle", "LaunchAerial", "WallClimb", "CeilingRide", "WaveDashRecovery", "DoomseeDish"] and not is_carrying
            
            # Relaxed Z threshold: Trigger even on small hops (< 50 height, even if not falling fast)
            # This allows it to chain dashes or dash after small jumps.
            if safe_to_dash and car.physics.location.z < 150 and self.jump_ready:
                # Ensure we are actually off the ground slightly or just landed?
                # Wave dash requires being AIRBORNE but CLOSE.
                if not car.has_wheel_contact:
                     self.mode = "WaveDashRecovery"
                     self.wave_dash_timer = 0

            # GLOBAL TURTLE RECOVERY (Upside down on ground)
            if self.mode not in ["WaveDashRecovery", "DoomseeDish"] and car.has_wheel_contact and car.physics.location.z < 50:
                # Check if we are upside down (Up vector z is negative)
                # We don't have up vector easily, but we can check Roll/Pitch or just use gravity heuristic?
                # Actually, standard heuristic: If wheel contact is True but we are not moving or controls feel reversed?
                # Better: Check dot product of car Up vector with World Up.
                # Since we don't have matrix math here easily, check Roll magnitude.
                # If Roll is near pi or -pi, we are upside down.
                if abs(car.physics.rotation.roll) > 2.0 or abs(car.physics.rotation.pitch) > 1.4:
                     controller.jump = True
                     controller.roll = 1.0 # Flip over
                    
        except Exception:
            # safe fallback: basic drive to wall
            controller.throttle = 1.0
            controller.boost = car.boost > self.min_boost_to_fly

        # decrement jump cooldown if set
        if self.jump_cooldown > 0:
            self.jump_cooldown -= 1

        # UPDATE LAST INPUTS WITH FINAL VALUES
        # This ensures smoothing works based on what we actually sent, not just what came in.
        self.last_inputs["throttle"] = float(controller.throttle)
        self.last_inputs["steer"] = float(controller.steer)
        self.last_inputs["pitch"] = float(controller.pitch)
        self.last_inputs["yaw"] = float(controller.yaw)
        self.last_inputs["roll"] = float(controller.roll)

        return controller

    def _wave_dash_recovery(self, c, car, ball):
        """
        Execute a forward wave dash for speed recovery.
        Sequence: Tilt Nose Up -> Wait for rear wheels -> Jump + Pitch Forward
        """
        self.wave_dash_timer += 1
        
        # 1. Align car (Look forward, drift if needed)
        c.yaw = 0.0
        c.steer = 0.0
        c.handbrake = True # Slide on landing
        
        # 2. Check for contact immediately to trigger the dash
        if car.has_wheel_contact:
             # We touched! Now FLIP FORWARD immediately
             if self.wave_dash_timer < 25:
                 c.jump = True
                 c.pitch = -1.0 # Front flip
                 c.throttle = 1.0
                 self.jump_ready = False
                 self.jump_cooldown = 10
             else:
                 # Done, exit
                 self.mode = "WallApproach"
                 self.wave_dash_timer = 0

        # 3. If no contact yet, Tilt back slightly to land rear wheels first
        elif self.wave_dash_timer < 20:
             c.pitch = 1.0 # Nose Up
             c.throttle = 1.0
        
        # Safety timeout
        if self.wave_dash_timer > 30:
            self.mode = "WallApproach"

    def _doomsee_dish(self, c, car, ball):
        """
        Doomsee Dish: Jump from side of goal/backboard to dunk a rebounding ball.
        """
        pred = getattr(self, "_last_predicted_ball", ball)
        
        # 1. Drive/Fly towards the ball's future location (which should be just in front of goal)
        target_x = clamp(pred.x, -800, 800) # Aim for goal width
        target_y = pred.y
        target_z = pred.z
        
        target = SimpleNamespace(x=target_x, y=target_y, z=target_z)
        
        # 2. Mechanics
        # Usually requires a jump + fast aerial or just a side flip
        
        c.throttle = 1.0
        c.boost = True
        
        # Aim
        angle = angle_to(car.physics.location, target)
        c.steer = clamp(angle, -1.0, 1.0)
        
        dist_to_ball = dist(car.physics.location, target)
        
        # Jump if needed
        if self.jump_ready and (car.physics.location.z < target.z - 100 or dist_to_ball < 400):
            c.jump = True
            
            # If close, FLIP into goal
            if dist_to_ball < 250:
                 c.pitch = -1.0 # Front flip dunk
                 self.jump_ready = False
                 self.jump_cooldown = 20
            else:
                 # Fast Aerial up
                 c.pitch = -1.0
                 self.jump_ready = False
                 self.jump_cooldown = 10
                 
        # Air control if airborne
        if not car.has_wheel_contact:
             # Point nose at ball
             # Simple aim
             c.yaw = clamp(angle, -1.0, 1.0)
             if car.physics.location.z < target.z:
                 c.pitch = -1.0
             
             # If close in air, roll to hit with wheels or roof
             # Ensure dist_to_ball is defined in scope before usage
             dist_to_ball = dist(car.physics.location, target)
             if dist_to_ball < 200:
                  c.roll = 1.0

    # -------------------- MANEUVERS --------------------
    def _wall_approach(self, c, car, ball):
        # Cilj: brzo doći do preferred wall-a blizu predicted ball
        pred = getattr(self, "_last_predicted_ball", ball)
        # find an aim point on wall slightly above predicted ball
        target_y = self.wall_threshold * (1 if pred.y > 0 else -1)
        aim_point = SimpleNamespace(x=pred.x * 0.6, y=target_y, z=max(100, pred.z * 0.6))
        angle = angle_to(car.physics.location, aim_point)
        c.throttle = 1.0
        c.steer = clamp(angle, -1.0, 1.0)
        c.boost = car.boost > self.min_boost_to_fly

        # once close to the wall aim point, small jump to latch onto wall
        if flat_dist(car.physics.location, aim_point) < 600 and self.jump_ready:
            c.jump = True
            self.jump_ready = False
            self.jump_cooldown = 12

    def _wall_climb(self, c, car, ball):
        """
        Climb wall. Decide: Launch (Air Dribble) OR Ceiling Setup?
        FIXED: Aggressive launch if ball is near, prevent driving down.
        """
        pred = getattr(self, "_last_predicted_ball", ball)
        goal_y = -5120 if pred.y > 0 else 5120
        dir_to_goal = math.atan2(goal_y - car.physics.location.y, -car.physics.location.x)
        
        c.throttle = 1.0
        
        # --- WALL INTERCEPT CHECK ---
        # Is the ball close to the wall (and us)?
        # If so, JUMP FOR IT immediately instead of climbing endlessly or driving down.
        
        dist_to_ball = dist(car.physics.location, pred)
        # RELAXED: Don't strictly require ball to be "near side walls" (>3000).
        # Sometimes ball is slightly off wall (e.g. x=2500) but we are on wall.
        ball_reachable_from_wall = abs(pred.x) > 2000
        
        # If we are on wall (z > 50) and ball is close...
        # RELAXED DISTANCE: 2000 units.
        if car.physics.location.z > 50 and dist_to_ball < 2000 and ball_reachable_from_wall:
             # Force Launch!
             if self.jump_ready:
                 c.jump = True
                 # Angle car towards ball
                 # On wall, Yaw rotates around wall normal? No, Pitch does.
                 # Pitch -1 = Nose up. Pitch 1 = Nose down.
                 # Yaw -1 = Turn Left (down wall?), Yaw 1 = Turn Right (up wall?)
                 
                 # Simpler: Just jump + air roll to ball in LaunchAerial
                 c.pitch = 0.18 # Slight pitch up to detach
                 self.jump_ready = False
                 self.jump_cooldown = 15
                 self.mode = "LaunchAerial"
                 self.freestyle_timer = 0
                 return # EXIT

        # DECISION: Ceiling or Air Dribble?
        go_for_ceiling = (car.physics.location.z > 800) and (pred.z > 1000) and (car.boost > 30)
        
        if go_for_ceiling:
            # Drive UP to ceiling
            c.throttle = 1.0
            # Steer slightly towards ball x/y?
            # c.yaw = ...
            # Just go up.
            pass
            
            # Transition to CeilingRide if z > ~1900
            if car.physics.location.z > 1950:
                self.mode = "CeilingRide"
                
        else:
            # Standard Wall to Air Dribble Launch
            # Don't drive down! If not ceiling, just launch soon.
            
            c.pitch = 0.35 # Nose up
            c.yaw = clamp(dir_to_goal * 0.2, -1, 1)
            c.boost = car.boost > self.min_boost_to_fly
            
            # Jump logic: Relaxed Z requirement.
            # If we are on wall and have speed, launch.
            if car.physics.location.z > 100 and self.jump_ready:
                c.jump = True
                c.pitch = 0.18 # Nose up/away from wall
                self.jump_ready = False
                self.jump_cooldown = 18
                self.mode = "LaunchAerial"
                self.freestyle_timer = 0

    def _ceiling_ride(self, c, car, ball):
        # Voznja po stropu: cilj je zadržati momentum i kad lopta ispod, odskočiti
        pred = getattr(self, "_last_predicted_ball", ball)
        
        # Drive forward but keep traction
        c.throttle = 1.0
        
        # Calculate horizontal distance to ball
        flat_d = flat_dist(car.physics.location, pred)
        
        # If we are effectively "above" the ball (horizontally close), jump down
        if flat_d < 400 and pred.z < car.physics.location.z - 200 and self.jump_ready:
            c.jump = True
            c.pitch = 1.0 # Nose down hard to get off ceiling fast
            self.jump_ready = False
            self.jump_cooldown = 20
            self.mode = "AerialFreestyle" # Go straight to freestyle
            self.freestyle_timer = 0
        else:
            # Just drive towards ball on ceiling
            # Simple steering logic for ceiling (remember controls are inverted relative to ground view often)
            local_target = SimpleNamespace(x=pred.x, y=pred.y, z=car.physics.location.z)
            angle = angle_to(car.physics.location, local_target)
            c.steer = clamp(angle, -1.0, 1.0)
            c.boost = car.boost > self.min_boost_to_fly and flat_d > 1000

    def _launch_aerial(self, c, car, ball):
        """
        Nakon wall jump: agresivni launch prema predikciji lopte,
        UZ KORIŠTENJE DIRECTIONAL AIR ROLL-a odmah pri polijetanju.
        """
        pred = getattr(self, "_last_predicted_ball", ball)
        
        # 1. Basic aiming
        goal_y = -5120 if pred.y > 0 else 5120
        toward_goal_x = pred.x * 0.85
        aim = SimpleNamespace(x=toward_goal_x, y=pred.y, z=max(pred.z, 150))
        angle = angle_to(car.physics.location, aim)
        
        c.throttle = 1.0
        c.boost = car.boost > self.min_boost_to_fly
        
        # 2. Force Directional Air Roll ASAP
        # Choose roll direction based on which wall we came from or just preference
        roll_dir = -1.0 if self.preferred_wall_side < 0 else 1.0
        c.roll = roll_dir
        
        # 3. Kuxir Twist Launch
        # While rolling, we need to steer.
        # Standard launch pitch is usually -1 (back) to gain height quickly.
        # But with Air Roll, we need to Tornado Twist to angle towards ball.
        c.yaw = -roll_dir * 0.5 # Slight tornado to correct
        c.pitch = 0.8 # Pitch back hard to climb (FIXED SIGN)
        
        # 4. Early transition to freestyle to prioritize Reset
        # If we are airborne and moving towards ball, just go freestyle immediately
        # to let the freestyle logic handle the flip reset setup.
        if car.physics.location.z > 200:
            self.mode = "AerialFreestyle"
            self.freestyle_timer = 0

    def _aerial_freestyle(self, c, car, ball):
        # This method kept for compatibility if external code calls it
        self._aerial_freestyle_common(c, car, ball)

    def _aerial_freestyle_common(self, c, car, ball):
        # Full freestyle control: FORCED CONTINUOUS AIR ROLL
        
        pred = getattr(self, "_last_predicted_ball", ball)
        
        # --- ACCURACY IMPROVEMENT: PREDICTIVE AIMING ---
        # Instead of aiming at the ball's current predicted location,
        # aim slightly 'through' the ball towards the goal.
        
        goal_y = -5120 if self.team_index == 1 else 5120
        vec_ball_to_goal = SimpleNamespace(x=0 - pred.x, y=goal_y - pred.y, z=0)
        dist_ball_goal = vec_len(vec_ball_to_goal)
        
        if dist_ball_goal > 100:
            # Normalize
            vec_ball_to_goal.x /= dist_ball_goal
            vec_ball_to_goal.y /= dist_ball_goal
            
            # Offset the target: We want to hit the BACK of the ball relative to goal.
            # So we aim at a point slightly 'behind' the ball.
            # No, that's for dribbling. For aerials, we aim AT the contact point.
            # Contact point is: Ball Pos - (Radius * DirectionToGoal)
            
            # Target = Ball Pos - (92 * VecToGoal)
            # This makes the car hit the specific spot on the ball that pushes it to goal.
            target = SimpleNamespace(x=pred.x - (vec_ball_to_goal.x * 50),
                                     y=pred.y - (vec_ball_to_goal.y * 50),
                                     z=pred.z)
        else:
            target = SimpleNamespace(x=pred.x, y=pred.y, z=pred.z)

        # --- FORCE AIR ROLL LOGIC ---
        # The user reported no air roll usage during dribbles.
        # We will force a hard roll value to ensure it spins.
        
        # Use a consistent direction based on team or just hardcode left/right
        # to ensure it's always spinning.
        roll_dir = -1.0 # Roll Left (common for right-hand setups)
        c.roll = roll_dir
        
        # --- DOUBLE TAP / REBOUND READ LOGIC ---
        # Detect if we are setting up for a backboard read
        opp_goal_y = 5120 if self.team_index == 0 else -5120
        dist_ball_backboard = abs(pred.y - opp_goal_y)
        
        # Check if ball is moving towards backboard
        ball_vel = getattr(ball, "physics", ball).velocity
        ball_vel_y = ball_vel.y
        moving_to_backboard = (ball_vel_y > 0 and self.team_index == 0) or (ball_vel_y < 0 and self.team_index == 1)
        
        target = SimpleNamespace(x=pred.x, y=pred.y, z=pred.z)
        
        is_double_tap_mode = False
        
        # 1. PRE-BOUNCE: Ball is flying to backboard, and we are relatively close.
        # We need to predict the bounce and NOT fly into the wall.
        if moving_to_backboard and dist_ball_backboard < 1500 and pred.z > 400:
             # Target the "Rebound Spot" (outwards from wall) instead of the ball itself
             # This creates natural separation so we can hit the double tap
             rebound_offset = 600 if self.team_index == 0 else -600 # Look 600 units back from wall
             
             # We want to be where the ball will be, but backed off on the Y axis
             target.y = pred.y - rebound_offset
             is_double_tap_mode = True
             
        # 2. POST-BOUNCE: Ball is moving away from backboard but still near it (The Rebound)
        elif (not moving_to_backboard) and dist_ball_backboard < 1600 and pred.z > 300:
             # ATTACK THE DOUBLE TAP!
             # Target is the ball (default), but we ensure we are aggressive
             is_double_tap_mode = True
        
        # 2. Kuxir Twist Navigation (Tornado Spin)
        # To fly while rolling, we must use YAW in the opposite direction or sync PITCH/YAW.
        # Simplest freestyle mechanic: Tornado Spin (Roll Left + Yaw Right).
        
        # To actually HIT the ball while spinning, we need to stop spinning momentarily if we are off target?
        # NO, we adjust pitch/yaw inputs relative to the roll.
        
        # BASIC TORNADO SPIN:
        # Roll Left (-1) + Yaw Right (1)
        c.yaw = -roll_dir
        
        # IF WE NEED TO TURN:
        # While spinning, Pitch and Yaw axes rotate.
        # To simplify: We will stick to the "Kuxir Twist" (Roll + Opposing Yaw)
        # but modulate the STRENGTH of the yaw to steer.
        
        # If we are pointing AT the target, reduce Yaw (stop twisting, just roll forward)
        # If we need to turn, increase twist?
        
        # Actually, standard "Bot Air Dribble" often requires stopping the spin to align.
        # BUT user wants freestyle.
        # Let's try: ALWAYS ROLL, but use Pitch/Yaw to align vector.
        
        vec_to_target = SimpleNamespace(x=target.x - car.physics.location.x,
                                        y=target.y - car.physics.location.y,
                                        z=target.z - car.physics.location.z)
        
        # Normalize target vector
        target_len = vec_len(vec_to_target)
        if target_len > 0:
            vec_to_target.x /= target_len
            vec_to_target.y /= target_len
            vec_to_target.z /= target_len
            
        # Get car orientation matrix (approximate from Pitch/Yaw/Roll)
        # Without full matrix math, we can just use the controller filter to "steer towards".
        # If we FORCE ROLL, the steering becomes complex.
        
        # Hack: If we are close to lining up, KEEP ROLLING.
        # If we are WAY off, stop rolling for a micro-second to align?
        # User said "haven't seen it use air roll once".
        # This implies it was taking the "off target" branch too often.
        
        # Let's FORCE it.
        c.roll = roll_dir
        
        # Basic alignment check:
        angle_to_tgt = angle_to(car.physics.location, target)
        # If we are roughly facing the target, TORNADO.
        # If we need to turn significantly, just use standard aerial steering + roll.
        
        # Simple Logic:
        # Just pass the steer commands through, but overlay the roll.
        # This works because RL physics allows combining pitch/yaw/roll.
        
        # Reset yaw from tornado default
        c.yaw = 0.0
        
        # Steer towards target normally
        # Calculate local offsets
        # (This is hard without full matrix, so we use the simple heuristic)
        # Standard aerial steering:
        # Pitch: nose up/down towards target Z
        # Yaw: nose left/right towards target XY
        
        # This simple logic works well enough for bots if we just overlay roll.
        
        dx = target.x - car.physics.location.x
        dy = target.y - car.physics.location.y
        dz = target.z - car.physics.location.z
        
        # Local transformation would be better, but let's trust the "Face Target" logic
        # We need to compute Pitch/Yaw to face (target - pos).
        # Since we don't have the math library here, we rely on the bot framework's behavior?
        # No, we must send inputs.
        
        # Simple bot steering:
        # 1. Aim nose at ball.
        # 2. Add Roll.
        
        # Calculate global angles
        wanted_pitch = math.atan2(dz, math.sqrt(dx*dx + dy*dy))
        wanted_yaw = math.atan2(dy, dx)
        
        curr_pitch = car.physics.rotation.pitch
        curr_yaw = car.physics.rotation.yaw
        
        # Diff
        dp = wanted_pitch - curr_pitch
        dy = wanted_yaw - curr_yaw
        while dy > math.pi: dy -= 2*math.pi
        while dy < -math.pi: dy += 2*math.pi
        
        # Apply to controller
        # INCREASED SENSITIVITY for better accuracy
        c.pitch = clamp(dp * 5.0, -1.0, 1.0)
        c.yaw = clamp(dy * 5.0, -1.0, 1.0)
        
        # FORCE FREESTYLE ROLL
        # Unconditional. Always roll.
        c.roll = roll_dir
        
        # Steering Logic:
        # We need to direct the "tornado" towards the ball.
        # We do this by adjusting Pitch.
        
        # Calculate angle to target in local space (approximate)
        # If target is above us, Pitch Up. If below/forward, Pitch Down.
        
        # Is the ball above us?
        dz = target.z - car.physics.location.z
        dx = target.x - car.physics.location.x
        dy = target.y - car.physics.location.y
        
        # Simple heuristic:
        # If we need to go UP, hold Pitch Up (Nose back)
        # If we need to go FORWARD, tap Pitch Down (Nose forward)
        
        if dz > 50:
             c.pitch = 1.0 # Nose up/back to climb while twisting
        elif flat_dist(car.physics.location, target) > 100:
             c.pitch = -0.5 # Nose forward to travel
        else:
             c.pitch = 0.0
             
        # "Stick" correction:
        # If we are way off target, we might need to stop spinning for a split second to align?
        # NO, FREESTYLE ONLY. Spin faster!
        
        angle = angle_to(car.physics.location, target)
        # If we are facing away from ball, use Pitch to loop around?
        # Too complex for simple script. Just trust the Tornado.
        
        # Boost Management
        should_hover = car.physics.velocity.z < 50
        
        # Special Double Tap Boost Logic
        if is_double_tap_mode and moving_to_backboard:
             # PRE-BOUNCE: Be careful! Don't slam into wall.
             dist_to_virtual_target = dist(car.physics.location, target)
             if dist_to_virtual_target < 300:
                 c.boost = False # Glide into position
             else:
                 c.boost = (self.last_tick // 4) % 2 == 0
        else:
             # Standard Freestyle Boost
             # Boost if lower than ball or falling
             if (car.physics.location.z < target.z or should_hover) and car.boost > 0:
                  c.boost = (self.last_tick // 4) % 2 == 0 # Fast feathering
             else:
                  c.boost = False

        # 3. Flip Reset Logic (Aggressive & Prioritized)
        # We want to HIT flip resets if we are going up for a freestyle.
        
        is_under_ball = car.physics.location.z < target.z
        
        # Increased range: Start setting up the reset earlier
        # Check if dist_to_ball is defined (already calculated above in boost logic)
        # If not, define it:
        dist_to_ball = dist(car.physics.location, target)
        
        if dist_to_ball < 500 and is_under_ball:
            # We are approaching for a reset.
            
            # Hard coded "Upside Down" check attempt:
            # If we are spinning, we just want to ensure we pull our NOSE BACK relative to velocity
            # so our wheels hit the ball.
            
            c.roll = roll_dir # Keep spinning for style
            c.yaw = 0.0       # Stop tornado-ing so we don't steer away
            c.pitch = 1.0     # PITCH BACK HARD. This exposes wheels in almost any orientation.
            
            c.throttle = 1.0
            
            # Precise Boost Control
            # Boost only if we need to close the gap, but stop before impact to avoid bouncing off
            c.boost = (dist_to_ball > 150) and (car.boost > 0)
            
            # 4. Contact & Pop
            # If we are super close (contact range ~130uu)
            if dist_to_ball < 130:
                # Stop spinning to stick the landing
                c.roll = 0.0
                c.pitch = 0.0
                c.yaw = 0.0
                c.boost = False
                
                # Immediate flip usage if we get it?
                # Or wait to carry? Let's try to carry first (no auto flick yet).
                pass
                
            # Random Pre-flip / stall
            # Sometimes use jump just before contact to "stall" into reset?
            # (Too complex for simple inputs, stick to landing on ball)
        
        # increment freestyle timer
        self.freestyle_timer += 1

    def _ground_freestyle(self, c, car, ball):
        """
        Ground freestyle: Dribble -> Wall Setup OR Pop.
        Logic updated to push ball to wall for air dribble setups.
        """
        pred = getattr(self, "_last_predicted_ball", ball)
        
        dist_to_ball = dist(car.physics.location, pred)
        car_speed = vec_len(car.physics.velocity)
        ball_speed = vec_len(ball.physics.velocity)
        
        # --- 1. Setup Selection ---
        # If we have the ball, decide: Wall Setup vs Ground Pop?
        # If we are near the wall (e.g. y > 2500), push to wall.
        # If we are central, maybe pop.
        
        # Where is the nearest wall?
        # Arena width approx 4096.
        # If x > 2000 or x < -2000, we are near side walls.
        # Let's guide to nearest side wall if not moving fast towards goal.
        
        target_wall_x = 4096 if car.physics.location.x > 0 else -4096
        dist_to_wall = abs(target_wall_x - car.physics.location.x)
        
        # RELAXED CONDITION: Look for wall setups from further away (2500 instead of 1500)
        # We actively want to go to the wall for "more aerial stuff"
        is_wall_setup = dist_to_wall < 2500 and car_speed > 300 and car.boost > 20
        
        if dist_to_ball < 220: # We have the ball (Dribble State)
            
            # --- DRIBBLING STABILITY & CONTROL ---
            # Use PID-like logic to keep ball on center of roof.
            
            # 1. Calculate Ball Offset relative to Car
            # Convert ball pos to local car coordinates
            # We need ball position relative to car, rotated by car's inverse orientation.
            dx = pred.x - car.physics.location.x
            dy = pred.y - car.physics.location.y
            
            cy = math.sin(car.physics.rotation.yaw)
            cx = math.cos(car.physics.rotation.yaw)
            
            # Local X (Forward), Local Y (Right/Left)
            local_x = (dx * cx) + (dy * cy)
            local_y = (dy * cx) - (dx * cy)
            
            # 2. Steering Control (Left/Right Balance)
            # If ball is to the right (local_y > 0), we must steer RIGHT to get under it.
            # Sensitivity is key.
            steer_sensitivity = 0.015
            c.steer = clamp(local_y * steer_sensitivity, -1.0, 1.0)
            
            # 3. Throttle/Speed Control (Forward/Back Balance)
            # If ball is too far forward (local_x > 20), speed up.
            # If ball is too far back (local_x < 10), slow down.
            # Sweet spot is usually slightly forward on roof (~15-20 units).
            
            target_speed = ball_speed
            
            # If ball is falling off front
            if local_x > 30:
                c.throttle = 1.0
                c.boost = True
            # If ball is falling off back
            elif local_x < -10:
                c.throttle = 0.0 # Brake
                c.boost = False
            # In the pocket
            else:
                 # Match speed gently
                 if car_speed < target_speed - 10:
                     c.throttle = 1.0
                     c.boost = False
                 elif car_speed > target_speed + 10:
                     c.throttle = 0.0
                     c.boost = False
                 else:
                     c.throttle = 0.5 # Maintain
            
            # --- EVASIVE DRIBBLE OVERRIDE ---
            if hasattr(self, 'packet'):
                for i in range(self.packet.num_cars):
                    p_car = self.packet.game_cars[i]
                    if p_car.team != self.team_index and not p_car.is_demolished:
                        d_opp = dist(car.physics.location, p_car.physics.location)
                        if d_opp < 1000:
                            # Check if in front
                            vec_to_opp = SimpleNamespace(x=p_car.physics.location.x - car.physics.location.x,
                                                         y=p_car.physics.location.y - car.physics.location.y, z=0)
                            # Dot product with car forward
                            car_yaw = car.physics.rotation.yaw
                            forward = SimpleNamespace(x=math.cos(car_yaw), y=math.sin(car_yaw), z=0)
                            dot = vec_to_opp.x * forward.x + vec_to_opp.y * forward.y
                            
                            if dot > 0 and abs(math.atan2(vec_to_opp.y, vec_to_opp.x) - car_yaw) < 0.5:
                                # Opponent is in front! Swerve!
                                swerve_dir = 1.0 if angle_to(car.physics.location, p_car.physics.location) < car_yaw else -1.0
                                c.steer += swerve_dir * 0.5
                                c.boost = False

            # --- WALL SETUP LOGIC ---
            if is_wall_setup:
                # FORCE MODE SWITCH: If we decided to setup for wall, GO TO WALL MODE.
                # This ensures we don't get stuck in ground dribble logic.
                self.mode = "WallApproach"
                
                # We want to push the ball TOWARDS the wall, slightly angled towards goal.
                # Target point: On the wall ahead of us.
                wall_target = SimpleNamespace(x=target_wall_x, y=car.physics.location.y + (2000 * (1 if self.team_index == 0 else -1)), z=0)
                
                # Steer ball towards that wall target
                # We do this by positioning the car slightly on the INTERIOR side of the ball.
                
                # Desired heading
                heading_to_wall = angle_to(car.physics.location, wall_target)
                
                # Steer car to push ball that way
                # If we steer the car to match the heading, the ball on top moves that way.
                
                # Speed control: Don't go too fast or it bangs off wall too hard
                if car_speed > 1300: c.throttle = 0.0
                elif car_speed < 1000: c.throttle = 1.0
                else: c.throttle = 0.5
                
                # Steer
                # We need to maintain the ball on roof, so we can't turn too hard.
                # Just gentle bias towards wall.
                angle = angle_to(car.physics.location, pred) # Angle to ball
                
                # Bias: Add a small offset to the ball angle based on where we want to go?
                # Actually, simplified: Just keep dribbling logic but allow "drifting" towards wall.
                
                car_yaw = car.physics.rotation.yaw
                rel_angle = angle - car_yaw
                # Normalize
                while rel_angle > math.pi: rel_angle -= 2*math.pi
                while rel_angle < -math.pi: rel_angle += 2*math.pi
                
                # If we want to go RIGHT (wall is right), we need to be slightly LEFT of ball center?
                # Actually, simpler: Just drive towards the wall target, but prioritize keeping ball on roof.
                # The existing dribble logic keeps car under ball.
                # To move ball, we just need to steer car under the "opposite" side of the ball.
                
                # "Dumb" Wall Setup: Just let it roll off slightly if close to wall?
                # No, we'll let the generic dribble logic handle the carry,
                # but if we hit the wall ramp, we transition to WallClimb.
                
                # Logic: If close to wall, stop trying to turn away from it.
                # The regular dribble logic below matches ball speed.
                pass

            # (Replaced by PID Logic above)
            
            # --- 2. Ground-to-Air Pop (Flick Up) ---
            # "Start them up good and nice and controlled"
            # We need to wait until the ball is SETTLED on the car roof before popping.
            # Settled means local Z velocity of ball relative to car is low.
            
            # Simple check: Is ball resting?
            ball_relative_z = ball.physics.location.z - car.physics.location.z
            ball_stable = 140 < ball_relative_z < 180
            
            # Only pop if NOT setting up for wall
            if not is_wall_setup and car_speed > 800 and self.jump_ready and ball_stable:
                # WAY MORE ground to air dribbles -> Increase probability drastically
                # If we have boost, almost always go for it if not near wall.
                should_pop = (car.boost > 40 and random.random() < 0.6)
                
                if should_pop:
                    c.jump = True
                    # CONTROLLED POP:
                    # Hold Jump for longer (simulated by cooldown/flag?)
                    # Actually, just Pitch Back (1.0) to tilt car up immediately for the follow.
                    c.pitch = 0.8 # FIXED SIGN: Positive is Nose Up
                    
                    self.jump_ready = False
                    self.jump_cooldown = 15
                    self.mode = "AerialFreestyle" # Transition to air logic immediately
                    self.freestyle_timer = 0
            
        else:
            # --- Approach / Catch Mode ---
            # IMPROVED START DRIBBLE LOGIC
            
            # Calculate where we want to hit the ball (The "Pocket")
            # Usually we want to hit the bottom-back of the ball to pop it up for a carry.
            
            # Vector from ball to goal (or target wall)
            target_goal_y = -5120 if self.team_index == 1 else 5120 # Aim for opponent goal
            vec_to_goal = SimpleNamespace(x=0 - pred.x, y=target_goal_y - pred.y, z=0)
            
            # Normalize approximation
            inv_len = 1.0 / (vec_len(vec_to_goal) + 0.001)
            vec_to_goal.x *= inv_len
            vec_to_goal.y *= inv_len
            
            # We want to be behind the ball opposite to the goal
            offset_dist = 100
            target_pos = SimpleNamespace(x=pred.x - (vec_to_goal.x * offset_dist),
                                         y=pred.y - (vec_to_goal.y * offset_dist),
                                         z=pred.z)
            
            # Drive to that target
            angle = angle_to(car.physics.location, target_pos)
            c.steer = clamp(angle, -1.0, 1.0)
            c.handbrake = abs(angle) > 1.5 # Powerslide turn if needed
            
            # Speed Control for "Pick Up"
            # To start a dribble, we need speed > ball speed to scoop it.
            if car_speed < ball_speed + 300:
                c.throttle = 1.0
                c.boost = (abs(angle) < 0.2) # Boost if aligned
            else:
                c.throttle = 0.5 # Coast if already fast enough
                c.boost = False
            
            # If we are near wall, try to hit ball towards wall
            if is_wall_setup:
                 # Override target to aim for wall?
                 # Actually, WallApproach mode usually handles this if we switch.
                 # But if we are here, we are grounding it.
                 c.boost = True # Rush to wall setup
                
        self.freestyle_timer += 1

    # wrapper that chooses final aerial behavior (keeps API simple)
    def _aerial_freestyle(self, c, car, ball):
        self._aerial_freestyle_common(c, car, ball)

    # -------------------- DEFENSE BEHAVIORS --------------------
    def _shadow_defense(self, c, car, ball):
        """
        Stay between ball and our goal, matching Y velocity, waiting for a mistake.
        IMPROVED: More conservative, prevents over-committing/demo chasing.
        """
        pred = getattr(self, "_last_predicted_ball", ball)
        my_goal_y = -5120 if self.team_index == 0 else 5120
        
        # Target position: Between ball and goal, slightly offset to force ball to corner
        target_x = pred.x * 0.5 # Stay somewhat central relative to ball
        target_y = pred.y + (2000 if self.team_index == 0 else -2000) # 2000 units goal-side of ball
        
        # Clamp target Y so we don't go into our own net if ball is far
        # ALSO: Don't go past the midfield if we are defending!
        # This prevents chasing into opponent territory unnecessarily.
        if self.team_index == 0:
            target_y = max(target_y, my_goal_y + 200)
            target_y = min(target_y, -500) # Don't go past own half too much
        else:
            target_y = min(target_y, my_goal_y - 200)
            target_y = max(target_y, 500)
            
        target = SimpleNamespace(x=target_x, y=target_y, z=0)
        
        # Drive to target
        angle = angle_to(car.physics.location, target)
        c.steer = clamp(angle, -1.0, 1.0)
        
        # Speed control: Match ball speed if close, else hurry back
        dist_to_target = flat_dist(car.physics.location, target)
        if dist_to_target > 500:
             c.throttle = 1.0
             c.boost = dist_to_target > 1500
        else:
             # We are in position. Face the ball.
             angle_to_ball = angle_to(car.physics.location, pred)
             c.steer = clamp(angle_to_ball, -1.0, 1.0)
             
             # Stationary defense: Don't creep forward!
             # IMPROVED: Match ball Y velocity to shadow properly instead of stopping
             ball_vel_y = ball.physics.velocity.y
             car_vel_y = car.physics.velocity.y
             
             # If ball is coming towards us (and goal), reverse/slow down
             if (self.team_index == 0 and ball_vel_y < 0) or (self.team_index == 1 and ball_vel_y > 0):
                  c.throttle = -1.0 if abs(car_vel_y) < abs(ball_vel_y) else 0.0
             else:
                  c.throttle = 0.0
             
             # Only engage if ball comes close
             if flat_dist(car.physics.location, pred) < 800:
                 self.mode = "PanicClear" # Or a Challenge mode

    def _goal_line(self, c, car, ball):
        """
        Sit on goal line (far post relative to ball) and wait to clear.
        UPDATED: Far more aggressive interception logic.
        """
        pred = getattr(self, "_last_predicted_ball", ball)
        my_goal_y = -5120 if self.team_index == 0 else 5120
        
        # Target: Far Post Rotation
        # If ball is on left (x < 0), go to right post (x > 0)
        target_x = 400 if pred.x < 0 else -400
        target = SimpleNamespace(x=target_x, y=my_goal_y, z=0)
        
        dist_to_target = flat_dist(car.physics.location, target)
        dist_to_ball = flat_dist(car.physics.location, pred)
        
        # FAST AERIAL INTERCEPT
        # If ball is high and threatening, launch UP immediately from goal line.
        if pred.z > 500 and dist_to_ball < 2000:
             # Aim at ball and FLY
             angle_to_ball = angle_to(car.physics.location, pred)
             c.steer = clamp(angle_to_ball, -1.0, 1.0)
             if abs(angle_to_ball) < 0.3 and self.jump_ready:
                 c.jump = True
                 c.pitch = -1.0 # Fast aerial
                 c.boost = True
                 self.jump_ready = False
                 self.jump_cooldown = 10
                 # We are now committed
                 return

        if dist_to_target > 200:
            angle = angle_to(car.physics.location, target)
            c.steer = clamp(angle, -1.0, 1.0)
            c.throttle = 1.0
            c.boost = True
            c.handbrake = abs(angle) > 1.0
        else:
            # Turn to face ball
            angle_to_ball = angle_to(car.physics.location, pred)
            c.steer = clamp(angle_to_ball, -1.0, 1.0)
            c.throttle = 0.0
            
            # AGGRESSIVE CHALLENGE:
            # If ball enters our "box" (within 2500), GO!
            # Don't wait for 1500.
            if dist_to_ball < 2500:
                self.mode = "PanicClear"

    def _panic_clear(self, c, car, ball):
        """
        Hit the ball ANYWHERE away from goal.
        Includes "Half-Flip Save" logic for balls crossing the line.
        """
        pred = getattr(self, "_last_predicted_ball", ball)
        
        my_goal_y = -5120 if self.team_index == 0 else 5120
        dist_to_ball = dist(car.physics.location, pred)
        
        # --- GOAL LINE SAVE MECHANIC ---
        # If ball is very close to goal line (or slightly inside)
        # AND we are facing away from the ball/field (facing into net), we need to backflip or drive reverse.
        
        ball_in_danger_zone = abs(pred.y - my_goal_y) < 300
        car_facing_into_net = (self.team_index == 0 and car.physics.rotation.yaw < 0) or \
                              (self.team_index == 1 and car.physics.rotation.yaw > 0)
                              # (Simplified yaw check, better to use dot product but this works for standard orientation)
        
        # Check if ball is behind us relative to field center?
        # Actually, simpler: Is the ball "in the net" relative to us?
        
        # IMPROVED: Trigger slightly earlier (350uu instead of 200uu)
        if ball_in_danger_zone and dist_to_ball < 350:
             # We are right on top of it.
             # If we are facing WRONG way (away from ball?), flip backwards.
             
             # Vector from car to ball
             dx = pred.x - car.physics.location.x
             dy = pred.y - car.physics.location.y
             
             # Car forward vector
             # (Approximate based on yaw)
             cy = math.sin(car.physics.rotation.yaw)
             cx = math.cos(car.physics.rotation.yaw)
             
             # Dot product: If negative, ball is behind us
             dot = cx*dx + cy*dy
             
             if dot < 0:
                 # Ball is behind us!
                 c.throttle = -1.0 # Drive backwards
                 
                 if self.jump_ready:
                     c.jump = True
                     c.pitch = 1.0 # Backflip to scoop it out
                     self.jump_ready = False
                     self.jump_cooldown = 15
                 return # EXIT EARLY so we don't do forward logic
             
             # If dot > 0 (Ball is in front) but we are this close in danger zone:
             elif dot > 0 and self.jump_ready:
                  # Panic Front Flip
                  c.jump = True
                  c.pitch = -1.0
                  self.jump_ready = False
                  self.jump_cooldown = 15
                  return
        
        # --- STANDARD CLEAR LOGIC ---
        
        # Drive straight at ball, but slow down if we are about to overshoot
        angle = angle_to(car.physics.location, pred)
        c.steer = clamp(angle, -1.0, 1.0)
        
        car_speed = vec_len(car.physics.velocity)
        
        # Overshoot prevention:
        if abs(angle) < 0.1:
            c.throttle = 1.0
            c.boost = True
        elif abs(angle) < 0.5:
            c.throttle = 1.0
            c.boost = False
        else:
            c.throttle = 0.5
            c.boost = False
            
        # Jump logic (Standardized)
        if dist_to_ball < 800 and self.jump_ready:
             if dist_to_ball < 300:
                 # Flip into it (Front Flip for power)
                 c.jump = True
                 c.pitch = -1.0
                 self.jump_ready = False
                 self.jump_cooldown = 15
             elif car.physics.location.z < pred.z - 50:
                 # Jump up to it
                 c.jump = True
                 c.pitch = -0.5
                 self.jump_ready = False
                 self.jump_cooldown = 20

    # -------------------- helpers & safety --------------------
    def _safe_call(self, fn, *args, **kwargs):
        try:
            fn(*args, **kwargs)
        except Exception:
            pass

# End of plugin file.
